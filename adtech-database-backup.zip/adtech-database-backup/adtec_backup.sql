/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 8.0.17 : Database - replica_adtec
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`replica_adtec` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

/*Table structure for table `MyTable` */

DROP TABLE IF EXISTS `MyTable`;

CREATE TABLE `MyTable` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `etl_loging` */

DROP TABLE IF EXISTS `etl_loging`;

CREATE TABLE `etl_loging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` bigint(20) NOT NULL,
  `sp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=390 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tb_ams_api` */

DROP TABLE IF EXISTS `tb_ams_api`;

CREATE TABLE `tb_ams_api` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `grant_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `refresh_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_secret` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_Ams_Parameter_Types` */

DROP TABLE IF EXISTS `tbl_Ams_Parameter_Types`;

CREATE TABLE `tbl_Ams_Parameter_Types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parameterName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isSd` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `isSp` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `isSb` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `isActive` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_account` */

DROP TABLE IF EXISTS `tbl_account`;

CREATE TABLE `tbl_account` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBrandId` bigint(20) DEFAULT NULL,
  `marketPlaceID` bigint(20) NOT NULL,
  `fkAccountType` int(11) NOT NULL,
  `fkId` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=913 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_account_login` */

DROP TABLE IF EXISTS `tbl_account_login`;

CREATE TABLE `tbl_account_login` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `loginId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkAccountType` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_account_type` */

DROP TABLE IF EXISTS `tbl_account_type`;

CREATE TABLE `tbl_account_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_accounts_asins` */

DROP TABLE IF EXISTS `tbl_accounts_asins`;

CREATE TABLE `tbl_accounts_asins` (
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkAsinId` bigint(20) NOT NULL,
  `uniqueColumn` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdaAt` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `tbl_accounts_asins_uniquecolumn_unique` (`uniqueColumn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_active_asins` */

DROP TABLE IF EXISTS `tbl_active_asins`;

CREATE TABLE `tbl_active_asins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountId` int(11) DEFAULT NULL,
  `asin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1024 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_agency` */

DROP TABLE IF EXISTS `tbl_agency`;

CREATE TABLE `tbl_agency` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_agency_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_download_links_sb` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_download_links_sb`;

CREATE TABLE `tbl_ams_adgroup_reports_download_links_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216621 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_download_links_sd` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_download_links_sd`;

CREATE TABLE `tbl_ams_adgroup_reports_download_links_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=210658 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_download_links_sp` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_download_links_sp`;

CREATE TABLE `tbl_ams_adgroup_reports_download_links_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216471 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sb` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sb`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=494480 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sb_archived` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sb_archived`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sb_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sd` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sd`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=57171 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sd_archived` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sd_archived`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sd_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sp` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sp`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2481951 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sp_archived` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sp_archived`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sp_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_advertising_schedule_files` */

DROP TABLE IF EXISTS `tbl_ams_advertising_schedule_files`;

CREATE TABLE `tbl_ams_advertising_schedule_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkScheduleId` bigint(20) DEFAULT NULL,
  `fkParameterTypeId` bigint(20) DEFAULT NULL,
  `parameterTypeName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filePath` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completeFilePath` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `devServerLink` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apiServerLink` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isDataFound` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `isFileDeleted` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_alerts` */

DROP TABLE IF EXISTS `tbl_ams_alerts`;

CREATE TABLE `tbl_ams_alerts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `alertName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkProfileId` bigint(20) DEFAULT NULL,
  `dayPartingAlertsStatus` tinyint(1) NOT NULL DEFAULT '0',
  `biddingRuleAlertsStatus` tinyint(1) NOT NULL DEFAULT '0',
  `tacosAlertsStatus` tinyint(1) NOT NULL DEFAULT '0',
  `budgetMultiplierAlertsStatus` tinyint(1) NOT NULL DEFAULT '0',
  `bidMultiplierAlertsStatus` tinyint(1) NOT NULL DEFAULT '0',
  `addCC` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_asin_reports_download_links` */

DROP TABLE IF EXISTS `tbl_ams_asin_reports_download_links`;

CREATE TABLE `tbl_ams_asin_reports_download_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216511 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_asin_reports_downloaded_sp` */

DROP TABLE IF EXISTS `tbl_ams_asin_reports_downloaded_sp`;

CREATE TABLE `tbl_ams_asin_reports_downloaded_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `otherAsin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2246213 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_asin_reports_downloaded_sp_archived` */

DROP TABLE IF EXISTS `tbl_ams_asin_reports_downloaded_sp_archived`;

CREATE TABLE `tbl_ams_asin_reports_downloaded_sp_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `otherAsin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_authtoken` */

DROP TABLE IF EXISTS `tbl_ams_authtoken`;

CREATE TABLE `tbl_ams_authtoken` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `client_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `refresh_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_in` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` datetime NOT NULL,
  `updationDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bid_multiplier_cron` */

DROP TABLE IF EXISTS `tbl_ams_bid_multiplier_cron`;

CREATE TABLE `tbl_ams_bid_multiplier_cron` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkMultiplierId` bigint(20) NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsoredType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  `runStatus` tinyint(1) NOT NULL DEFAULT '0',
  `checkRule` tinyint(1) NOT NULL DEFAULT '0',
  `ruleResult` tinyint(1) NOT NULL DEFAULT '0',
  `isData` tinyint(1) NOT NULL DEFAULT '0',
  `currentRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bid_multiplier_keyword` */

DROP TABLE IF EXISTS `tbl_ams_bid_multiplier_keyword`;

CREATE TABLE `tbl_ams_bid_multiplier_keyword` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkConfigId` bigint(20) NOT NULL,
  `fkMultiplierId` bigint(20) NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `reportType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` decimal(8,2) NOT NULL,
  `tempBid` decimal(8,2) NOT NULL,
  `servingStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdatedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isEligible` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6331 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bid_multiplier_list` */

DROP TABLE IF EXISTS `tbl_ams_bid_multiplier_list`;

CREATE TABLE `tbl_ams_bid_multiplier_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profileId` bigint(20) unsigned NOT NULL,
  `campaignId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `userID` bigint(20) unsigned NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bid_multiplier_list_activity_tracker` */

DROP TABLE IF EXISTS `tbl_ams_bid_multiplier_list_activity_tracker`;

CREATE TABLE `tbl_ams_bid_multiplier_list_activity_tracker` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkMultiplierListId` bigint(20) unsigned NOT NULL,
  `profileId` bigint(20) unsigned NOT NULL,
  `campaignId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `userID` bigint(20) unsigned NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bid_multiplier_tracker` */

DROP TABLE IF EXISTS `tbl_ams_bid_multiplier_tracker`;

CREATE TABLE `tbl_ams_bid_multiplier_tracker` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fkMultiplierId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `profileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL DEFAULT '0',
  `bidOptimizationValue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldBid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4299 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_cron` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_cron`;

CREATE TABLE `tbl_ams_bidding_rule_cron` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `sponsoredType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriodDays` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `runStatus` tinyint(1) NOT NULL DEFAULT '0',
  `currentRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nextRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `checkRule` tinyint(1) NOT NULL DEFAULT '0',
  `ruleResult` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `emailSent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_invalid_profile` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_invalid_profile`;

CREATE TABLE `tbl_ams_bidding_rule_invalid_profile` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkId` bigint(20) NOT NULL,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_keywordId_list` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_keywordId_list`;

CREATE TABLE `tbl_ams_bidding_rule_keywordId_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkId` bigint(20) NOT NULL,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `profileId` bigint(20) NOT NULL,
  `reportType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` decimal(8,2) NOT NULL,
  `servingStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdatedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1437 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_preset` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_preset`;

CREATE TABLE `tbl_ams_bidding_rule_preset` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `presetName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `integerValues` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `thenClause` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidBy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `andOr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriod` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriodDays` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_target_list` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_target_list`;

CREATE TABLE `tbl_ams_bidding_rule_target_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkId` bigint(20) NOT NULL,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `reportType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `targetId` bigint(20) NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` decimal(8,2) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rules` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rules`;

CREATE TABLE `tbl_ams_bidding_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkUserId` bigint(20) NOT NULL,
  `fKPreSetRule` bigint(20) NOT NULL,
  `ruleName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsoredType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriod` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriodDays` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pfCampaigns` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `profileId` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `integerValues` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `thenClause` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidBy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `andOr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ccEmails` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `fkBrandId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rules_portfolio_campaign_data_cron` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rules_portfolio_campaign_data_cron`;

CREATE TABLE `tbl_ams_bidding_rules_portfolio_campaign_data_cron` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `sponsoredType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `portfolioId` bigint(20) NOT NULL,
  `reportType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `isDone` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_tracker` */

DROP TABLE IF EXISTS `tbl_ams_bidding_tracker`;

CREATE TABLE `tbl_ams_bidding_tracker` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportType` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldBid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` datetime NOT NULL,
  `targetId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=758 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_budget_rule_campaign_ids` */

DROP TABLE IF EXISTS `tbl_ams_budget_rule_campaign_ids`;

CREATE TABLE `tbl_ams_budget_rule_campaign_ids` (
  `fkRuleId` int(11) NOT NULL,
  `fkCampaignId` int(11) NOT NULL,
  `createdAt` timestamp NOT NULL,
  `shouldRemove` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_budget_rule_list` */

DROP TABLE IF EXISTS `tbl_ams_budget_rule_list`;

CREATE TABLE `tbl_ams_budget_rule_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ruleName` varchar(355) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` bigint(20) unsigned NOT NULL DEFAULT '0',
  `adType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruleType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eventId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eventName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `recurrence` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mon` tinyint(1) NOT NULL DEFAULT '0',
  `tue` tinyint(1) NOT NULL DEFAULT '0',
  `wed` tinyint(1) NOT NULL DEFAULT '0',
  `thu` tinyint(1) NOT NULL DEFAULT '0',
  `fri` tinyint(1) NOT NULL DEFAULT '0',
  `sat` tinyint(1) NOT NULL DEFAULT '0',
  `sun` tinyint(1) NOT NULL DEFAULT '0',
  `daysOfWeek` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metric` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comparisonOperator` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `threshold` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `raiseBudget` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `apiStatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: api call did not happen  or failed, 1 : success',
  `apiMsg` json DEFAULT NULL,
  `userID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ruleId` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruleState` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruleStatus` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruleStatusDetails` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  `createdDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastUpdatedDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaign_list` */

DROP TABLE IF EXISTS `tbl_ams_campaign_list`;

CREATE TABLE `tbl_ams_campaign_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkProfileId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `profileId` bigint(20) NOT NULL,
  `portfolioId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `strCampaignId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `premiumBidAdjustment` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dailyBudget` decimal(8,2) NOT NULL,
  `budget` decimal(8,2) NOT NULL,
  `endDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidOptimization` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidMultiplier` bigint(20) DEFAULT NULL,
  `budgetType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `servingStatus` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pageType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandLogoAssetID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `headline` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shouldOptimizeAsins` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandLogoUrl` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asins` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strategy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `predicate` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaigns_reports_download_links_sb` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_download_links_sb`;

CREATE TABLE `tbl_ams_campaigns_reports_download_links_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216526 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaigns_reports_download_links_sd` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_download_links_sd`;

CREATE TABLE `tbl_ams_campaigns_reports_download_links_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196565 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaigns_reports_download_links_sp` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_download_links_sp`;

CREATE TABLE `tbl_ams_campaigns_reports_download_links_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216289 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaigns_reports_downloaded_sb` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_downloaded_sb`;

CREATE TABLE `tbl_ams_campaigns_reports_downloaded_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=474733 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaigns_reports_downloaded_sb_archived` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_downloaded_sb_archived`;

CREATE TABLE `tbl_ams_campaigns_reports_downloaded_sb_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_campaigns_reports_downloaded_sd` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_downloaded_sd`;

CREATE TABLE `tbl_ams_campaigns_reports_downloaded_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=46700 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaigns_reports_downloaded_sd_archived` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_downloaded_sd_archived`;

CREATE TABLE `tbl_ams_campaigns_reports_downloaded_sd_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDPV14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_campaigns_reports_downloaded_sp` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_downloaded_sp`;

CREATE TABLE `tbl_ams_campaigns_reports_downloaded_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidPlus` tinyint(1) NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `portfolioId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `portfolioName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedUnitsOrdered1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2009142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaigns_reports_downloaded_sp_archived` */

DROP TABLE IF EXISTS `tbl_ams_campaigns_reports_downloaded_sp_archived`;

CREATE TABLE `tbl_ams_campaigns_reports_downloaded_sp_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidPlus` tinyint(1) NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `portfolioId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `portfolioName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedUnitsOrdered1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_crons` */

DROP TABLE IF EXISTS `tbl_ams_crons`;

CREATE TABLE `tbl_ams_crons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cronType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cronTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cronStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastRun` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `modifiedDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cronRun` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nextRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_customer_profile` */

DROP TABLE IF EXISTS `tbl_ams_customer_profile`;

CREATE TABLE `tbl_ams_customer_profile` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_data_duplication` */

DROP TABLE IF EXISTS `tbl_ams_data_duplication`;

CREATE TABLE `tbl_ams_data_duplication` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Account_Id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Report_Type_Data` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Repetitive_Count` bigint(20) NOT NULL DEFAULT '0',
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43633 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_campaign_schedule_ids` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_campaign_schedule_ids`;

CREATE TABLE `tbl_ams_day_parting_campaign_schedule_ids` (
  `fkScheduleId` bigint(20) NOT NULL,
  `fkCampaignId` bigint(20) NOT NULL,
  `scheduleName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userSelection` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1.Run today''s schedule, then pause, 2.Pause campaigns immediately, 3.Campaigns enabled permanently',
  `enablingPausingTime` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enablingPausingStatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isEnablingPausingDone` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_daily_campaigns` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_daily_campaigns`;

CREATE TABLE `tbl_ams_day_parting_daily_campaigns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget` double(20,2) NOT NULL,
  `bidOptimization` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `premiumBidAdjustment` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strategy` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `predicate` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` bigint(20) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `portfolioId` bigint(20) NOT NULL DEFAULT '0',
  `profileId` bigint(20) NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `budgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `servingStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandLogoAssetID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `headline` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shouldOptimizeAsins` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asins` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandLogoUrl` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pageType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_history_cron_schedules` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_history_cron_schedules`;

CREATE TABLE `tbl_ams_day_parting_history_cron_schedules` (
  `fkScheduleId` bigint(20) NOT NULL,
  `startTime` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endTime` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isMessage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cronDate` date NOT NULL,
  `creationDate` datetime NOT NULL,
  `updationDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_pf_campaign_schedules` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_pf_campaign_schedules`;

CREATE TABLE `tbl_ams_day_parting_pf_campaign_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkManagerId` bigint(20) unsigned NOT NULL,
  `managerEmail` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduleName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `portfolioCampaignType` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emailReceiptStart` tinyint(1) NOT NULL DEFAULT '0',
  `emailReceiptEnd` tinyint(1) NOT NULL DEFAULT '0',
  `isCronRunning` tinyint(1) NOT NULL DEFAULT '0',
  `isCronSuccess` tinyint(1) NOT NULL DEFAULT '0',
  `isCronError` tinyint(1) NOT NULL DEFAULT '0',
  `isCronEnd` bigint(20) NOT NULL DEFAULT '0',
  `isScheduleExpired` tinyint(1) NOT NULL DEFAULT '0',
  `reccuringSchedule` bigint(20) NOT NULL DEFAULT '0',
  `stopScheduleDate` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ccEmails` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fkBrandId` bigint(20) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL DEFAULT '0',
  `selectionHours` json NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_portfolio_all_campaign_lists` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_portfolio_all_campaign_lists`;

CREATE TABLE `tbl_ams_day_parting_portfolio_all_campaign_lists` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget` double(20,2) NOT NULL,
  `bidOptimization` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `premiumBidAdjustment` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strategy` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `predicate` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` bigint(20) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `portfolioId` bigint(20) NOT NULL DEFAULT '0',
  `profileId` bigint(20) NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `budgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `servingStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandLogoAssetID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `headline` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shouldOptimizeAsins` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asins` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandLogoUrl` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pageType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_portfolio_schedule_ids` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_portfolio_schedule_ids`;

CREATE TABLE `tbl_ams_day_parting_portfolio_schedule_ids` (
  `fkScheduleId` bigint(20) NOT NULL,
  `fkPortfolioId` bigint(20) NOT NULL,
  `scheduleName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `portfolioName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userSelection` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1.Run today''s schedule, then pause, 2.Pause campaigns immediately, 3.Campaigns enabled permanently',
  `enablingPausingTime` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enablingPausingStatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isEnablingPausingDone` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_portfolios` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_portfolios`;

CREATE TABLE `tbl_ams_day_parting_portfolios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `portfolioId` bigint(20) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(20,2) NOT NULL,
  `currencyCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `inBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `profileId` bigint(20) NOT NULL,
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_schedule_cron_statuses` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_schedule_cron_statuses`;

CREATE TABLE `tbl_ams_day_parting_schedule_cron_statuses` (
  `fkScheduleId` bigint(20) NOT NULL,
  `cronMessage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduleDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduleStatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0:default, 1:Success, 2: Error'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_day_parting_schedules_time_campaigns` */

DROP TABLE IF EXISTS `tbl_ams_day_parting_schedules_time_campaigns`;

CREATE TABLE `tbl_ams_day_parting_schedules_time_campaigns` (
  `fkScheduleId` bigint(20) NOT NULL,
  `startTime` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `endTime` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'monday, tuesday, wednesday, thursday, friday, saturday, sunday',
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_failed_reports_links` */

DROP TABLE IF EXISTS `tbl_ams_failed_reports_links`;

CREATE TABLE `tbl_ams_failed_reports_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `reportType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=506 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_keyword_for_biding_rule` */

DROP TABLE IF EXISTS `tbl_ams_keyword_for_biding_rule`;

CREATE TABLE `tbl_ams_keyword_for_biding_rule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` int(11) NOT NULL,
  `fkAccountId` int(11) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `profile_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_type` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `cost` decimal(19,2) NOT NULL,
  `attributedConversions` int(11) NOT NULL,
  `attributedConversionsSameSKU` int(11) NOT NULL,
  `attributedUnitsOrdered` int(11) NOT NULL,
  `attributedSales` decimal(19,2) NOT NULL,
  `attributedSalesSameSKU` decimal(19,2) NOT NULL,
  `reportDate` int(11) NOT NULL,
  `creationDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_keyword_reports_download_links_sb` */

DROP TABLE IF EXISTS `tbl_ams_keyword_reports_download_links_sb`;

CREATE TABLE `tbl_ams_keyword_reports_download_links_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216454 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_keyword_reports_download_links_sp` */

DROP TABLE IF EXISTS `tbl_ams_keyword_reports_download_links_sp`;

CREATE TABLE `tbl_ams_keyword_reports_download_links_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216456 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_keyword_reports_downloaded_data_sb` */

DROP TABLE IF EXISTS `tbl_ams_keyword_reports_downloaded_data_sb`;

CREATE TABLE `tbl_ams_keyword_reports_downloaded_data_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `keywordBid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `keywordStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `targetId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `targetingExpression` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `targetingText` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `targetingType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=9087505 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_keyword_reports_downloaded_data_sb_archived` */

DROP TABLE IF EXISTS `tbl_ams_keyword_reports_downloaded_data_sb_archived`;

CREATE TABLE `tbl_ams_keyword_reports_downloaded_data_sb_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `keywordBid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `keywordStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `targetId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `targetingExpression` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `targetingText` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `targetingType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_keyword_reports_downloaded_data_sp` */

DROP TABLE IF EXISTS `tbl_ams_keyword_reports_downloaded_data_sp`;

CREATE TABLE `tbl_ams_keyword_reports_downloaded_data_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=29300546 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_keyword_reports_downloaded_data_sp_archived` */

DROP TABLE IF EXISTS `tbl_ams_keyword_reports_downloaded_data_sp_archived`;

CREATE TABLE `tbl_ams_keyword_reports_downloaded_data_sp_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_keywordbid` */

DROP TABLE IF EXISTS `tbl_ams_keywordbid`;

CREATE TABLE `tbl_ams_keywordbid` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `adtype` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `profileId` bigint(20) unsigned NOT NULL,
  `keywordId` bigint(20) unsigned NOT NULL,
  `adGroupId` bigint(20) unsigned NOT NULL,
  `campaignId` bigint(20) unsigned NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` decimal(8,2) NOT NULL,
  `servingStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdatedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=634795 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_keywordbid_tracker` */

DROP TABLE IF EXISTS `tbl_ams_keywordbid_tracker`;

CREATE TABLE `tbl_ams_keywordbid_tracker` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profileId` bigint(20) unsigned NOT NULL,
  `campaignId` bigint(20) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  `dated` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8332 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_link_duplication` */

DROP TABLE IF EXISTS `tbl_ams_link_duplication`;

CREATE TABLE `tbl_ams_link_duplication` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Account_Id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Report_Type_Link` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Repetitive_Count` bigint(20) NOT NULL DEFAULT '0',
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=613 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_link_error` */

DROP TABLE IF EXISTS `tbl_ams_link_error`;

CREATE TABLE `tbl_ams_link_error` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Account_id` bigint(20) NOT NULL DEFAULT '0',
  `Profile_id` bigint(20) NOT NULL DEFAULT '0',
  `Report_Type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Report_date` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1015044 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_portfolios` */

DROP TABLE IF EXISTS `tbl_ams_portfolios`;

CREATE TABLE `tbl_ams_portfolios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `portfolioId` bigint(20) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `profileId` bigint(20) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(20,2) NOT NULL DEFAULT '0.00',
  `currencyCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `policy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `inBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sandBox` tinyint(1) NOT NULL,
  `live` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3446 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_productsads_reports_download_links` */

DROP TABLE IF EXISTS `tbl_ams_productsads_reports_download_links`;

CREATE TABLE `tbl_ams_productsads_reports_download_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216471 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_productsads_reports_download_links_sd` */

DROP TABLE IF EXISTS `tbl_ams_productsads_reports_download_links_sd`;

CREATE TABLE `tbl_ams_productsads_reports_download_links_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=210597 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_productsads_reports_downloaded_data` */

DROP TABLE IF EXISTS `tbl_ams_productsads_reports_downloaded_data`;

CREATE TABLE `tbl_ams_productsads_reports_downloaded_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedUnitsOrdered1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=9039419 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_productsads_reports_downloaded_data_archived` */

DROP TABLE IF EXISTS `tbl_ams_productsads_reports_downloaded_data_archived`;

CREATE TABLE `tbl_ams_productsads_reports_downloaded_data_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedUnitsOrdered1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_productsads_reports_downloaded_data_sd` */

DROP TABLE IF EXISTS `tbl_ams_productsads_reports_downloaded_data_sd`;

CREATE TABLE `tbl_ams_productsads_reports_downloaded_data_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`fkBatchId`,`fkProfileId`,`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=766233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_productsads_reports_downloaded_data_sd_archived` */

DROP TABLE IF EXISTS `tbl_ams_productsads_reports_downloaded_data_sd_archived`;

CREATE TABLE `tbl_ams_productsads_reports_downloaded_data_sd_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_profile_log` */

DROP TABLE IF EXISTS `tbl_ams_profile_log`;

CREATE TABLE `tbl_ams_profile_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkprofileid` bigint(20) NOT NULL,
  `profileId` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `countrycode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT NULL,
  `typeofchange` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_profile_report_status` */

DROP TABLE IF EXISTS `tbl_ams_profile_report_status`;

CREATE TABLE `tbl_ams_profile_report_status` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `batchId` bigint(20) unsigned NOT NULL,
  `profileId` bigint(20) unsigned NOT NULL,
  `adType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `error_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1972525 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_profiles` */

DROP TABLE IF EXISTS `tbl_ams_profiles`;

CREATE TABLE `tbl_ams_profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `profileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `countryCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currencyCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `marketplaceStringId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupSpSixtyDays` tinyint(1) NOT NULL,
  `aSINsSixtyDays` tinyint(1) NOT NULL,
  `campaignSpSixtyDays` tinyint(1) NOT NULL,
  `keywordSbSixtyDays` tinyint(1) NOT NULL,
  `keywordSpSixtyDays` tinyint(1) NOT NULL,
  `productAdsSixtyDays` tinyint(1) NOT NULL,
  `productTargetingSixtyDays` tinyint(1) NOT NULL,
  `creationDate` datetime NOT NULL,
  `SponsoredBrandCampaignsSixtyDays` tinyint(1) NOT NULL,
  `SponsoredDisplayCampaignsSixtyDays` tinyint(1) NOT NULL,
  `SponsoredDisplayAdgroupSixtyDays` tinyint(1) NOT NULL,
  `SponsoredDisplayProductAdsSixtyDays` tinyint(1) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `isSandboxProfile` tinyint(1) NOT NULL DEFAULT '1',
  `SponsoredBrandAdgroupSixtyDays` tinyint(1) NOT NULL DEFAULT '0',
  `SponsoredBrandTargetingSixtyDays` tinyint(1) NOT NULL DEFAULT '0',
  `adGroupSdSixtyDays` tinyint(1) DEFAULT '0',
  `SponsoredDisplayTargetSixtyDays` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtl_ams` (`profileId`)
) ENGINE=InnoDB AUTO_INCREMENT=1605 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_profiles_validate` */

DROP TABLE IF EXISTS `tbl_ams_profiles_validate`;

CREATE TABLE `tbl_ams_profiles_validate` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `countryCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `creationDate` date NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '0',
  `reportDate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=312733 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_report_id` */

DROP TABLE IF EXISTS `tbl_ams_report_id`;

CREATE TABLE `tbl_ams_report_id` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recordType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isDone` int(11) NOT NULL DEFAULT '0',
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3003114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_report_id_error` */

DROP TABLE IF EXISTS `tbl_ams_report_id_error`;

CREATE TABLE `tbl_ams_report_id_error` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Account_id` bigint(20) NOT NULL DEFAULT '0',
  `Profile_id` bigint(20) NOT NULL DEFAULT '0',
  `Report_Type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Report_date` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1021661 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_report_id_mandatory` */

DROP TABLE IF EXISTS `tbl_ams_report_id_mandatory`;

CREATE TABLE `tbl_ams_report_id_mandatory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_type_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_report_id` bigint(20) NOT NULL DEFAULT '0',
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_reports_metrics` */

DROP TABLE IF EXISTS `tbl_ams_reports_metrics`;

CREATE TABLE `tbl_ams_reports_metrics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `metricName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tblColumnName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fkParameterType` bigint(20) DEFAULT NULL,
  `isActive` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_schedule_advertising_reports` */

DROP TABLE IF EXISTS `tbl_ams_schedule_advertising_reports`;

CREATE TABLE `tbl_ams_schedule_advertising_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reportName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amsProfileId` bigint(20) DEFAULT NULL,
  `fkProfileId` bigint(20) DEFAULT NULL,
  `granularity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allMetricsCheck` tinyint(1) NOT NULL DEFAULT '0',
  `addCC` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timeFrame` int(11) DEFAULT NULL,
  `time` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `completedTime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cronLastRunDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cronLastRunTime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mon` tinyint(1) NOT NULL DEFAULT '0',
  `tue` tinyint(1) NOT NULL DEFAULT '0',
  `wed` tinyint(1) NOT NULL DEFAULT '0',
  `thu` tinyint(1) NOT NULL DEFAULT '0',
  `fri` tinyint(1) NOT NULL DEFAULT '0',
  `sat` tinyint(1) NOT NULL DEFAULT '0',
  `sun` tinyint(1) NOT NULL DEFAULT '0',
  `createdBy` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_schedule_selected_email_reports` */

DROP TABLE IF EXISTS `tbl_ams_schedule_selected_email_reports`;

CREATE TABLE `tbl_ams_schedule_selected_email_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkReportScheduleId` bigint(20) DEFAULT NULL,
  `fkSponsordTypeId` bigint(20) DEFAULT NULL,
  `fkReportId` bigint(20) DEFAULT NULL,
  `fkParameterType` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_schedule_selected_email_sponsored_types` */

DROP TABLE IF EXISTS `tbl_ams_schedule_selected_email_sponsored_types`;

CREATE TABLE `tbl_ams_schedule_selected_email_sponsored_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkReportScheduleId` bigint(20) DEFAULT NULL,
  `fkSponsordTypeId` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_scheduled_email_reports_metrics` */

DROP TABLE IF EXISTS `tbl_ams_scheduled_email_reports_metrics`;

CREATE TABLE `tbl_ams_scheduled_email_reports_metrics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkReportScheduleId` bigint(20) DEFAULT NULL,
  `fkReportMetricId` bigint(20) DEFAULT NULL,
  `fkParameterType` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=243 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_score_card` */

DROP TABLE IF EXISTS `tbl_ams_score_card`;

CREATE TABLE `tbl_ams_score_card` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Total_Report_Id` bigint(20) NOT NULL DEFAULT '0',
  `Total_Link_Reports` bigint(20) NOT NULL DEFAULT '0',
  `New_Profile` bigint(20) NOT NULL DEFAULT '0',
  `Active_Profile` bigint(20) NOT NULL DEFAULT '0',
  `InActive_Profile` bigint(20) NOT NULL DEFAULT '0',
  `Profile_Incompatible_with_SD` bigint(20) NOT NULL DEFAULT '0',
  `Agency_Type` bigint(20) NOT NULL DEFAULT '0',
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=278 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_sponsored_reports` */

DROP TABLE IF EXISTS `tbl_ams_sponsored_reports`;

CREATE TABLE `tbl_ams_sponsored_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reportName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fkSponsordTypeId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fkParameterType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_sponsored_types` */

DROP TABLE IF EXISTS `tbl_ams_sponsored_types`;

CREATE TABLE `tbl_ams_sponsored_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sponsordTypenName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_tacos_bid_tracker` */

DROP TABLE IF EXISTS `tbl_ams_tacos_bid_tracker`;

CREATE TABLE `tbl_ams_tacos_bid_tracker` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fkTacosId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `profileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportType` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldBid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17361 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_tacos_keywordid_list` */

DROP TABLE IF EXISTS `tbl_ams_tacos_keywordid_list`;

CREATE TABLE `tbl_ams_tacos_keywordid_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkId` bigint(20) NOT NULL,
  `fkTacosId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `reportType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` decimal(8,2) NOT NULL,
  `servingStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdatedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39010 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_tacos_target_list` */

DROP TABLE IF EXISTS `tbl_ams_tacos_target_list`;

CREATE TABLE `tbl_ams_tacos_target_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkId` bigint(20) NOT NULL,
  `fkTacosId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `reportType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `targetId` bigint(20) NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` decimal(8,2) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_targets_reports_download_links` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_download_links`;

CREATE TABLE `tbl_ams_targets_reports_download_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216544 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_targets_reports_download_links_sb` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_download_links_sb`;

CREATE TABLE `tbl_ams_targets_reports_download_links_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216482 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_targets_reports_download_links_sd` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_download_links_sd`;

CREATE TABLE `tbl_ams_targets_reports_download_links_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  `expiration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=193755 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_targets_reports_downloaded_data` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_downloaded_data`;

CREATE TABLE `tbl_ams_targets_reports_downloaded_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingExpression` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11398299 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_targets_reports_downloaded_data_archived` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_downloaded_data_archived`;

CREATE TABLE `tbl_ams_targets_reports_downloaded_data_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingExpression` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_targets_reports_downloaded_data_sb` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_downloaded_data_sb`;

CREATE TABLE `tbl_ams_targets_reports_downloaded_data_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingExpression` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=682825 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_targets_reports_downloaded_data_sb_archived` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_downloaded_data_sb_archived`;

CREATE TABLE `tbl_ams_targets_reports_downloaded_data_sb_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingExpression` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_targets_reports_downloaded_data_sd` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_downloaded_data_sd`;

CREATE TABLE `tbl_ams_targets_reports_downloaded_data_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingText` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `targetingExpression` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `targetingType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107345 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_targets_reports_downloaded_data_sd_for_biding_rule` */

DROP TABLE IF EXISTS `tbl_ams_targets_reports_downloaded_data_sd_for_biding_rule`;

CREATE TABLE `tbl_ams_targets_reports_downloaded_data_sd_for_biding_rule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingText` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179057 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_total_link` */

DROP TABLE IF EXISTS `tbl_ams_total_link`;

CREATE TABLE `tbl_ams_total_link` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_type_link` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_link_count` bigint(20) NOT NULL DEFAULT '0',
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2542 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_total_report_id` */

DROP TABLE IF EXISTS `tbl_ams_total_report_id`;

CREATE TABLE `tbl_ams_total_report_id` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_type_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_report_id` bigint(20) NOT NULL DEFAULT '0',
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4086 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_tracker` */

DROP TABLE IF EXISTS `tbl_ams_tracker`;

CREATE TABLE `tbl_ams_tracker` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reportName` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15205724 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_valid_token_response` */

DROP TABLE IF EXISTS `tbl_ams_valid_token_response`;

CREATE TABLE `tbl_ams_valid_token_response` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `aud` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `iss` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exp` int(10) unsigned NOT NULL,
  `app_id` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `iat` int(10) unsigned NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_asin_collection` */

DROP TABLE IF EXISTS `tbl_asin_collection`;

CREATE TABLE `tbl_asin_collection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_type` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `isNew` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_asin_segments` */

DROP TABLE IF EXISTS `tbl_asin_segments`;

CREATE TABLE `tbl_asin_segments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) NOT NULL,
  `fkSegmentId` bigint(20) NOT NULL,
  `fkGroupId` bigint(20) DEFAULT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `occurrenceDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000:00:00',
  `uniqueColumn` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_asin_segments_uniquecolumn_unique` (`uniqueColumn`)
) ENGINE=InnoDB AUTO_INCREMENT=244928 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_asin_tags` */

DROP TABLE IF EXISTS `tbl_asin_tags`;

CREATE TABLE `tbl_asin_tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkTagId` bigint(20) unsigned NOT NULL,
  `tag` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullFillmentChannel` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uniqueColumn` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_asin_tags_uniquecolumn_unique` (`uniqueColumn`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_asins` */

DROP TABLE IF EXISTS `tbl_asins`;

CREATE TABLE `tbl_asins` (
  `asin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_id` int(10) unsigned NOT NULL,
  `asin_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `created_on` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin_status` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'i',
  `allocatedThread` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`asin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20975 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_asins_instant_fail_statuses` */

DROP TABLE IF EXISTS `tbl_asins_instant_fail_statuses`;

CREATE TABLE `tbl_asins_instant_fail_statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `failed_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `c_id` int(10) unsigned NOT NULL,
  `isNew` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_asins_instant_temp_schedules` */

DROP TABLE IF EXISTS `tbl_asins_instant_temp_schedules`;

CREATE TABLE `tbl_asins_instant_temp_schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fkCollectionId` int(10) unsigned NOT NULL,
  `isRunning` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_asins_intant_temp_urls` */

DROP TABLE IF EXISTS `tbl_asins_intant_temp_urls`;

CREATE TABLE `tbl_asins_intant_temp_urls` (
  `asin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_id` int(10) unsigned NOT NULL,
  `asin_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `created_on` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin_status` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'i',
  `allocatedThread` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`asin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=389 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_asins_result` */

DROP TABLE IF EXISTS `tbl_asins_result`;

CREATE TABLE `tbl_asins_result` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_id` bigint(20) NOT NULL,
  `url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `asinExists` smallint(6) NOT NULL DEFAULT '0',
  `capturedAt` date NOT NULL,
  `metaKeywords` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `offerPriceOrignal` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `offerPrice` decimal(10,2) DEFAULT NULL,
  `listPriceOrignal` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `listPrice` decimal(10,2) DEFAULT NULL,
  `offerCount` int(10) unsigned NOT NULL DEFAULT '0',
  `modelNo` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `breadcrumbs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'NA',
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `imageCount` int(10) unsigned NOT NULL DEFAULT '0',
  `videoCount` int(10) unsigned NOT NULL DEFAULT '0',
  `bullets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `bulletCount` int(10) unsigned NOT NULL DEFAULT '0',
  `avgWordsPerBulitCount` decimal(10,0) DEFAULT NULL,
  `aplus` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `aplusModule` smallint(6) NOT NULL DEFAULT '0',
  `averageReview` decimal(10,2) DEFAULT NULL,
  `totalReviews` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `bestSellerRank` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bestSellerCategory` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isPrime` tinyint(1) NOT NULL DEFAULT '0',
  `isAvailable` tinyint(1) NOT NULL DEFAULT '0',
  `availabilityMessage` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `isAmazonChoice` tinyint(1) NOT NULL DEFAULT '0',
  `amazonChoiceTerm` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `isPromo` tinyint(1) NOT NULL DEFAULT '0',
  `seller` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `size` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `color` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `length` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `width` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `height` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `shipWeight` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `dateFirstAvailable` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `fkAsinId` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1005921 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_attribute_type` */

DROP TABLE IF EXISTS `tbl_attribute_type`;

CREATE TABLE `tbl_attribute_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attributeTypeName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_batch_id` */

DROP TABLE IF EXISTS `tbl_batch_id`;

CREATE TABLE `tbl_batch_id` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) NOT NULL,
  `batchId` bigint(20) NOT NULL,
  `reportDate` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=221964 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_brand_association` */

DROP TABLE IF EXISTS `tbl_brand_association`;

CREATE TABLE `tbl_brand_association` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBrandId` bigint(20) NOT NULL,
  `fkManagerId` bigint(20) NOT NULL,
  `sendEmail` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2935 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_brands` */

DROP TABLE IF EXISTS `tbl_brands`;

CREATE TABLE `tbl_brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAgencyId` bigint(20) NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isParentBrand` int(11) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_buybox_accounts_asins` */

DROP TABLE IF EXISTS `tbl_buybox_accounts_asins`;

CREATE TABLE `tbl_buybox_accounts_asins` (
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkAsinId` bigint(20) NOT NULL,
  `uniqueColumn` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdaAt` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `tbl_buybox_accounts_asins_uniquecolumn_unique` (`uniqueColumn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_buybox_activity_tracker` */

DROP TABLE IF EXISTS `tbl_buybox_activity_tracker`;

CREATE TABLE `tbl_buybox_activity_tracker` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activity` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `activity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NA',
  `cron_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NA',
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NA',
  `activity_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130522 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_buybox_asin_list` */

DROP TABLE IF EXISTS `tbl_buybox_asin_list`;

CREATE TABLE `tbl_buybox_asin_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cNameBuybox` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asinCode` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scrapStatus` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_buybox_asin_scraped` */

DROP TABLE IF EXISTS `tbl_buybox_asin_scraped`;

CREATE TABLE `tbl_buybox_asin_scraped` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkCollection` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isNew` tinyint(1) NOT NULL DEFAULT '1',
  `brand` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `soldBy` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `soldByAlert` int(11) NOT NULL,
  `price` double(10,2) NOT NULL,
  `priceOrignal` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `primeDesc` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prime` int(11) NOT NULL,
  `stock` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `stockAlert` int(11) NOT NULL,
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asinCode` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `fkAsinId` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_buybox_cron` */

DROP TABLE IF EXISTS `tbl_buybox_cron`;

CREATE TABLE `tbl_buybox_cron` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cNameBuybox` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currentFrequency` int(10) unsigned NOT NULL,
  `duration` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nextRun` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nextRunTime` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hoursToAdd` int(10) unsigned NOT NULL,
  `cronStatus` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_buybox_fail_statuses` */

DROP TABLE IF EXISTS `tbl_buybox_fail_statuses`;

CREATE TABLE `tbl_buybox_fail_statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `failed_data` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `failed_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `crawler_id` int(10) unsigned NOT NULL,
  `isNew` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `fkAccountId` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_buybox_temp_urls` */

DROP TABLE IF EXISTS `tbl_buybox_temp_urls`;

CREATE TABLE `tbl_buybox_temp_urls` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_bbc_id` bigint(20) NOT NULL,
  `fk_bb_asin_list_id` bigint(20) NOT NULL,
  `frequency` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asinCode` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scrapStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `allocatedThread` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_campaign_tags` */

DROP TABLE IF EXISTS `tbl_campaign_tags`;

CREATE TABLE `tbl_campaign_tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkManagerId` bigint(20) unsigned NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_cron_events` */

DROP TABLE IF EXISTS `tbl_cron_events`;

CREATE TABLE `tbl_cron_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cronEventName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_event_logs` */

DROP TABLE IF EXISTS `tbl_event_logs`;

CREATE TABLE `tbl_event_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkEventId` bigint(20) NOT NULL,
  `occurrenceDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uniqueColumn` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_product_preview_uniquecolumn_unique` (`uniqueColumn`)
) ENGINE=InnoDB AUTO_INCREMENT=618678 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_events` */

DROP TABLE IF EXISTS `tbl_events`;

CREATE TABLE `tbl_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `eventName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isEventAuto` tinyint(1) NOT NULL DEFAULT '0',
  `eventColor` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_fail_statuses` */

DROP TABLE IF EXISTS `tbl_fail_statuses`;

CREATE TABLE `tbl_fail_statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `failed_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `crawler_id` int(10) unsigned NOT NULL,
  `isNew` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `fkAccountId` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=90579 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_notification` */

DROP TABLE IF EXISTS `tbl_notification`;

CREATE TABLE `tbl_notification` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `fkAccountId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=413 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_notification_details` */

DROP TABLE IF EXISTS `tbl_notification_details`;

CREATE TABLE `tbl_notification_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `n_id` bigint(20) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3182874 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_product_categories` */

DROP TABLE IF EXISTS `tbl_product_categories`;

CREATE TABLE `tbl_product_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkProductTblId` int(11) DEFAULT NULL,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `source` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SC',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `fkSellerConfigId` int(11) DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productCategoryId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `productCategoryName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `categoryTreeSequence` int(11) DEFAULT NULL,
  `categoryTreeNumber` int(11) DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_product_preview_type` */

DROP TABLE IF EXISTS `tbl_product_preview_type`;

CREATE TABLE `tbl_product_preview_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `typeTitle` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_product_segment_groups` */

DROP TABLE IF EXISTS `tbl_product_segment_groups`;

CREATE TABLE `tbl_product_segment_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `groupName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_product_segments` */

DROP TABLE IF EXISTS `tbl_product_segments`;

CREATE TABLE `tbl_product_segments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `segmentName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkGroupId` bigint(20) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_product_table_tags` */

DROP TABLE IF EXISTS `tbl_product_table_tags`;

CREATE TABLE `tbl_product_table_tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fkManagerId` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_proxy` */

DROP TABLE IF EXISTS `tbl_proxy`;

CREATE TABLE `tbl_proxy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `proxy_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `proxy_auth` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_blocked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=202 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_repDate` */

DROP TABLE IF EXISTS `tbl_repDate`;

CREATE TABLE `tbl_repDate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reportDate` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_roles` */

DROP TABLE IF EXISTS `tbl_roles`;

CREATE TABLE `tbl_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_account_client` */

DROP TABLE IF EXISTS `tbl_rtl_account_client`;

CREATE TABLE `tbl_rtl_account_client` (
  `rtl_acc_cl_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `Agency_Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `client_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_account_password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_creation` timestamp NOT NULL,
  `client_updation` timestamp NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `marketplaceid` bigint(20) NOT NULL,
  `account_type` int(11) NOT NULL,
  `account_type_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkId` bigint(20) NOT NULL,
  `accountName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_creation` timestamp NULL DEFAULT NULL,
  `account_updation` timestamp NULL DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`rtl_acc_cl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1024 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_ams_adgroup` */

DROP TABLE IF EXISTS `tbl_rtl_ams_adgroup`;

CREATE TABLE `tbl_rtl_ams_adgroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkAccountId` int(11) DEFAULT NULL,
  `fkProfileId` bigint(20) DEFAULT NULL,
  `profile_name` varchar(191) DEFAULT NULL,
  `campaignId` bigint(20) DEFAULT NULL,
  `campaignName` varchar(191) DEFAULT NULL,
  `adGroupId` bigint(20) DEFAULT NULL,
  `adGroupName` varchar(191) DEFAULT NULL,
  `report_type` varchar(4) DEFAULT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `attributedConversions` int(11) DEFAULT NULL,
  `attributedConversionsSameSKU` int(11) DEFAULT NULL,
  `attributedUnitsOrdered` int(11) DEFAULT NULL,
  `attributedSales` decimal(19,2) DEFAULT NULL,
  `attributedSalesSameSKU` decimal(19,2) DEFAULT NULL,
  `reportDate` date DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16384 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_rtl_ams_asin` */

DROP TABLE IF EXISTS `tbl_rtl_ams_asin`;

CREATE TABLE `tbl_rtl_ams_asin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkAccountId` int(11) DEFAULT NULL,
  `fkProfileId` bigint(20) DEFAULT NULL,
  `profile_name` varchar(191) DEFAULT NULL,
  `campaignId` bigint(20) DEFAULT NULL,
  `campaignName` varchar(191) DEFAULT NULL,
  `adGroupId` bigint(20) DEFAULT NULL,
  `adGroupName` varchar(191) DEFAULT NULL,
  `keywordId` bigint(20) DEFAULT NULL,
  `keywordText` varchar(191) DEFAULT NULL,
  `asin` varchar(40) DEFAULT NULL,
  `otherAsin` varchar(40) DEFAULT NULL,
  `sku` varchar(40) DEFAULT NULL,
  `currency` varchar(50) DEFAULT NULL,
  `matchType` varchar(50) DEFAULT NULL,
  `report_type` varchar(50) DEFAULT NULL,
  `attributedUnitsOrdered` int(11) DEFAULT NULL,
  `attributedSalesOtherSKU` decimal(19,2) DEFAULT NULL,
  `attributedUnitsOrderedOtherSKU` int(11) DEFAULT NULL,
  `reportDate` date DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16384 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_rtl_ams_asin_list` */

DROP TABLE IF EXISTS `tbl_rtl_ams_asin_list`;

CREATE TABLE `tbl_rtl_ams_asin_list` (
  `fkProfileId` bigint(20) DEFAULT NULL,
  `campaignId` bigint(20) DEFAULT NULL,
  `asin` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_ams_campaign` */

DROP TABLE IF EXISTS `tbl_rtl_ams_campaign`;

CREATE TABLE `tbl_rtl_ams_campaign` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkAccountId` int(11) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `profile_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` decimal(19,2) NOT NULL,
  `campaign_budget_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `cost` decimal(19,2) NOT NULL,
  `attributedConversions` int(11) NOT NULL,
  `attributedConversionsSameSKU` int(11) NOT NULL,
  `attributedUnitsOrdered` int(11) NOT NULL,
  `attributedSales` decimal(19,2) NOT NULL,
  `attributedSalesSameSKU` decimal(19,2) NOT NULL,
  `reportDate` int(11) NOT NULL,
  `creationDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16384 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_ams_campaign_list` */

DROP TABLE IF EXISTS `tbl_rtl_ams_campaign_list`;

CREATE TABLE `tbl_rtl_ams_campaign_list` (
  `fkAccountId` int(11) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `ProfileId` bigint(20) NOT NULL,
  `campaignId` varchar(50) NOT NULL,
  `campaignName` varchar(191) NOT NULL,
  `campaign_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_rtl_ams_keyword` */

DROP TABLE IF EXISTS `tbl_rtl_ams_keyword`;

CREATE TABLE `tbl_rtl_ams_keyword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkAccountId` int(11) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `profile_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_type` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `cost` decimal(19,2) NOT NULL,
  `attributedConversions` int(11) NOT NULL,
  `attributedConversionsSameSKU` int(11) NOT NULL,
  `attributedUnitsOrdered` int(11) NOT NULL,
  `attributedSales` decimal(19,2) NOT NULL,
  `attributedSalesSameSKU` decimal(19,2) NOT NULL,
  `reportDate` int(11) NOT NULL,
  `creationDate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_RtlKeyword_ReportDate` (`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=62578287 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_ams_keyword_new` */

DROP TABLE IF EXISTS `tbl_rtl_ams_keyword_new`;

CREATE TABLE `tbl_rtl_ams_keyword_new` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkAccountId` int(11) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `profile_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_type` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `cost` decimal(19,2) NOT NULL,
  `attributedConversions` int(11) NOT NULL,
  `attributedConversionsSameSKU` int(11) NOT NULL,
  `attributedUnitsOrdered` int(11) NOT NULL,
  `attributedSales` decimal(19,2) NOT NULL,
  `attributedSalesSameSKU` decimal(19,2) NOT NULL,
  `reportDate` int(11) NOT NULL,
  `creationDate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_RtlKeyword_ReportDate` (`reportDate`)
) ENGINE=InnoDB AUTO_INCREMENT=131071 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_ams_product_ads` */

DROP TABLE IF EXISTS `tbl_rtl_ams_product_ads`;

CREATE TABLE `tbl_rtl_ams_product_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkAccountId` int(11) DEFAULT NULL,
  `fkProfileId` bigint(20) DEFAULT NULL,
  `profile_name` varchar(191) DEFAULT NULL,
  `campaignId` bigint(20) DEFAULT NULL,
  `campaignName` varchar(191) DEFAULT NULL,
  `adGroupId` bigint(20) DEFAULT NULL,
  `adGroupName` varchar(191) DEFAULT NULL,
  `report_type` varchar(4) DEFAULT NULL,
  `adId` bigint(20) DEFAULT NULL,
  `asin` varchar(40) DEFAULT NULL,
  `sku` varchar(40) DEFAULT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `attributedConversions` int(11) DEFAULT NULL,
  `attributedConversionsSameSKU` int(11) DEFAULT NULL,
  `attributedUnitsOrdered` int(11) DEFAULT NULL,
  `attributedSales` decimal(19,2) DEFAULT NULL,
  `attributedSalesSameSKU` decimal(19,2) DEFAULT NULL,
  `attributedUnitsOrderedSameSKU` int(11) DEFAULT NULL,
  `reportDate` date DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65536 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_rtl_ams_profile` */

DROP TABLE IF EXISTS `tbl_rtl_ams_profile`;

CREATE TABLE `tbl_rtl_ams_profile` (
  `rtl_ams_profile` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) NOT NULL,
  `profile_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`rtl_ams_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=2048 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_inventory_master` */

DROP TABLE IF EXISTS `tbl_rtl_inventory_master`;

CREATE TABLE `tbl_rtl_inventory_master` (
  `rtl_inven_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) DEFAULT NULL,
  `asins` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillment_channel` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `seller_inv_units` int(11) DEFAULT NULL,
  `unseller_inv_units` int(11) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`rtl_inven_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_rtl_manager` */

DROP TABLE IF EXISTS `tbl_rtl_manager`;

CREATE TABLE `tbl_rtl_manager` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Manager_id` bigint(20) unsigned NOT NULL,
  `Brand_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Manager_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_rtl_product_catalog` */

DROP TABLE IF EXISTS `tbl_rtl_product_catalog`;

CREATE TABLE `tbl_rtl_product_catalog` (
  `tbl_pc_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) NOT NULL,
  `last_refresh` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ASIN` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillment_channel` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sc_status` tinyint(4) DEFAULT NULL,
  `vc_status` tinyint(4) DEFAULT NULL,
  `upc` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `release_date` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(9,4) DEFAULT NULL,
  `product_width` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_length` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_height` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_ship_weight` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `binding` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_group` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_asins` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `category_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `subcategory_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesrank` bigint(20) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`tbl_pc_id`),
  KEY `idx_rtl_sc` (`fk_account_id`,`ASIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_product_salesrank` */

DROP TABLE IF EXISTS `tbl_rtl_product_salesrank`;

CREATE TABLE `tbl_rtl_product_salesrank` (
  `tbl_sal_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) NOT NULL,
  `ASIN` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subcategory_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subcategory_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_rank` bigint(20) DEFAULT NULL,
  `batchid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`tbl_sal_id`),
  KEY `idx_rtl_sc` (`fk_account_id`,`ASIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_purchaseorder_master` */

DROP TABLE IF EXISTS `tbl_rtl_purchaseorder_master`;

CREATE TABLE `tbl_rtl_purchaseorder_master` (
  `rtl_po_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) DEFAULT NULL,
  `po` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hand_off_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ship_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asins` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `po_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_window_start` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_window_end` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `backorder` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expected_ship_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed_ship_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `case_size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_cases` int(11) DEFAULT NULL,
  `accepted_cases` int(11) DEFAULT NULL,
  `received_cases` int(11) DEFAULT NULL,
  `outstanding_cases` int(11) DEFAULT NULL,
  `str_case_cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `str_total_cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `case_cost` int(11) DEFAULT NULL,
  `total_cost` int(11) DEFAULT NULL,
  `accepted_case` int(11) DEFAULT NULL,
  `rejected_case` int(11) DEFAULT NULL,
  `total_po_cost` int(11) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`rtl_po_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_sale_master` */

DROP TABLE IF EXISTS `tbl_rtl_sale_master`;

CREATE TABLE `tbl_rtl_sale_master` (
  `rtl_sal_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) DEFAULT NULL,
  `ASIN` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fulfillment_channel` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sku` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipped_cogs` decimal(19,4) DEFAULT NULL,
  `shipped_unit` decimal(19,4) DEFAULT NULL,
  `shipped_cogs_last_year` decimal(19,4) DEFAULT NULL,
  `shipped_units_last_year` decimal(19,4) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`rtl_sal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_rtl_scraping` */

DROP TABLE IF EXISTS `tbl_rtl_scraping`;

CREATE TABLE `tbl_rtl_scraping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT NULL,
  `asin` varchar(50) DEFAULT NULL,
  `total_reviews` varchar(500) DEFAULT NULL,
  `reviews_count` int(10) unsigned DEFAULT NULL,
  `average_review` decimal(19,2) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `LoadDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1024 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_sc_activity_tracker` */

DROP TABLE IF EXISTS `tbl_sc_activity_tracker`;

CREATE TABLE `tbl_sc_activity_tracker` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `activity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cron_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19361 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_catalog_cat_active_report` */

DROP TABLE IF EXISTS `tbl_sc_catalog_cat_active_report`;

CREATE TABLE `tbl_sc_catalog_cat_active_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `itemDescription` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `listingId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sellerSku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `openDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageUrl` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemIsMarketplace` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productIdType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopShippingFee` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemNote` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemCondition` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopCategory1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopBrowsePath` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopStorefrontFeature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin2` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin3` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `willShipInternationally` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expeditedShipping` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopBoldface` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bidForFeaturedPlacement` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addDelete` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendingQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillmentChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchantShippingGroup` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_catalog_cat_inactive_report` */

DROP TABLE IF EXISTS `tbl_sc_catalog_cat_inactive_report`;

CREATE TABLE `tbl_sc_catalog_cat_inactive_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `itemDescription` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `listingId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sellerSku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `openDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageUrl` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemIsMarketplace` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productIdType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopShippingFee` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemNote` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemCondition` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopCategory1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopBrowsePath` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopStorefrontFeature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin2` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin3` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `willShipInternationally` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expeditedShipping` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopBoldface` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bidForFeaturedPlacement` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addDelete` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendingQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillmentChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchantShippingGroup` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_catalog_fba_health_report` */

DROP TABLE IF EXISTS `tbl_sc_catalog_fba_health_report`;

CREATE TABLE `tbl_sc_catalog_fba_health_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapshotDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fnsku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `condition` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesRank` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productGroup` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sellableQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unsellableQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge0To90Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge91To180Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge181To270Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge271To365Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge365PlusDays` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast24Hrs` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast7Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast30Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast90Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast180Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast365Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT7` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT30` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT90` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT180` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT365` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numAfnNewSellers` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numAfnUsedSellers` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `yourPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lowestAfnNewPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lowestAfnUsedPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lowestMfnNewPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lowestMfnUsedPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyToBeChargedlTsf12Mo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyInLongTermStorageProgram` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyWithRemovalsInProgress` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `projectedlTsf12Mo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `perUnitVolume` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isHazmat` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inBoundQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asinLimit` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inboundRecommendQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyToBeChargedlTsf6Mo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `projectedlTsf6Mo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_sc` (`fkBatchId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_config` */

DROP TABLE IF EXISTS `tbl_sc_config`;

CREATE TABLE `tbl_sc_config` (
  `mws_config_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mws_access_key_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mws_authtoken` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mws_secret_key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `historical_data_downloaded` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`mws_config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_crons` */

DROP TABLE IF EXISTS `tbl_sc_crons`;

CREATE TABLE `tbl_sc_crons` (
  `task_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cronStartTime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCronRunning` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `frequency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestReportTime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestReportLastRun` date DEFAULT NULL,
  `requestReportCompletedTime` timestamp NULL DEFAULT NULL,
  `requestReportLISTTime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestReportListLastRun` date DEFAULT NULL,
  `requestReportLISTCompletedTime` timestamp NULL DEFAULT NULL,
  `getReportTime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `getReportLastRun` date DEFAULT NULL,
  `getReportCompletedTime` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_failed_reports_request` */

DROP TABLE IF EXISTS `tbl_sc_failed_reports_request`;

CREATE TABLE `tbl_sc_failed_reports_request` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `errorCode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `httpStatusCode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apiType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sellerId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24520 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_fba_restock_report` */

DROP TABLE IF EXISTS `tbl_sc_fba_restock_report`;

CREATE TABLE `tbl_sc_fba_restock_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapshotDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FNSKU` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchant` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partNo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currencyCode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsSoldLast30Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalInventory` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inboundInventory` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `availableInventory` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recommendedOrderQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcTransfer` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcProcessing` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemPromotionDiscount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerOrder` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipCity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unfulfillable` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfilledBy` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `daysOfSupply` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instockAlert` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recommendedOrderQty` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recommendedOrderDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eligibleForStorageFeeDiscountCurrentMonth` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentMonthVeryLowInventoryThreshold` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentMonthStorageDiscountMinimumInventoryThreshold` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentMonthStorageDiscountMaximumInventoryThreshold` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentMonthVeryHighInventoryThreshold` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eligibleForStorageFeeDiscountNextMonth` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nextMonthStorageDiscountMinimumInventoryThreshold` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nextMonthStorageDiscountMaximumInventoryThreshold` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nextMonthVeryHighInventoryThreshold` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_inventory_cat_active_report` */

DROP TABLE IF EXISTS `tbl_sc_inventory_cat_active_report`;

CREATE TABLE `tbl_sc_inventory_cat_active_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `itemDescription` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `listingId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sellerSku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `openDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageUrl` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemIsMarketplace` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productIdType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopShippingFee` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemNote` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemCondition` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopCategory1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopBrowsePath` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopStorefrontFeature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin2` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin3` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `willShipInternationally` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expeditedShipping` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zshopBoldface` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bidForFeaturedPlacement` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addDelete` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendingQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillmentChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchantShippingGroup` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_sc` (`fkBatchId`,`fkAccountId`,`asin1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_inventory_fba_health_report` */

DROP TABLE IF EXISTS `tbl_sc_inventory_fba_health_report`;

CREATE TABLE `tbl_sc_inventory_fba_health_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapshotDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fnsku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `condition` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesRank` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productGroup` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sellableQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unsellableQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge0To90Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge91To180Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge181To270Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge271To365Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invAge365PlusDays` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast24Hrs` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast7Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast30Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast90Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast180Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitsShippedLast365Days` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT7` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT30` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT90` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT180` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weeksOfCoverT365` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numAfnNewSellers` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numAfnUsedSellers` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `yourPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lowestAfnNewPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lowestAfnUsedPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lowestMfnNewPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lowestMfnUsedPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyToBeChargedlTsf12Mo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyInLongTermStorageProgram` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyWithRemovalsInProgress` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `projectedlTsf12Mo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `perUnitVolume` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isHazmat` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inBoundQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asinLimit` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inboundRecommendQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyToBeChargedlTsf6Mo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `projectedlTsf6Mo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_sc` (`fkBatchId`,`fkAccountId`,`asin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_inventory_fba_receipt_report` */

DROP TABLE IF EXISTS `tbl_sc_inventory_fba_receipt_report`;

CREATE TABLE `tbl_sc_inventory_fba_receipt_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) NOT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receivedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fnsku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fbaShipmentId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillmentCenterId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_processed_sales_rank` */

DROP TABLE IF EXISTS `tbl_sc_processed_sales_rank`;

CREATE TABLE `tbl_sc_processed_sales_rank` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkProductTblId` int(11) DEFAULT NULL,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `source` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SC',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `fkSellerConfigId` int(11) DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productCategoryId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `productSubCategoryName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `productSubCategoryId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `productCategoryName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `salesRank` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_vc` (`fkAccountId`,`asin`,`createdAt`)
) ENGINE=InnoDB AUTO_INCREMENT=344863 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_product_category_details` */

DROP TABLE IF EXISTS `tbl_sc_product_category_details`;

CREATE TABLE `tbl_sc_product_category_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkProductTblId` int(11) DEFAULT NULL,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `source` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SC',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `fkSellerConfigId` int(11) DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productCategoryId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `productCategoryName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `categoryTreeSequence` int(11) DEFAULT NULL,
  `categoryTreeNumber` int(11) NOT NULL DEFAULT '1',
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_sc` (`categoryTreeSequence`,`categoryTreeNumber`,`productCategoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=65287 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_product_details` */

DROP TABLE IF EXISTS `tbl_sc_product_details`;

CREATE TABLE `tbl_sc_product_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkProductTblId` int(11) DEFAULT NULL,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `source` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SC',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `fkSellerConfigId` int(11) DEFAULT NULL,
  `marketplaceId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `binding` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `brand` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `color` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `department` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `itemHeight` decimal(8,2) NOT NULL DEFAULT '0.00',
  `itemLength` decimal(8,2) NOT NULL DEFAULT '0.00',
  `itemWidth` decimal(8,2) NOT NULL DEFAULT '0.00',
  `itemWeight` decimal(8,2) NOT NULL DEFAULT '0.00',
  `itemLabel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `itemAmount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `currencyCode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `manufacturer` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `materialType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `model` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `numberOfItems` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `packageHeight` decimal(8,2) NOT NULL DEFAULT '0.00',
  `packageLength` decimal(8,2) NOT NULL DEFAULT '0.00',
  `packageWidth` decimal(8,2) NOT NULL DEFAULT '0.00',
  `packageWeight` decimal(8,2) NOT NULL DEFAULT '0.00',
  `packageQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `partNumber` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `productGroup` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `productTypeName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `publisher` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `releaseDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `size` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `smallImageURL` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `smallImageHeight` decimal(8,2) NOT NULL DEFAULT '0.00',
  `smallImageWidth` decimal(8,2) NOT NULL DEFAULT '0.00',
  `studio` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `warranty` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `parentAsinMarketplaceId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `parentAsin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `isAdultProduct` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `isAutographed` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `isMemorabilia` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `platform` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `publicationDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `manufacturerMaximumAge` decimal(8,2) NOT NULL DEFAULT '0.00',
  `manufacturerMinimumAge` decimal(8,2) NOT NULL DEFAULT '0.00',
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_sc` (`fkAccountId`,`asin`)
) ENGINE=InnoDB AUTO_INCREMENT=330658 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_product_ids` */

DROP TABLE IF EXISTS `tbl_sc_product_ids`;

CREATE TABLE `tbl_sc_product_ids` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkSellerConfigId` int(11) DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productDetailsDownloaded` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `productDetailsInQueue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `productCategoryDetailsDownloaded` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `productCategoryDetailsInQueue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `productSalesRankCoppied` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `source` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8520 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_requested_reports` */

DROP TABLE IF EXISTS `tbl_sc_requested_reports`;

CREATE TABLE `tbl_sc_requested_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fk_merchant_id` bigint(20) DEFAULT NULL,
  `ReportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ReportType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metricsType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` date DEFAULT NULL,
  `StartDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EndDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazonStartDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazonEndDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SubmittedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ReportProcessingStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GeneratedReportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Acknowledged` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_acknowledgement` enum('false','true','no_data') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'false',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_sales_fba_returns_report` */

DROP TABLE IF EXISTS `tbl_sc_sales_fba_returns_report`;

CREATE TABLE `tbl_sc_sales_fba_returns_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `returnDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fnsku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillmentCenterId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detailedDisposition` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licensePlateNumber` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerComments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_sales_mfn_returns_report` */

DROP TABLE IF EXISTS `tbl_sc_sales_mfn_returns_report`;

CREATE TABLE `tbl_sc_sales_mfn_returns_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `returnRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `returnRequestStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazonRmaId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchantRmaId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `labelType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `labelCost` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currencyCode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `returnCarrier` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trackingId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `labelToBePaidBy` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aToZClaim` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isPrime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchantSku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `returnQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shippingPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `returnReason` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inPolicy` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `returnType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolution` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoiceNumber` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `returnDeliveryDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderAmount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderQuantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `safeTActionReason` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `safeTClaimId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `safeTClaimState` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `safeTClaimCreationTime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `safeTClaimReimbursementAmount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refundedAmount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_sales_orders_report` */

DROP TABLE IF EXISTS `tbl_sc_sales_orders_report`;

CREATE TABLE `tbl_sc_sales_orders_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazonOrderId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchantOrderId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchaseDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastUpdatedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillmentChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipServiceLevel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemTax` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shippingPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shippingTax` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `giftWrapPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `giftWrapTax` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemPromotionDiscount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipPromotionDiscount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipCity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipState` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipPostalCode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipCountry` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `promotionIds` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_sales_orders_updt_report` */

DROP TABLE IF EXISTS `tbl_sc_sales_orders_updt_report`;

CREATE TABLE `tbl_sc_sales_orders_updt_report` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkRequestId` int(11) DEFAULT NULL,
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportRequestDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazonOrderId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchantOrderId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchaseDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastUpdatedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fulfillmentChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderChannel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipServiceLevel` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemTax` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shippingPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shippingTax` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `giftWrapPrice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `giftWrapTax` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemPromotionDiscount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipPromotionDiscount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipCity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipState` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipPostalCode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipCountry` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `promotionIds` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_sc` (`fkBatchId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_sc_sales_rank` */

DROP TABLE IF EXISTS `tbl_sc_sales_rank`;

CREATE TABLE `tbl_sc_sales_rank` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkProductTblId` int(11) DEFAULT NULL,
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `source` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SC',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `fkSellerConfigId` int(11) DEFAULT NULL,
  `asin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productCategoryId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `salesRank` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `salesRankCount` int(11) DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=681054 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_schedule_cron` */

DROP TABLE IF EXISTS `tbl_schedule_cron`;

CREATE TABLE `tbl_schedule_cron` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_id` int(10) unsigned NOT NULL,
  `cronStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastRun` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cronDuration` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `isRunning` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_scraping_activity_tracker` */

DROP TABLE IF EXISTS `tbl_scraping_activity_tracker`;

CREATE TABLE `tbl_scraping_activity_tracker` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `activity` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `activity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NA',
  `cron_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NA',
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NA',
  `activity_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27992947 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_search_rank_crawler` */

DROP TABLE IF EXISTS `tbl_search_rank_crawler`;

CREATE TABLE `tbl_search_rank_crawler` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `d_id` int(10) unsigned NOT NULL,
  `c_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `c_frequency` int(10) unsigned NOT NULL,
  `c_lastRun` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `c_nextRun` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `isRunning` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_search_rank_department` */

DROP TABLE IF EXISTS `tbl_search_rank_department`;

CREATE TABLE `tbl_search_rank_department` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `d_name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `d_alias` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_search_rank_fail_statuses` */

DROP TABLE IF EXISTS `tbl_search_rank_fail_statuses`;

CREATE TABLE `tbl_search_rank_fail_statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `failed_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  `crawler_id` int(10) unsigned NOT NULL,
  `isNew` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_search_rank_scraped_result` */

DROP TABLE IF EXISTS `tbl_search_rank_scraped_result`;

CREATE TABLE `tbl_search_rank_scraped_result` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_id` int(10) unsigned NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `proxyIp` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `brand` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `pageNo` int(10) unsigned NOT NULL,
  `offerPriceOrignal` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `offerPrice` decimal(10,2) DEFAULT NULL,
  `listPriceOrignal` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `listPrice` decimal(10,2) DEFAULT NULL,
  `offerCount` int(10) unsigned NOT NULL DEFAULT '0',
  `isSponsered` tinyint(1) NOT NULL DEFAULT '0',
  `isPromo` tinyint(1) NOT NULL DEFAULT '0',
  `isBestSeller` tinyint(1) NOT NULL DEFAULT '0',
  `isAmazonChoice` tinyint(1) NOT NULL DEFAULT '0',
  `isPrime` tinyint(1) NOT NULL DEFAULT '0',
  `reviewCount` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `reviewScore` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `created_at` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_search_rank_temp_urls` */

DROP TABLE IF EXISTS `tbl_search_rank_temp_urls`;

CREATE TABLE `tbl_search_rank_temp_urls` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `department_id` int(10) unsigned NOT NULL,
  `searchTerm_id` int(10) unsigned NOT NULL,
  `searchRankUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pageNo` smallint(5) unsigned NOT NULL,
  `urlStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `allocatedThread` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `created_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_search_terms` */

DROP TABLE IF EXISTS `tbl_search_terms`;

CREATE TABLE `tbl_search_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `crawler_id` int(10) unsigned NOT NULL,
  `st_term` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `st_alias` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `st_url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_settings` */

DROP TABLE IF EXISTS `tbl_settings`;

CREATE TABLE `tbl_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_stage_vc_daily_forecast` */

DROP TABLE IF EXISTS `tbl_stage_vc_daily_forecast`;

CREATE TABLE `tbl_stage_vc_daily_forecast` (
  `daily_forecast_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkCategoryId` bigint(20) NOT NULL DEFAULT '0',
  `subcategory` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rep_oos` double(20,2) NOT NULL,
  `rep_oos_percentage_total` double(20,2) NOT NULL,
  `rep_oos_prior_period` double(20,2) NOT NULL,
  `shipped_units` bigint(20) NOT NULL,
  `shipped_units_prior_period` double(20,2) NOT NULL,
  `unfilled_customer_ordered_units` bigint(20) NOT NULL,
  `available_inventory` bigint(20) NOT NULL,
  `available_inventory_prior_period` double(20,2) NOT NULL,
  `weeks_on_hand` bigint(20) NOT NULL,
  `open_purchase_order_quantity` bigint(20) NOT NULL,
  `open_purchase_order_quantity_prior_period` double(20,2) NOT NULL,
  `receive_fill_rate` double(20,2) NOT NULL,
  `overall_vendor_lead_time_days` double(20,2) NOT NULL,
  `replenishment_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `week_1_mean_forecast` double(20,2) NOT NULL,
  `week_2_mean_forecast` double(20,2) NOT NULL,
  `week_3_mean_forecast` double(20,2) NOT NULL,
  `week_4_mean_forecast` double(20,2) NOT NULL,
  `week_5_mean_forecast` double(20,2) NOT NULL,
  `week_6_mean_forecast` double(20,2) NOT NULL,
  `week_7_mean_forecast` double(20,2) NOT NULL,
  `week_8_mean_forecast` double(20,2) NOT NULL,
  `week_9_mean_forecast` double(20,2) NOT NULL,
  `week_10_mean_forecast` double(20,2) NOT NULL,
  `week_11_mean_forecast` double(20,2) NOT NULL,
  `week_12_mean_forecast` double(20,2) NOT NULL,
  `week_13_mean_forecast` double(20,2) NOT NULL,
  `week_14_mean_forecast` double(20,2) NOT NULL,
  `week_15_mean_forecast` double(20,2) NOT NULL,
  `week_16_mean_forecast` double(20,2) NOT NULL,
  `week_17_mean_forecast` double(20,2) NOT NULL,
  `week_18_mean_forecast` double(20,2) NOT NULL,
  `week_19_mean_forecast` double(20,2) NOT NULL,
  `week_20_mean_forecast` double(20,2) NOT NULL,
  `week_21_mean_forecast` double(20,2) NOT NULL,
  `week_22_mean_forecast` double(20,2) NOT NULL,
  `week_23_mean_forecast` double(20,2) NOT NULL,
  `week_24_mean_forecast` double(20,2) NOT NULL,
  `week_25_mean_forecast` double(20,2) NOT NULL,
  `week_26_mean_forecast` double(20,2) NOT NULL,
  `week_1_p70_forecast` double(20,2) NOT NULL,
  `week_2_p70_forecast` double(20,2) NOT NULL,
  `week_3_p70_forecast` double(20,2) NOT NULL,
  `week_4_p70_forecast` double(20,2) NOT NULL,
  `week_5_p70_forecast` double(20,2) NOT NULL,
  `week_6_p70_forecast` double(20,2) NOT NULL,
  `week_7_p70_forecast` double(20,2) NOT NULL,
  `week_8_p70_forecast` double(20,2) NOT NULL,
  `week_9_p70_forecast` double(20,2) NOT NULL,
  `week_10_p70_forecast` double(20,2) NOT NULL,
  `week_11_p70_forecast` double(20,2) NOT NULL,
  `week_12_p70_forecast` double(20,2) NOT NULL,
  `week_13_p70_forecast` double(20,2) NOT NULL,
  `week_14_p70_forecast` double(20,2) NOT NULL,
  `week_15_p70_forecast` double(20,2) NOT NULL,
  `week_16_p70_forecast` double(20,2) NOT NULL,
  `week_17_p70_forecast` double(20,2) NOT NULL,
  `week_18_p70_forecast` double(20,2) NOT NULL,
  `week_19_p70_forecast` double(20,2) NOT NULL,
  `week_20_p70_forecast` double(20,2) NOT NULL,
  `week_21_p70_forecast` double(20,2) NOT NULL,
  `week_22_p70_forecast` double(20,2) NOT NULL,
  `week_23_p70_forecast` double(20,2) NOT NULL,
  `week_24_p70_forecast` double(20,2) NOT NULL,
  `week_25_p70_forecast` double(20,2) NOT NULL,
  `week_26_p70_forecast` double(20,2) NOT NULL,
  `week_1_p80_forecast` double(20,2) NOT NULL,
  `week_2_p80_forecast` double(20,2) NOT NULL,
  `week_3_p80_forecast` double(20,2) NOT NULL,
  `week_4_p80_forecast` double(20,2) NOT NULL,
  `week_5_p80_forecast` double(20,2) NOT NULL,
  `week_6_p80_forecast` double(20,2) NOT NULL,
  `week_7_p80_forecast` double(20,2) NOT NULL,
  `week_8_p80_forecast` double(20,2) NOT NULL,
  `week_9_p80_forecast` double(20,2) NOT NULL,
  `week_10_p80_forecast` double(20,2) NOT NULL,
  `week_11_p80_forecast` double(20,2) NOT NULL,
  `week_12_p80_forecast` double(20,2) NOT NULL,
  `week_13_p80_forecast` double(20,2) NOT NULL,
  `week_14_p80_forecast` double(20,2) NOT NULL,
  `week_15_p80_forecast` double(20,2) NOT NULL,
  `week_16_p80_forecast` double(20,2) NOT NULL,
  `week_17_p80_forecast` double(20,2) NOT NULL,
  `week_18_p80_forecast` double(20,2) NOT NULL,
  `week_19_p80_forecast` double(20,2) NOT NULL,
  `week_20_p80_forecast` double(20,2) NOT NULL,
  `week_21_p80_forecast` double(20,2) NOT NULL,
  `week_22_p80_forecast` double(20,2) NOT NULL,
  `week_23_p80_forecast` double(20,2) NOT NULL,
  `week_24_p80_forecast` double(20,2) NOT NULL,
  `week_25_p80_forecast` double(20,2) NOT NULL,
  `week_26_p80_forecast` double(20,2) NOT NULL,
  `week_1_p90_forecast` double(20,2) NOT NULL,
  `week_2_p90_forecast` double(20,2) NOT NULL,
  `week_3_p90_forecast` double(20,2) NOT NULL,
  `week_4_p90_forecast` double(20,2) NOT NULL,
  `week_5_p90_forecast` double(20,2) NOT NULL,
  `week_6_p90_forecast` double(20,2) NOT NULL,
  `week_7_p90_forecast` double(20,2) NOT NULL,
  `week_8_p90_forecast` double(20,2) NOT NULL,
  `week_9_p90_forecast` double(20,2) NOT NULL,
  `week_10_p90_forecast` double(20,2) NOT NULL,
  `week_11_p90_forecast` double(20,2) NOT NULL,
  `week_12_p90_forecast` double(20,2) NOT NULL,
  `week_13_p90_forecast` double(20,2) NOT NULL,
  `week_14_p90_forecast` double(20,2) NOT NULL,
  `week_15_p90_forecast` double(20,2) NOT NULL,
  `week_16_p90_forecast` double(20,2) NOT NULL,
  `week_17_p90_forecast` double(20,2) NOT NULL,
  `week_18_p90_forecast` double(20,2) NOT NULL,
  `week_19_p90_forecast` double(20,2) NOT NULL,
  `week_20_p90_forecast` double(20,2) NOT NULL,
  `week_21_p90_forecast` double(20,2) NOT NULL,
  `week_22_p90_forecast` double(20,2) NOT NULL,
  `week_23_p90_forecast` double(20,2) NOT NULL,
  `week_24_p90_forecast` double(20,2) NOT NULL,
  `week_25_p90_forecast` double(20,2) NOT NULL,
  `week_26_p90_forecast` double(20,2) NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`daily_forecast_id`)
) ENGINE=InnoDB AUTO_INCREMENT=698458 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_stage_vc_daily_inventory` */

DROP TABLE IF EXISTS `tbl_stage_vc_daily_inventory`;

CREATE TABLE `tbl_stage_vc_daily_inventory` (
  `daily_inventory_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkCategoryId` bigint(20) NOT NULL DEFAULT '0',
  `subcategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `net_recieved` double(20,2) NOT NULL,
  `net_revieved_units` bigint(20) NOT NULL,
  `sell_through_rate` double(20,2) NOT NULL,
  `open_purchase_order_quantity` bigint(20) NOT NULL,
  `sellable_on_hand_inventory` double(20,2) NOT NULL,
  `sellable_on_hand_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `sellable_on_hand_units` bigint(20) NOT NULL,
  `unsellable_on_hand_inventory` double(20,2) NOT NULL,
  `unsellable_on_hand_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `unsellable_on_hand_units` bigint(20) NOT NULL,
  `aged_90_days_sellable_inventory` double(20,2) NOT NULL,
  `aged_90+_days_sellable_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `aged_90_days_sellable_units` bigint(20) NOT NULL,
  `unhealthy_inventory` double(20,2) NOT NULL,
  `unhealthy_inventory_trailing_30day_average` double(20,2) NOT NULL,
  `unhealthy_units` bigint(20) NOT NULL,
  `replenishment_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rec_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`daily_inventory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=662707 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_stage_vc_daily_sales` */

DROP TABLE IF EXISTS `tbl_stage_vc_daily_sales`;

CREATE TABLE `tbl_stage_vc_daily_sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkCategoryId` bigint(20) NOT NULL DEFAULT '0',
  `subcategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipped_cogs` double(20,2) NOT NULL,
  `shipped_cogs_percentage_total` double(20,2) NOT NULL,
  `shipped_cogs_prior_period` double(20,2) NOT NULL,
  `shipped_cogs_last_year` double(20,2) NOT NULL,
  `shipped_units` bigint(20) NOT NULL,
  `shipped_units_percentage_total` double(20,2) NOT NULL,
  `shipped_units_prior_period` double(20,2) NOT NULL,
  `shipped_units_last_year` double(20,2) NOT NULL,
  `units_percentage_total` double(20,2) NOT NULL,
  `customer_returns` bigint(20) NOT NULL,
  `free_replacements` bigint(20) NOT NULL,
  `average_sales_price` double(20,2) NOT NULL,
  `average_sales_price_prior_period` double(20,2) NOT NULL,
  `sale_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=555008 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_stage_vc_product_catalog` */

DROP TABLE IF EXISTS `tbl_stage_vc_product_catalog`;

CREATE TABLE `tbl_stage_vc_product_catalog` (
  `product_catalog_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isbn13` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ean` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `upc` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `release_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `binding` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `list_price` double(20,2) NOT NULL,
  `author_artist` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sitbenabled` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apparel_size` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apparel_size_width` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_group` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `replenishment_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_style_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `colour` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `colour_count` bigint(20) NOT NULL,
  `prep_instructions_required` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prep_instructions_vendor_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_manufacturer_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_catalog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=930061 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_stage_vc_purchaseorders` */

DROP TABLE IF EXISTS `tbl_stage_vc_purchaseorders`;

CREATE TABLE `tbl_stage_vc_purchaseorders` (
  `po_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `po` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_to_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `availability` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `externalid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ack_code_translation_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hand_off_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_window_start` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_window_end` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `backorder` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expected_delivery_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed_delivery_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_size` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `accepted_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `outstanding_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderon_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_cost` double(20,2) NOT NULL,
  `total_cost` double(20,2) NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`po_id`)
) ENGINE=InnoDB AUTO_INCREMENT=218352 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_stage_vc_weekly_traffic_summary` */

DROP TABLE IF EXISTS `tbl_stage_vc_weekly_traffic_summary`;

CREATE TABLE `tbl_stage_vc_weekly_traffic_summary` (
  `traffic_summary_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_glance_view_reported` double(20,2) NOT NULL,
  `change_glance_view_prior_period` double(20,2) NOT NULL,
  `change_glance_view_last_year` double(20,2) NOT NULL,
  `change_conversion_reported` double(20,2) NOT NULL,
  `change_conversion_prior_period` double(20,2) NOT NULL,
  `change_conversion_last_year` double(20,2) NOT NULL,
  `change_unique_visitors_reported` double(20,2) NOT NULL,
  `change_unique_visitors_prior_period` double(20,2) NOT NULL,
  `change_unique_visitors_last_year` double(20,2) NOT NULL,
  `fast_track_glance_view_reported` double(20,2) NOT NULL,
  `fast_track_glance_view_prior_period` double(20,2) NOT NULL,
  `fast_track_glance_view_last_year` double(20,2) NOT NULL,
  `fast_track_glance_view` double(20,2) NOT NULL,
  `conversion_percentile` double(20,2) NOT NULL,
  `percentage_total_gvs` double(20,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`traffic_summary_id`)
) ENGINE=InnoDB AUTO_INCREMENT=134025 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_tacos_cron` */

DROP TABLE IF EXISTS `tbl_tacos_cron`;

CREATE TABLE `tbl_tacos_cron` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkTacosId` bigint(20) NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsoredType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriodDays` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  `isData` tinyint(1) NOT NULL DEFAULT '0',
  `runStatus` tinyint(1) NOT NULL DEFAULT '0',
  `checkRule` tinyint(1) NOT NULL DEFAULT '0',
  `ruleResult` tinyint(1) NOT NULL DEFAULT '0',
  `currentRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nextRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emailSent` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=261 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_tacos_list` */

DROP TABLE IF EXISTS `tbl_tacos_list`;

CREATE TABLE `tbl_tacos_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profileId` bigint(20) unsigned NOT NULL,
  `campaignId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tacos` double(5,2) NOT NULL DEFAULT '0.00',
  `min` double(5,2) NOT NULL DEFAULT '0.00',
  `max` double(6,2) NOT NULL DEFAULT '0.00',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `userID` bigint(20) unsigned NOT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_tacos_list_activity_tracker` */

DROP TABLE IF EXISTS `tbl_tacos_list_activity_tracker`;

CREATE TABLE `tbl_tacos_list_activity_tracker` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkTacosId` bigint(20) unsigned NOT NULL,
  `profileId` bigint(20) unsigned NOT NULL,
  `campaignId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tacos` double(5,2) NOT NULL DEFAULT '0.00',
  `min` double(5,2) NOT NULL DEFAULT '0.00',
  `max` double(6,2) NOT NULL DEFAULT '0.00',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `userID` bigint(20) unsigned NOT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_user_actions` */

DROP TABLE IF EXISTS `tbl_user_actions`;

CREATE TABLE `tbl_user_actions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `actionName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_user_roles` */

DROP TABLE IF EXISTS `tbl_user_roles`;

CREATE TABLE `tbl_user_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `roleId` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_all_availability_scrap` */

DROP TABLE IF EXISTS `tbl_vc_all_availability_scrap`;

CREATE TABLE `tbl_vc_all_availability_scrap` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `upc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendorCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastModifiedDate` date NOT NULL,
  `cost` double(8,2) NOT NULL,
  `available` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkVendorGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `offset` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_cron_list` */

DROP TABLE IF EXISTS `tbl_vc_cron_list`;

CREATE TABLE `tbl_vc_cron_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `moduleName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isDoneModuleData` bigint(20) NOT NULL,
  `isRunned` bigint(20) NOT NULL,
  `isFailed` bigint(20) NOT NULL,
  `isSuccess` bigint(20) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_daily_forecast` */

DROP TABLE IF EXISTS `tbl_vc_daily_forecast`;

CREATE TABLE `tbl_vc_daily_forecast` (
  `daily_forecast_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkCategoryId` bigint(20) NOT NULL DEFAULT '0',
  `subcategory` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rep_oos` double(20,2) NOT NULL,
  `rep_oos_percentage_total` double(20,2) NOT NULL,
  `rep_oos_prior_period` double(20,2) NOT NULL,
  `shipped_units` bigint(20) NOT NULL,
  `shipped_units_prior_period` double(20,2) NOT NULL,
  `unfilled_customer_ordered_units` bigint(20) NOT NULL,
  `available_inventory` bigint(20) NOT NULL,
  `available_inventory_prior_period` double(20,2) NOT NULL,
  `weeks_on_hand` bigint(20) NOT NULL,
  `open_purchase_order_quantity` bigint(20) NOT NULL,
  `open_purchase_order_quantity_prior_period` double(20,2) NOT NULL,
  `receive_fill_rate` double(20,2) NOT NULL,
  `overall_vendor_lead_time_days` double(20,2) NOT NULL,
  `replenishment_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `week_1_mean_forecast` double(20,2) NOT NULL,
  `week_2_mean_forecast` double(20,2) NOT NULL,
  `week_3_mean_forecast` double(20,2) NOT NULL,
  `week_4_mean_forecast` double(20,2) NOT NULL,
  `week_5_mean_forecast` double(20,2) NOT NULL,
  `week_6_mean_forecast` double(20,2) NOT NULL,
  `week_7_mean_forecast` double(20,2) NOT NULL,
  `week_8_mean_forecast` double(20,2) NOT NULL,
  `week_9_mean_forecast` double(20,2) NOT NULL,
  `week_10_mean_forecast` double(20,2) NOT NULL,
  `week_11_mean_forecast` double(20,2) NOT NULL,
  `week_12_mean_forecast` double(20,2) NOT NULL,
  `week_13_mean_forecast` double(20,2) NOT NULL,
  `week_14_mean_forecast` double(20,2) NOT NULL,
  `week_15_mean_forecast` double(20,2) NOT NULL,
  `week_16_mean_forecast` double(20,2) NOT NULL,
  `week_17_mean_forecast` double(20,2) NOT NULL,
  `week_18_mean_forecast` double(20,2) NOT NULL,
  `week_19_mean_forecast` double(20,2) NOT NULL,
  `week_20_mean_forecast` double(20,2) NOT NULL,
  `week_21_mean_forecast` double(20,2) NOT NULL,
  `week_22_mean_forecast` double(20,2) NOT NULL,
  `week_23_mean_forecast` double(20,2) NOT NULL,
  `week_24_mean_forecast` double(20,2) NOT NULL,
  `week_25_mean_forecast` double(20,2) NOT NULL,
  `week_26_mean_forecast` double(20,2) NOT NULL,
  `week_1_p70_forecast` double(20,2) NOT NULL,
  `week_2_p70_forecast` double(20,2) NOT NULL,
  `week_3_p70_forecast` double(20,2) NOT NULL,
  `week_4_p70_forecast` double(20,2) NOT NULL,
  `week_5_p70_forecast` double(20,2) NOT NULL,
  `week_6_p70_forecast` double(20,2) NOT NULL,
  `week_7_p70_forecast` double(20,2) NOT NULL,
  `week_8_p70_forecast` double(20,2) NOT NULL,
  `week_9_p70_forecast` double(20,2) NOT NULL,
  `week_10_p70_forecast` double(20,2) NOT NULL,
  `week_11_p70_forecast` double(20,2) NOT NULL,
  `week_12_p70_forecast` double(20,2) NOT NULL,
  `week_13_p70_forecast` double(20,2) NOT NULL,
  `week_14_p70_forecast` double(20,2) NOT NULL,
  `week_15_p70_forecast` double(20,2) NOT NULL,
  `week_16_p70_forecast` double(20,2) NOT NULL,
  `week_17_p70_forecast` double(20,2) NOT NULL,
  `week_18_p70_forecast` double(20,2) NOT NULL,
  `week_19_p70_forecast` double(20,2) NOT NULL,
  `week_20_p70_forecast` double(20,2) NOT NULL,
  `week_21_p70_forecast` double(20,2) NOT NULL,
  `week_22_p70_forecast` double(20,2) NOT NULL,
  `week_23_p70_forecast` double(20,2) NOT NULL,
  `week_24_p70_forecast` double(20,2) NOT NULL,
  `week_25_p70_forecast` double(20,2) NOT NULL,
  `week_26_p70_forecast` double(20,2) NOT NULL,
  `week_1_p80_forecast` double(20,2) NOT NULL,
  `week_2_p80_forecast` double(20,2) NOT NULL,
  `week_3_p80_forecast` double(20,2) NOT NULL,
  `week_4_p80_forecast` double(20,2) NOT NULL,
  `week_5_p80_forecast` double(20,2) NOT NULL,
  `week_6_p80_forecast` double(20,2) NOT NULL,
  `week_7_p80_forecast` double(20,2) NOT NULL,
  `week_8_p80_forecast` double(20,2) NOT NULL,
  `week_9_p80_forecast` double(20,2) NOT NULL,
  `week_10_p80_forecast` double(20,2) NOT NULL,
  `week_11_p80_forecast` double(20,2) NOT NULL,
  `week_12_p80_forecast` double(20,2) NOT NULL,
  `week_13_p80_forecast` double(20,2) NOT NULL,
  `week_14_p80_forecast` double(20,2) NOT NULL,
  `week_15_p80_forecast` double(20,2) NOT NULL,
  `week_16_p80_forecast` double(20,2) NOT NULL,
  `week_17_p80_forecast` double(20,2) NOT NULL,
  `week_18_p80_forecast` double(20,2) NOT NULL,
  `week_19_p80_forecast` double(20,2) NOT NULL,
  `week_20_p80_forecast` double(20,2) NOT NULL,
  `week_21_p80_forecast` double(20,2) NOT NULL,
  `week_22_p80_forecast` double(20,2) NOT NULL,
  `week_23_p80_forecast` double(20,2) NOT NULL,
  `week_24_p80_forecast` double(20,2) NOT NULL,
  `week_25_p80_forecast` double(20,2) NOT NULL,
  `week_26_p80_forecast` double(20,2) NOT NULL,
  `week_1_p90_forecast` double(20,2) NOT NULL,
  `week_2_p90_forecast` double(20,2) NOT NULL,
  `week_3_p90_forecast` double(20,2) NOT NULL,
  `week_4_p90_forecast` double(20,2) NOT NULL,
  `week_5_p90_forecast` double(20,2) NOT NULL,
  `week_6_p90_forecast` double(20,2) NOT NULL,
  `week_7_p90_forecast` double(20,2) NOT NULL,
  `week_8_p90_forecast` double(20,2) NOT NULL,
  `week_9_p90_forecast` double(20,2) NOT NULL,
  `week_10_p90_forecast` double(20,2) NOT NULL,
  `week_11_p90_forecast` double(20,2) NOT NULL,
  `week_12_p90_forecast` double(20,2) NOT NULL,
  `week_13_p90_forecast` double(20,2) NOT NULL,
  `week_14_p90_forecast` double(20,2) NOT NULL,
  `week_15_p90_forecast` double(20,2) NOT NULL,
  `week_16_p90_forecast` double(20,2) NOT NULL,
  `week_17_p90_forecast` double(20,2) NOT NULL,
  `week_18_p90_forecast` double(20,2) NOT NULL,
  `week_19_p90_forecast` double(20,2) NOT NULL,
  `week_20_p90_forecast` double(20,2) NOT NULL,
  `week_21_p90_forecast` double(20,2) NOT NULL,
  `week_22_p90_forecast` double(20,2) NOT NULL,
  `week_23_p90_forecast` double(20,2) NOT NULL,
  `week_24_p90_forecast` double(20,2) NOT NULL,
  `week_25_p90_forecast` double(20,2) NOT NULL,
  `week_26_p90_forecast` double(20,2) NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`daily_forecast_id`)
) ENGINE=InnoDB AUTO_INCREMENT=995650 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_daily_inventory` */

DROP TABLE IF EXISTS `tbl_vc_daily_inventory`;

CREATE TABLE `tbl_vc_daily_inventory` (
  `daily_inventory_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkCategoryId` bigint(20) NOT NULL DEFAULT '0',
  `subcategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `net_recieved` double(20,2) NOT NULL,
  `net_revieved_units` bigint(20) NOT NULL,
  `sell_through_rate` double(20,2) NOT NULL,
  `open_purchase_order_quantity` bigint(20) NOT NULL,
  `sellable_on_hand_inventory` double(20,2) NOT NULL,
  `sellable_on_hand_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `sellable_on_hand_units` bigint(20) NOT NULL,
  `unsellable_on_hand_inventory` double(20,2) NOT NULL,
  `unsellable_on_hand_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `unsellable_on_hand_units` bigint(20) NOT NULL,
  `aged_90_days_sellable_inventory` double(20,2) NOT NULL,
  `aged_90+_days_sellable_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `aged_90_days_sellable_units` bigint(20) NOT NULL,
  `unhealthy_inventory` double(20,2) NOT NULL,
  `unhealthy_inventory_trailing_30day_average` double(20,2) NOT NULL,
  `unhealthy_units` bigint(20) NOT NULL,
  `replenishment_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rec_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`daily_inventory_id`),
  KEY `idx_rtl_vc` (`batchId`)
) ENGINE=InnoDB AUTO_INCREMENT=994100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_daily_inventory_updt` */

DROP TABLE IF EXISTS `tbl_vc_daily_inventory_updt`;

CREATE TABLE `tbl_vc_daily_inventory_updt` (
  `daily_inventory_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkCategoryId` bigint(20) NOT NULL DEFAULT '0',
  `subcategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `net_recieved` double(20,2) NOT NULL,
  `net_revieved_units` bigint(20) NOT NULL,
  `sell_through_rate` double(20,2) NOT NULL,
  `open_purchase_order_quantity` bigint(20) NOT NULL,
  `sellable_on_hand_inventory` double(20,2) NOT NULL,
  `sellable_on_hand_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `sellable_on_hand_units` bigint(20) NOT NULL,
  `unsellable_on_hand_inventory` double(20,2) NOT NULL,
  `unsellable_on_hand_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `unsellable_on_hand_units` bigint(20) NOT NULL,
  `aged_90_days_sellable_inventory` double(20,2) NOT NULL,
  `aged_90+_days_sellable_inventory_trailing_30_day_average` double(20,2) NOT NULL,
  `aged_90_days_sellable_units` bigint(20) NOT NULL,
  `unhealthy_inventory` double(20,2) NOT NULL,
  `unhealthy_inventory_trailing_30day_average` double(20,2) NOT NULL,
  `unhealthy_units` bigint(20) NOT NULL,
  `replenishment_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rec_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`daily_inventory_id`),
  KEY `idx_rtl_vc` (`batchId`)
) ENGINE=InnoDB AUTO_INCREMENT=7112521763 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_daily_sales` */

DROP TABLE IF EXISTS `tbl_vc_daily_sales`;

CREATE TABLE `tbl_vc_daily_sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkCategoryId` bigint(20) NOT NULL DEFAULT '0',
  `subcategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipped_cogs` double(20,2) NOT NULL,
  `shipped_cogs_percentage_total` double(20,2) NOT NULL,
  `shipped_cogs_prior_period` double(20,2) NOT NULL,
  `shipped_cogs_last_year` double(20,2) NOT NULL,
  `shipped_units` bigint(20) NOT NULL,
  `shipped_units_percentage_total` double(20,2) NOT NULL,
  `shipped_units_prior_period` double(20,2) NOT NULL,
  `shipped_units_last_year` double(20,2) NOT NULL,
  `units_percentage_total` double(20,2) NOT NULL,
  `customer_returns` bigint(20) NOT NULL,
  `free_replacements` bigint(20) NOT NULL,
  `average_sales_price` double(20,2) NOT NULL,
  `average_sales_price_prior_period` double(20,2) NOT NULL,
  `sale_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_vc` (`batchId`)
) ENGINE=InnoDB AUTO_INCREMENT=813873 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_daily_sales_updt` */

DROP TABLE IF EXISTS `tbl_vc_daily_sales_updt`;

CREATE TABLE `tbl_vc_daily_sales_updt` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkCategoryId` bigint(20) NOT NULL DEFAULT '0',
  `subcategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipped_cogs` double(20,2) NOT NULL,
  `shipped_cogs_percentage_total` double(20,2) NOT NULL,
  `shipped_cogs_prior_period` double(20,2) NOT NULL,
  `shipped_cogs_last_year` double(20,2) NOT NULL,
  `shipped_units` bigint(20) NOT NULL,
  `shipped_units_percentage_total` double(20,2) NOT NULL,
  `shipped_units_prior_period` double(20,2) NOT NULL,
  `shipped_units_last_year` double(20,2) NOT NULL,
  `units_percentage_total` double(20,2) NOT NULL,
  `customer_returns` bigint(20) NOT NULL,
  `free_replacements` bigint(20) NOT NULL,
  `average_sales_price` double(20,2) NOT NULL,
  `average_sales_price_prior_period` double(20,2) NOT NULL,
  `sale_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rtl_vc` (`batchId`)
) ENGINE=InnoDB AUTO_INCREMENT=6018517381 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_look_up_availability_scrap` */

DROP TABLE IF EXISTS `tbl_vc_look_up_availability_scrap`;

CREATE TABLE `tbl_vc_look_up_availability_scrap` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `upc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendorCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastModifiedDate` date NOT NULL,
  `cost` double(8,2) NOT NULL,
  `available` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkVendorGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `offset` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_product_catalog` */

DROP TABLE IF EXISTS `tbl_vc_product_catalog`;

CREATE TABLE `tbl_vc_product_catalog` (
  `product_catalog_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isbn13` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ean` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `upc` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `release_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `binding` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `list_price` double(20,2) NOT NULL,
  `author_artist` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sitbenabled` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apparel_size` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apparel_size_width` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_group` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `replenishment_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_style_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `colour` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `colour_count` bigint(20) NOT NULL,
  `prep_instructions_required` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prep_instructions_vendor_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_manufacturer_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_catalog_id`),
  KEY `idx_rtl_vc` (`fkAccountId`,`asin`,`batchId`)
) ENGINE=InnoDB AUTO_INCREMENT=1428266 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_product_catalog_updt` */

DROP TABLE IF EXISTS `tbl_vc_product_catalog_updt`;

CREATE TABLE `tbl_vc_product_catalog_updt` (
  `product_catalog_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isbn13` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ean` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `upc` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `release_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `binding` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `list_price` double(20,2) NOT NULL,
  `author_artist` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sitbenabled` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apparel_size` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apparel_size_width` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_group` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `replenishment_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_style_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `colour` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `colour_count` bigint(20) NOT NULL,
  `prep_instructions_required` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prep_instructions_vendor_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_manufacturer_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`product_catalog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4252582048 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_purchaseorders` */

DROP TABLE IF EXISTS `tbl_vc_purchaseorders`;

CREATE TABLE `tbl_vc_purchaseorders` (
  `po_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `po` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_to_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `availability` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `externalid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ack_code_translation_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hand_off_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_window_start` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_window_end` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `backorder` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expected_delivery_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed_delivery_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_size` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `accepted_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `outstanding_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderon_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_cost` double(20,2) NOT NULL,
  `total_cost` double(20,2) NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`po_id`),
  KEY `idx_rtl_po` (`batchId`)
) ENGINE=InnoDB AUTO_INCREMENT=149389 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_purchaseorders_updt` */

DROP TABLE IF EXISTS `tbl_vc_purchaseorders_updt`;

CREATE TABLE `tbl_vc_purchaseorders_updt` (
  `po_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `po` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_to_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `availability` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `externalid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ack_code_translation_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hand_off_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_window_start` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_window_end` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `backorder` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expected_delivery_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed_delivery_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_size` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `accepted_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `outstanding_cases` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderon_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `case_cost` double(20,2) NOT NULL,
  `total_cost` double(20,2) NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`po_id`),
  KEY `idx_rtl_po` (`batchId`)
) ENGINE=InnoDB AUTO_INCREMENT=1010234956 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_tmp_all_availability_scrap` */

DROP TABLE IF EXISTS `tbl_vc_tmp_all_availability_scrap`;

CREATE TABLE `tbl_vc_tmp_all_availability_scrap` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `upc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendorCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastModifiedDate` date NOT NULL,
  `cost` double(8,2) NOT NULL,
  `available` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkVendorGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `offset` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_vendor_list_scrap` */

DROP TABLE IF EXISTS `tbl_vc_vendor_list_scrap`;

CREATE TABLE `tbl_vc_vendor_list_scrap` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `businessName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `marketscopeId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendorGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isScraped` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_vendors` */

DROP TABLE IF EXISTS `tbl_vc_vendors`;

CREATE TABLE `tbl_vc_vendors` (
  `vendor_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_status` tinyint(3) unsigned NOT NULL COMMENT '0 = inActive, 1 = Active',
  `created_date` date NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_vc_weekly_traffic_summary` */

DROP TABLE IF EXISTS `tbl_vc_weekly_traffic_summary`;

CREATE TABLE `tbl_vc_weekly_traffic_summary` (
  `traffic_summary_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_vendor_id` bigint(20) unsigned NOT NULL,
  `batchId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `change_glance_view_reported` double(20,2) NOT NULL,
  `change_glance_view_prior_period` double(20,2) NOT NULL,
  `change_glance_view_last_year` double(20,2) NOT NULL,
  `change_conversion_reported` double(20,2) NOT NULL,
  `change_conversion_prior_period` double(20,2) NOT NULL,
  `change_conversion_last_year` double(20,2) NOT NULL,
  `change_unique_visitors_reported` double(20,2) NOT NULL,
  `change_unique_visitors_prior_period` double(20,2) NOT NULL,
  `change_unique_visitors_last_year` double(20,2) NOT NULL,
  `fast_track_glance_view_reported` double(20,2) NOT NULL,
  `fast_track_glance_view_prior_period` double(20,2) NOT NULL,
  `fast_track_glance_view_last_year` double(20,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `capture_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `product_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `category` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NA',
  `percentage_total_gvs` double(20,2) NOT NULL DEFAULT '0.00',
  `conversion_percentile` double(20,2) NOT NULL DEFAULT '0.00',
  `fast_track_glance_view` double(20,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`traffic_summary_id`)
) ENGINE=InnoDB AUTO_INCREMENT=167737 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `test` */

DROP TABLE IF EXISTS `test`;

CREATE TABLE `test` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) NOT NULL,
  `batchId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=496249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `view_product_asin_segments` */

DROP TABLE IF EXISTS `view_product_asin_segments`;

CREATE TABLE `view_product_asin_segments` (
  `segmentASIN` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `segmentId` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `segmentName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`segmentASIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/* Procedure structure for procedure `spRTLAMSASINLIST` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSASINLIST` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSASINLIST`()
BEGIN 
INSERT INTO tbl_rtl_ams_asin_list
   (     
        `fkProfileId`
       , `campaignId` 
       , `asin`
   )
   
   (
 SELECT
    DISTINCT
          `fkProfileId`
       , `campaignId` 
       , `asin`
       
       FROM 
(
 SELECT
    DISTINCT
          `fkProfileId`
       , `campaignId` 
       , `asin`
       
      FROM
         `replica_adtec`.`tbl_ams_productsads_reports_downloaded_data` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
     
    
   
)t
);
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spDuplicateVerfDailyCatalogVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spDuplicateVerfDailyCatalogVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spDuplicateVerfDailyCatalogVC`(IN VendorId INT)
BEGIN 
SELECT DISTINCT b.fk_vendor_id, b.date_column,b.cnt1 AS `Row_Count`,COALESCE(cnt-1,0) AS dup_count
FROM (
(SELECT fk_vendor_id,capture_date  AS date_column,ASIN,COUNT( * ) AS cnt FROM `tbl_stage_vc_product_catalog` 
	WHERE fk_vendor_id =VendorId 
	GROUP BY date_column,fk_vendor_id,ASIN
	HAVING cnt > 1
)a	
RIGHT JOIN
(
SELECT fk_vendor_id,capture_date  AS date_column,COUNT( * ) AS cnt1 FROM `tbl_stage_vc_product_catalog` 
WHERE fk_vendor_id = VendorId
GROUP BY date_column,fk_vendor_id)b
ON a.fk_vendor_id=b.fk_vendor_id AND a.date_column=b.date_column
);
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `spDuplicateVerfDailyForecastVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spDuplicateVerfDailyForecastVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spDuplicateVerfDailyForecastVC`(IN VendorId INT)
BEGIN 
SELECT DISTINCT b.fk_vendor_id, b.date_column,b.cnt1 AS `Row_Count`,COALESCE(cnt-1,0) AS dup_count
FROM (
(SELECT fk_vendor_id,capture_date  AS date_column,ASIN,COUNT( * ) AS cnt FROM `tbl_stage_vc_daily_forecast` 
	WHERE fk_vendor_id =VendorId
	GROUP BY date_column,fk_vendor_id,ASIN
	HAVING cnt > 1
)a	
RIGHT JOIN
(
SELECT fk_vendor_id,capture_date  AS date_column,COUNT( * ) AS cnt1 FROM `tbl_stage_vc_daily_forecast` 
WHERE fk_vendor_id = VendorId
GROUP BY date_column,fk_vendor_id)b
ON a.fk_vendor_id=b.fk_vendor_id AND a.date_column=b.date_column
);
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `spDuplicateVerfDailyInventoryVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spDuplicateVerfDailyInventoryVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spDuplicateVerfDailyInventoryVC`(IN VendorId INT)
BEGIN 
SELECT DISTINCT b.fk_vendor_id, b.date_column,b.cnt1 AS `Row_Count`,COALESCE(cnt-1,0) AS dup_count
FROM (
(SELECT fk_vendor_id,rec_date AS date_column,ASIN,COUNT( * ) AS cnt FROM `tbl_stage_vc_daily_inventory` 
	WHERE fk_vendor_id =VendorId 
	GROUP BY date_column,fk_vendor_id,ASIN
	HAVING cnt > 1
)a	
RIGHT JOIN
(
SELECT fk_vendor_id,rec_date AS date_column,COUNT( * ) AS cnt1 FROM `tbl_stage_vc_daily_inventory` 
WHERE fk_vendor_id = VendorId
GROUP BY date_column,fk_vendor_id)b
ON a.fk_vendor_id=b.fk_vendor_id AND a.date_column=b.date_column
);
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `spDuplicateVerfDailySalesVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spDuplicateVerfDailySalesVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spDuplicateVerfDailySalesVC`(IN VendorId INT)
BEGIN 
SELECT DISTINCT b.fk_vendor_id, b.date_column,b.cnt1 AS `Row_Count`,COALESCE(cnt-1,0) AS dup_count
FROM (
(SELECT fk_vendor_id,sale_date AS date_column,ASIN,COUNT( * ) AS cnt FROM `tbl_stage_vc_daily_sales` 
	WHERE fk_vendor_id =VendorId 
	GROUP BY date_column,fk_vendor_id,ASIN
	HAVING cnt > 1
)a	
RIGHT JOIN
(
SELECT fk_vendor_id,sale_date AS date_column,COUNT( * ) AS cnt1 FROM `tbl_stage_vc_daily_sales` 
WHERE fk_vendor_id = VendorId
GROUP BY date_column,fk_vendor_id)b
ON a.fk_vendor_id=b.fk_vendor_id AND a.date_column=b.date_column
);
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `spMoveDailySalesVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMoveDailySalesVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMoveDailySalesVC`(IN vendor_id INT)
BEGIN
DECLARE asin_count INT ;
INSERT INTO `tbl_vc_daily_sales` 
(
fk_vendor_id,    
batchId,  
fkAccountId,  
ASIN, 
product_title, 
category,  
strCategory, 
fkCategoryId,  
subcategory, 
shipped_cogs,  
shipped_cogs_percentage_total,  
shipped_cogs_prior_period,  
shipped_cogs_last_year,  
shipped_units,  
shipped_units_percentage_total,  
shipped_units_prior_period,  
shipped_units_last_year,  
units_percentage_total,  
customer_returns,  
free_replacements,  
average_sales_price,  
average_sales_price_prior_period,  
sale_date,   
created_at,           
updated_at 
)          
	
(
SELECT 
fk_vendor_id,    
batchId,  
fkAccountId,  
ASIN, 
product_title, 
category,  
strCategory, 
fkCategoryId,  
subcategory, 
shipped_cogs,  
shipped_cogs_percentage_total,  
shipped_cogs_prior_period,  
shipped_cogs_last_year,  
shipped_units,  
shipped_units_percentage_total,  
shipped_units_prior_period,  
shipped_units_last_year,  
units_percentage_total,  
customer_returns,  
free_replacements,  
average_sales_price,  
average_sales_price_prior_period,  
sale_date,   
created_at,           
updated_at           
FROM
`replica_adtec`.`tbl_stage_vc_daily_sales`
WHERE 
fk_vendor_id = vendor_id);
SET asin_count=ROW_COUNT();
DELETE FROM `replica_adtec`.`tbl_stage_vc_daily_sales` 
WHERE fk_vendor_id=vendor_id;
SELECT asin_count;
 END */$$
DELIMITER ;

/* Procedure structure for procedure `spMoveDailyInventoryVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMoveDailyInventoryVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMoveDailyInventoryVC`(IN vendor_id INT)
BEGIN
DECLARE asin_count INT ;
INSERT INTO `tbl_vc_daily_inventory`
(
 fk_vendor_id,
 batchId, 
 fkAccountId,  
 ASIN,        
 product_title,                                                                                 
 category,                            
 strCategory,                  
 fkCategoryId,  
 subcategory,                              
 net_recieved,  
 net_revieved_units,  
 sell_through_rate,  
 open_purchase_order_quantity,  
 sellable_on_hand_inventory,  
 sellable_on_hand_inventory_trailing_30_day_average,  
 sellable_on_hand_units,  
 unsellable_on_hand_inventory,  
 unsellable_on_hand_inventory_trailing_30_day_average,  
 unsellable_on_hand_units,  
 `aged_90_days_sellable_inventory`,  
 `aged_90+_days_sellable_inventory_trailing_30_day_average`,
 `aged_90_days_sellable_units`,
 unhealthy_inventory,
 unhealthy_inventory_trailing_30day_average,
 unhealthy_units,
 replenishment_category,  
 rec_date,    
 created_at,           
 updated_at 
	)
	(
SELECT
 fk_vendor_id,
 batchId, 
 fkAccountId,  
 ASIN,        
 product_title,                                                                                 
 category,                            
 strCategory ,                  
 fkCategoryId,  
 subcategory,                              
 net_recieved,  
 net_revieved_units,  
 sell_through_rate,  
 open_purchase_order_quantity,  
 sellable_on_hand_inventory,  
 sellable_on_hand_inventory_trailing_30_day_average,  
 sellable_on_hand_units,  
 unsellable_on_hand_inventory,  
 unsellable_on_hand_inventory_trailing_30_day_average,  
 unsellable_on_hand_units,  
 `aged_90_days_sellable_inventory`,  
 `aged_90+_days_sellable_inventory_trailing_30_day_average`,
 `aged_90_days_sellable_units`,
 unhealthy_inventory,
 unhealthy_inventory_trailing_30day_average,
 unhealthy_units,
 replenishment_category,  
 rec_date,    
 created_at,           
 updated_at
  
FROM
`replica_adtec`.`tbl_stage_vc_daily_inventory`
WHERE 
fk_vendor_id = vendor_id);
SET asin_count=ROW_COUNT();
DELETE FROM `replica_adtec`.`tbl_stage_vc_daily_inventory` 
WHERE fk_vendor_id=vendor_id;
SELECT asin_count;
 END */$$
DELIMITER ;

/* Procedure structure for procedure `spMoveDailyPurchaseOrderVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMoveDailyPurchaseOrderVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMoveDailyPurchaseOrderVC`(IN vendor_id INT)
BEGIN
DECLARE asin_count INT ;
INSERT INTO `tbl_vc_purchaseorders`
(
fk_vendor_id,
batchId,
fkAccountId,  
po,      
vendor,  
warehouse,  
ship_to_location,  
model_number,  
ASIN,    
product_id_type,  
availability,  
externalid,  
sku,     
title,   
ack_code_translation_id,  
hand_off_type,  
STATUS, 
delivery_window_start,  
delivery_window_end,  
backorder,  
expected_delivery_date,  
confirmed_delivery_date,  
case_size,  
submitted_cases,  
accepted_cases,  
received_cases,  
outstanding_cases,  
orderon_date,  
case_cost,  
total_cost,  
capture_date,  
created_at,  
updated_at  
)
(
SELECT 
fk_vendor_id,
batchId,
fkAccountId,  
po,      
vendor,  
warehouse,  
ship_to_location,  
model_number,  
ASIN,    
product_id_type,  
availability,  
externalid,  
sku,     
title,   
ack_code_translation_id,  
hand_off_type,  
STATUS, 
delivery_window_start,  
delivery_window_end,  
backorder,  
expected_delivery_date,  
confirmed_delivery_date,  
case_size,  
submitted_cases,  
accepted_cases,  
received_cases,  
outstanding_cases,  
orderon_date,  
case_cost,  
total_cost,  
capture_date,  
created_at,  
updated_at  
FROM
`replica_adtec`.`tbl_stage_vc_purchaseorders`
WHERE 
fk_vendor_id = vendor_id);
SET asin_count=ROW_COUNT();
DELETE FROM `replica_adtec`.`tbl_stage_vc_purchaseorders` 
WHERE fk_vendor_id=vendor_id;
SELECT asin_count;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spMoveWeeklyTrafficVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMoveWeeklyTrafficVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMoveWeeklyTrafficVC`(IN vendor_id INT)
BEGIN
DECLARE asin_count INT ;
INSERT INTO `tbl_vc_weekly_traffic_summary`
(
 fk_vendor_id,     
 batchId,  
 fkAccountId,  
 change_glance_view_reported,  
 change_glance_view_prior_period,  
 change_glance_view_last_year,  
 change_conversion_reported,  
 change_conversion_prior_period,  
 change_conversion_last_year,  
 change_unique_visitors_reported,  
 change_unique_visitors_prior_period,  
 change_unique_visitors_last_year,  
 fast_track_glance_view_reported,  
 fast_track_glance_view_prior_period,  
 fast_track_glance_view_last_year,  
 start_date,  
 end_date,    
 capture_date,  
 created_at,           
 updated_at,           
 ASIN,        
 product_title,
 subcategory,
 category,
 percentage_total_gvs,
 conversion_percentile,
 fast_track_glance_view
)
(
SELECT 
fk_vendor_id,     
 batchId,  
 fkAccountId,  
 change_glance_view_reported,  
 change_glance_view_prior_period,  
 change_glance_view_last_year,  
 change_conversion_reported,  
 change_conversion_prior_period,  
 change_conversion_last_year,  
 change_unique_visitors_reported,  
 change_unique_visitors_prior_period,  
 change_unique_visitors_last_year,  
 fast_track_glance_view_reported,  
 fast_track_glance_view_prior_period,  
 fast_track_glance_view_last_year,  
 start_date,  
 end_date,    
 capture_date,  
 created_at,           
 updated_at,           
 ASIN,        
 product_title,
 subcategory,
 category,
 percentage_total_gvs,
 conversion_percentile,
 fast_track_glance_view
 FROM
`replica_adtec`.`tbl_stage_vc_weekly_traffic_summary`
WHERE 
fk_vendor_id = vendor_id);
SET asin_count=ROW_COUNT();
DELETE FROM `replica_adtec`.`tbl_stage_vc_weekly_traffic_summary` 
WHERE fk_vendor_id=vendor_id;
SELECT asin_count;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spDuplicateVerfDailyPOVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spDuplicateVerfDailyPOVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spDuplicateVerfDailyPOVC`(IN VendorId INT)
BEGIN 
SELECT DISTINCT b.fk_vendor_id, b.date_column,b.cnt1 AS `Row_Count`,COALESCE(cnt-1,0) AS dup_count
FROM (
(SELECT fk_vendor_id,`orderon_date`  AS date_column,ASIN,po,COUNT( * ) AS cnt FROM `replica_adtec`.`tbl_stage_vc_purchaseorders` 
	WHERE fk_vendor_id =VendorId 
	GROUP BY date_column,fk_vendor_id,ASIN,po
	HAVING cnt > 1
)a	
RIGHT JOIN
(
SELECT fk_vendor_id,`orderon_date` AS date_column,COUNT( * ) AS cnt1 FROM `replica_adtec`.`tbl_stage_vc_purchaseorders` 
WHERE fk_vendor_id = VendorId
GROUP BY date_column,fk_vendor_id)b
ON a.fk_vendor_id=b.fk_vendor_id AND a.date_column=b.date_column
);
	
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `spDuplicateVerfWeeklyTrafficVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spDuplicateVerfWeeklyTrafficVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spDuplicateVerfWeeklyTrafficVC`(IN VendorId INT)
BEGIN 
SELECT DISTINCT b.fk_vendor_id, b.start_date_column, b.end_date_column,b.cnt1 AS `Row_Count`,COALESCE(cnt-1,0) AS dup_count
FROM (
(SELECT fk_vendor_id,start_date  AS start_date_column, end_date AS end_date_column, ASIN,COUNT( * ) AS cnt FROM `tbl_stage_vc_weekly_traffic_summary` 
	WHERE fk_vendor_id =vendorId
	GROUP BY start_date_column,end_date_column,fk_vendor_id,ASIN
	HAVING cnt > 1
)a	
RIGHT JOIN
(
SELECT fk_vendor_id,start_date AS start_date_column, end_date AS end_date_column, COUNT( * ) AS cnt1 FROM `tbl_stage_vc_weekly_traffic_summary` 
WHERE fk_vendor_id = vendorId
GROUP BY start_date_column,end_date_column,fk_vendor_id)b
ON a.fk_vendor_id=b.fk_vendor_id AND a.start_date_column=b.start_date_column AND a.end_date_column = b.end_date_column
);
	
	
END */$$
DELIMITER ;

/* Procedure structure for procedure `spMoveDailyCatalogVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMoveDailyCatalogVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMoveDailyCatalogVC`(IN vendor_id INT)
BEGIN
DECLARE asin_count INT ;
INSERT INTO `tbl_vc_product_catalog`
	( fk_vendor_id
	  , batchId
	  , fkAccountId
	  , ASIN
	  , product_title
	  , parent_asin
	  , isbn13
	  , ean
	  , upc
	  , release_date
	  , binding
	  , list_price
	  , author_artist
	  , sitbenabled
	  , apparel_size
	  , apparel_size_width
	  , product_group
	  , replenishment_code
	  , model_style_number
	  , colour
	  , colour_count
	  , prep_instructions_required
	  , prep_instructions_vendor_state
	  , brand_code
	  , brand
	  , manufacturer_code
	  , parent_manufacturer_code
	  , capture_date
	  , created_at
	  , updated_at
	)
	(
		SELECT
			fk_vendor_id
		  , batchId
		  , fkAccountId
		  , ASIN
		  , product_title
		  , parent_asin
		  , isbn13
		  , ean
		  , upc
		  , release_date
		  , binding
		  , list_price
		  , author_artist
		  , sitbenabled
		  , apparel_size
		  , apparel_size_width
		  , product_group
		  , replenishment_code
		  , model_style_number
		  , colour
		  , colour_count
		  , prep_instructions_required
		  , prep_instructions_vendor_state
		  , brand_code
		  , brand
		  , manufacturer_code
		  , parent_manufacturer_code
		  , capture_date
		  , created_at
		  , updated_at
		FROM
			`replica_adtec`.`tbl_stage_vc_product_catalog`
		WHERE
			fk_vendor_id = vendor_id
	)
;
SET asin_count=ROW_COUNT();
DELETE
FROM
	`replica_adtec`.`tbl_stage_vc_product_catalog`
WHERE
	fk_vendor_id=vendor_id
;
SELECT
	asin_count
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spMoveDailyForecastVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMoveDailyForecastVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMoveDailyForecastVC`(IN vendor_id INT)
BEGIN
DECLARE asin_count INT ;
INSERT INTO `tbl_vc_daily_forecast`
(
`fk_vendor_id`,    
`batchId`,  
`fkAccountId`,  
`ASIN`,        
`product_title`,
`category`,  
`strCategory`,  
`fkCategoryId`,  
`subcategory`,  
`rep_oos`,  
`rep_oos_percentage_total`,  
`rep_oos_prior_period`,  
`shipped_units`,  
`shipped_units_prior_period`,  
`unfilled_customer_ordered_units`,  
`available_inventory`,  
`available_inventory_prior_period`,  
`weeks_on_hand`,  
`open_purchase_order_quantity`,  
`open_purchase_order_quantity_prior_period`,  
`receive_fill_rate`,  
`overall_vendor_lead_time_days`,  
`replenishment_category`,  
`week_1_mean_forecast`,  
`week_2_mean_forecast`,  
`week_3_mean_forecast`,  
`week_4_mean_forecast`,  
`week_5_mean_forecast`,  
`week_6_mean_forecast`,  
`week_7_mean_forecast`,  
`week_8_mean_forecast`,  
`week_9_mean_forecast`,  
`week_10_mean_forecast`,  
`week_11_mean_forecast`,  
`week_12_mean_forecast`,  
`week_13_mean_forecast`,  
`week_14_mean_forecast`,  
`week_15_mean_forecast`,  
`week_16_mean_forecast`,  
`week_17_mean_forecast`,  
`week_18_mean_forecast`,  
`week_19_mean_forecast`,  
`week_20_mean_forecast`,  
`week_21_mean_forecast`,
`week_22_mean_forecast`,
`week_23_mean_forecast`,  
`week_24_mean_forecast`,  
`week_25_mean_forecast`,  
`week_26_mean_forecast`,  
`week_1_p70_forecast`,  
`week_2_p70_forecast`,  
`week_3_p70_forecast`,  
`week_4_p70_forecast`,  
`week_5_p70_forecast`,  
`week_6_p70_forecast`,  
`week_7_p70_forecast`,
`week_8_p70_forecast`,
`week_9_p70_forecast`,
`week_10_p70_forecast`,
`week_11_p70_forecast`, 
`week_12_p70_forecast`,  
`week_13_p70_forecast`,  
`week_14_p70_forecast`,  
`week_15_p70_forecast`,
`week_16_p70_forecast`,
`week_17_p70_forecast`,  
`week_18_p70_forecast`,
`week_19_p70_forecast`,
`week_20_p70_forecast`,  
`week_21_p70_forecast`,  
`week_22_p70_forecast`,  
`week_23_p70_forecast`,  
`week_24_p70_forecast`,  
`week_25_p70_forecast`,  
`week_26_p70_forecast`,  
`week_1_p80_forecast`,  
`week_2_p80_forecast`,  
`week_3_p80_forecast`,  
`week_4_p80_forecast`,  
`week_5_p80_forecast`,  
`week_6_p80_forecast`,  
`week_7_p80_forecast`,  
`week_8_p80_forecast`,  
`week_9_p80_forecast`,  
`week_10_p80_forecast`,  
`week_11_p80_forecast`,  
`week_12_p80_forecast`,  
`week_13_p80_forecast`,  
`week_14_p80_forecast`,  
`week_15_p80_forecast`, 
`week_16_p80_forecast`,  
`week_17_p80_forecast`,
`week_18_p80_forecast`,
`week_19_p80_forecast`,  
`week_20_p80_forecast`,
`week_21_p80_forecast`,
`week_22_p80_forecast`,  
`week_23_p80_forecast`,  
`week_24_p80_forecast`,  
`week_25_p80_forecast`,  
`week_26_p80_forecast`,  
`week_1_p90_forecast`,  
`week_2_p90_forecast`,  
`week_3_p90_forecast`,  
`week_4_p90_forecast`,  
`week_5_p90_forecast`,  
`week_6_p90_forecast`,  
`week_7_p90_forecast`,
`week_8_p90_forecast`,
`week_9_p90_forecast`,  
`week_10_p90_forecast`,  
`week_11_p90_forecast`,  
`week_12_p90_forecast`,  
`week_13_p90_forecast`,
`week_14_p90_forecast`,
`week_15_p90_forecast`, 
`week_16_p90_forecast`,  
`week_17_p90_forecast`,  
`week_18_p90_forecast`,  
`week_19_p90_forecast`,  
`week_20_p90_forecast`,  
`week_21_p90_forecast`,  
`week_22_p90_forecast`,  
`week_23_p90_forecast`,  
`week_24_p90_forecast`,  
`week_25_p90_forecast`,  
`week_26_p90_forecast`,  
`capture_date`,  
`created_at`,           
`updated_at` 
)
(
SELECT
`fk_vendor_id`,    
`batchId`,  
`fkAccountId`,  
`ASIN`,        
`product_title`,
`category`,  
`strCategory`,  
`fkCategoryId`,  
`subcategory`,  
`rep_oos`,  
`rep_oos_percentage_total`,  
`rep_oos_prior_period`,  
`shipped_units`,  
`shipped_units_prior_period`,  
`unfilled_customer_ordered_units`,  
`available_inventory`,  
`available_inventory_prior_period`,  
`weeks_on_hand`,  
`open_purchase_order_quantity`,  
`open_purchase_order_quantity_prior_period`,  
`receive_fill_rate`,  
`overall_vendor_lead_time_days`,  
`replenishment_category`,  
`week_1_mean_forecast`,  
`week_2_mean_forecast`,  
`week_3_mean_forecast`,  
`week_4_mean_forecast`,  
`week_5_mean_forecast`,  
`week_6_mean_forecast`,  
`week_7_mean_forecast`,  
`week_8_mean_forecast`,  
`week_9_mean_forecast`,  
`week_10_mean_forecast`,  
`week_11_mean_forecast`,  
`week_12_mean_forecast`,  
`week_13_mean_forecast`,  
`week_14_mean_forecast`,  
`week_15_mean_forecast`,  
`week_16_mean_forecast`,  
`week_17_mean_forecast`,  
`week_18_mean_forecast`,  
`week_19_mean_forecast`,  
`week_20_mean_forecast`,  
`week_21_mean_forecast`,
`week_22_mean_forecast`,
`week_23_mean_forecast`,  
`week_24_mean_forecast`,  
`week_25_mean_forecast`,  
`week_26_mean_forecast`,  
`week_1_p70_forecast`,  
`week_2_p70_forecast`,  
`week_3_p70_forecast`,  
`week_4_p70_forecast`,  
`week_5_p70_forecast`,  
`week_6_p70_forecast`,  
`week_7_p70_forecast`,
`week_8_p70_forecast`,
`week_9_p70_forecast`,
`week_10_p70_forecast`,
`week_11_p70_forecast`, 
`week_12_p70_forecast`,  
`week_13_p70_forecast`,  
`week_14_p70_forecast`,  
`week_15_p70_forecast`,
`week_16_p70_forecast`,
`week_17_p70_forecast`,  
`week_18_p70_forecast`,
`week_19_p70_forecast`,
`week_20_p70_forecast`,  
`week_21_p70_forecast`,  
`week_22_p70_forecast`,  
`week_23_p70_forecast`,  
`week_24_p70_forecast`,  
`week_25_p70_forecast`,  
`week_26_p70_forecast`,  
`week_1_p80_forecast`,  
`week_2_p80_forecast`,  
`week_3_p80_forecast`,  
`week_4_p80_forecast`,  
`week_5_p80_forecast`,  
`week_6_p80_forecast`,  
`week_7_p80_forecast`,  
`week_8_p80_forecast`,  
`week_9_p80_forecast`,  
`week_10_p80_forecast`,  
`week_11_p80_forecast`,  
`week_12_p80_forecast`,  
`week_13_p80_forecast`,  
`week_14_p80_forecast`,  
`week_15_p80_forecast`, 
`week_16_p80_forecast`,  
`week_17_p80_forecast`,
`week_18_p80_forecast`,
`week_19_p80_forecast`,  
`week_20_p80_forecast`,
`week_21_p80_forecast`,
`week_22_p80_forecast`,  
`week_23_p80_forecast`,  
`week_24_p80_forecast`,  
`week_25_p80_forecast`,  
`week_26_p80_forecast`,  
`week_1_p90_forecast`,  
`week_2_p90_forecast`,  
`week_3_p90_forecast`,  
`week_4_p90_forecast`,  
`week_5_p90_forecast`,  
`week_6_p90_forecast`,  
`week_7_p90_forecast`,
`week_8_p90_forecast`,
`week_9_p90_forecast`,  
`week_10_p90_forecast`,  
`week_11_p90_forecast`,  
`week_12_p90_forecast`,  
`week_13_p90_forecast`,
`week_14_p90_forecast`,
`week_15_p90_forecast`, 
`week_16_p90_forecast`,  
`week_17_p90_forecast`,  
`week_18_p90_forecast`,  
`week_19_p90_forecast`,  
`week_20_p90_forecast`,  
`week_21_p90_forecast`,  
`week_22_p90_forecast`,  
`week_23_p90_forecast`,  
`week_24_p90_forecast`,  
`week_25_p90_forecast`,  
`week_26_p90_forecast`,  
`capture_date`,  
`created_at`,           
`updated_at`
FROM
`replica_adtec`.`tbl_stage_vc_daily_forecast`
WHERE 
fk_vendor_id = vendor_id);
SET asin_count=ROW_COUNT();
DELETE FROM `replica_adtec`.`tbl_stage_vc_daily_forecast` 
WHERE fk_vendor_id=vendor_id;
SELECT asin_count;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateKeywordBiddingRule` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateKeywordBiddingRule` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateKeywordBiddingRule`(IN campaign_id BIGINT,IN keyword_id BIGINT, IN reporttype VARCHAR(10), IN numofdays INT)
BEGIN
SELECT
  
 
  `fkAccountId`,
  `fkProfileId`,
  `profile_name`,
  `campaignId`,
  `campaignName`,
  `adGroupId`,
  `adGroupName`,
  `keywordId`,
  `keywordText`,
  `matchType`,
  SUM(`impressions`) AS impression,
  SUM(`clicks`) AS clicks,
  SUM(`cost`) AS cost,
  SUM(`attributedConversions`) AS attributedConversions,
  SUM(`attributedConversionsSameSKU`) AS attributedConversionsSameSKU,
  SUM(`attributedUnitsOrdered`) AS attributedUnitsOrdered,
  SUM(`attributedSales`) AS  revenue,
  SUM(`attributedSalesSameSKU`) AS attributedSalesSameSKU,
  
    CASE
        WHEN  SUM(`impressions`) > 0 
        THEN ROUND(SUM(`clicks`) /  SUM(`impressions`), 2) 
        ELSE 0 
      END AS ctr,
      CASE
        WHEN SUM(`attributedSales`)  > 0 
        THEN ROUND( SUM(`cost`) / SUM(`attributedSales`), 2) 
        ELSE 0 
      END AS `acos`,
      CASE
        WHEN SUM(`clicks`) > 0 
        THEN ROUND(SUM(`cost`) / SUM(`clicks`), 2) 
        ELSE 0.00 
      END AS cpc,
      CASE
        WHEN SUM(`cost`)  > 0 
        THEN ROUND(SUM(`attributedSales`) / SUM(`cost`) , 2) 
        ELSE 0.00 
      END AS roas,
      
            CASE
        WHEN SUM(`attributedUnitsOrdered`) > 0 
        THEN ROUND(SUM(`cost`) / SUM(`attributedUnitsOrdered`), 2) 
        ELSE 0.00 
      END AS cpa
  
  
  
  
FROM `replica_adtec`.`tbl_rtl_ams_keyword`
WHERE `reportDate` >= DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
AND campaignId = campaign_id
AND keywordId = keyword_id
AND report_type = reporttype
GROUP BY 
 
  `fkAccountId`,
  `fkProfileId`,
  `profile_name`,
  `campaignId`,
  `campaignName`,
  `adGroupId`,
  `adGroupName`,
  `keywordId`,
  `keywordText`,
  `matchType` ;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateTargetBiddingRule` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateTargetBiddingRule` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateTargetBiddingRule`(IN campaign_id BIGINT, IN target_id BIGINT, IN numofdays INT)
BEGIN
             SELECT
    `fkAccountId`,
    `fkProfileId`,
    -- `profile_name`,
    `campaignId`,
    `campaignName`,
    `adGroupId`,
    `adGroupName`,
    `targetId`,
    `targetingText`,
    SUM(`impressions`) AS impression,
    SUM(`clicks`) AS clicks,
    SUM(`cost`) AS cost,
    SUM(`attributedConversions14d`) AS attributedConversions,
    SUM(`attributedConversions14dSameSKU`) AS attributedConversionsSameSKU,
    SUM(`attributedUnitsOrdered14d`) AS attributedUnitsOrdered,
    SUM(`attributedSales14d`) AS revenue,
    SUM(`attributedSales14dSameSKU`) AS attributedSalesSameSKU,
    
    CASE
    WHEN SUM(`impressions`) > 0
    THEN ROUND(SUM(`clicks`) / SUM(`impressions`), 2)
    ELSE 0
    END AS ctr,
    CASE
    WHEN SUM(`attributedSales14d`) > 0
    THEN ROUND( SUM(`cost`) / SUM(`attributedSales14d`), 2)
    ELSE 0
    END AS `acos`,
    CASE
    WHEN SUM(`clicks`) > 0
    THEN ROUND(SUM(`cost`) / SUM(`clicks`), 2)
    ELSE 0.00
    END AS cpc,
    CASE
    WHEN SUM(`cost`) > 0
    THEN ROUND(SUM(`attributedSales14d`) / SUM(`cost`) , 2)
    ELSE 0.00
    END AS roas,
    
    CASE
    WHEN SUM(`attributedUnitsOrdered14d`) > 0
    THEN ROUND(SUM(`cost`) / SUM(`attributedUnitsOrdered14d`), 2)
    ELSE 0.00
    END AS cpa
    
    FROM `replica_adtec`.`tbl_ams_targets_reports_downloaded_data_sd_for_biding_rule`
    WHERE `reportDate` >= DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
    AND campaignId = campaign_id
    AND targetId = target_id
    GROUP BY
    
    `fkAccountId`,
    `fkProfileId`,
    -- `profile_name`,
    `campaignId`,
     `campaignName`,
    `adGroupId`,
    `adGroupName`,
    `targetId`,
    targetingText;
    -- `keywordText`,
    -- `matchType` ;
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spUpdateTargetBiddingRule` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUpdateTargetBiddingRule` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUpdateTargetBiddingRule`(IN max_date VARCHAR(20))
BEGIN
UPDATE `tbl_ams_targets_reports_downloaded_data_sd_for_biding_rule` a
INNER JOIN `tbl_ams_targets_reports_downloaded_data_sd` b ON a.campaignId = b.campaignId 
AND a.campaignName <>  b.campaignName 
AND a.adgroupid = b.adgroupId AND a.targetId=b.targetId
 AND b.reportDate = max_date
SET a.campaignName =  b.campaignName,
a.`adGroupName`=b.`adGroupName`
;
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSAccountPerReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSAccountPerReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSAccountPerReport`(in start_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
         
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
          
        delete from replica_adtec.`tbl_ams_report_id_error` where DATE_FORMAT(Report_date,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d");	
        INSERT INTO replica_adtec.`tbl_ams_report_id_error`
           SELECT
        NULL,
         t4.`id` AS Account_id
         ,t4.`fkId`AS Profile_id
        ,t3.reportType
        ,start_date
        FROM 
        (SELECT
        t2.`fkAccountId`,
        t2.`reportType`
        FROM
        (SELECT
        `profileID`,
        `reportType`,
        CONCAT(`profileID`,`reportType`) AS id1
        FROM 
        replica_adtec.`tbl_ams_report_id`
        WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
        GROUP BY 1,2,3
        )t1
        RIGHT JOIN
        (SELECT
        a.`fkAccountId`,
        a.`reportType`
        ,CONCAT(a.`profileID`,a.`reportType`) AS id2
        FROM 
        replica_adtec.`tbl_ams_report_id` a
        JOIN `tbl_ams_profiles` b
        ON a.`profileID`=b.`profileId`
        WHERE b.isActive = 1
        AND b.type !='agency'
        AND countrycode !='MX'
        AND DATE_FORMAT(LEFT(b.creationDate,10),"%Y-%m-%d") <=DATE_FORMAT(start_date,"%Y-%m-%d")
        GROUP BY 1,2,3
        )t2
        ON (t1.id1 = t2.id2)
        WHERE t1.id1 IS NULL)t3
        JOIN 
        (SELECT `id`,`fkId` FROM replica_adtec.`tbl_account`)t4
        ON t3.`fkAccountId`= t4.`id`
         UNION
         SELECT
        NULL,
         t4.`id` AS Account_id
         ,t4.`fkId`AS Profile_id
        ,t3.reportType
        ,start_date
        FROM 
        (SELECT
        t2.`fkAccountId`,
        t2.`reportType`
        FROM
        (SELECT
        `profileID`,
        `reportType`,
        CONCAT(`profileID`,`reportType`) AS id1
        FROM 
        replica_adtec.`tbl_ams_report_id`
        WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
        GROUP BY 1,2,3
        )t1
        RIGHT JOIN
        (SELECT
        a.`fkAccountId`,
        a.`reportType`
        ,CONCAT(a.`profileID`,a.`reportType`) AS id2
        FROM 
        replica_adtec.`tbl_ams_report_id` a
        JOIN `tbl_ams_profiles` b
        ON a.`profileID`=b.`profileId`
        WHERE b.isActive = 1
        AND b.type !='agency'
        AND DATE_FORMAT(LEFT(b.creationDate,10),"%Y-%m-%d") <=DATE_FORMAT(start_date,"%Y-%m-%d")
        GROUP BY 1,2,3
        )t2
        ON (t1.id1 = t2.id2)
        WHERE t1.id1 IS NULL)t3
        JOIN 
        (SELECT `id`,`fkId` FROM replica_adtec.`tbl_account`)t4
        ON t3.`fkAccountId`= t4.`id`
        ;
        
        
          
          IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSAccountPerReport'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSAccountPerReport'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSDataDuplication` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSDataDuplication` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSDataDuplication`(in startdate varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
         DECLARE EXIT HANDLER FOR SQLEXCEPTION 
         BEGIN
            -- ERROR
            SELECT 
             "Syntax Error" ;
           SET `_rollback` = 1 ;
           ROLLBACK ;
           END ;
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
          
          Delete from replica_adtec.`tbl_ams_data_duplication` where reportDate = startdate;
            Insert into replica_adtec.`tbl_ams_data_duplication`	
            SELECT
            NULL,
             fkAccountId,
             'Adgroup SB Data Duplication',
             COUNT(*) AS reptitve_count,
             reportDate
              FROM
            (SELECT  fkAccountId ,fkProfileId,campaignId,adgroupId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_adgroup_reports_downloaded_data_sb` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,adgroupId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL,fkAccountId,'Adgroup SB Data Not Present In Table',COUNT(*)AS reptitve,reportDate FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sb` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_adgroup_reports_downloaded_data_sb` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL, fkAccountId,'Adgroup SD Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT fkAccountId ,fkProfileId,campaignId,adgroupId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_adgroup_reports_downloaded_data_sd`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,adgroupId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Adgroup SD Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sd` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_adgroup_reports_downloaded_data_sd` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL ,fkAccountId,'Adgroup SP Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT fkAccountId ,fkProfileId,campaignId,adgroupId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_adgroup_reports_downloaded_data_sp`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,adgroupId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Adgroup SP Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sp` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_adgroup_reports_downloaded_data_sp` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL, fkAccountId,'Asin Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT fkAccountId ,fkProfileId,campaignId,adgroupId,keywordId,ASIN,otherAsin,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_asin_reports_downloaded_sp`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") 
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,adgroupId,keywordId,ASIN,otherAsin
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Asin Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_asin_reports_download_links` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_asin_reports_downloaded_sp` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT Null, fkAccountId,'Campaign SB Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT  fkAccountId ,fkProfileId,campaignId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_campaigns_reports_downloaded_sb`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Campaign SB Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sb` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_campaigns_reports_downloaded_sb` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL, fkAccountId,'Campaign SD Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT  fkAccountId ,fkProfileId,campaignId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_campaigns_reports_downloaded_sd`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL,fkAccountId,'Campaign SD Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sd` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_campaigns_reports_downloaded_sd` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL,fkAccountId,'Campaign SP Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT  fkAccountId ,fkProfileId,campaignId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_campaigns_reports_downloaded_sp`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Campaign SP Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sp` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_campaigns_reports_downloaded_sp` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL,fkAccountId,'Keyword SB Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT  fkAccountId ,fkProfileId,campaignId,adgroupId,keywordId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_keyword_reports_downloaded_data_sb`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,adgroupId,keywordId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Keyword SB Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_keyword_reports_download_links_sb` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_keyword_reports_downloaded_data_sb` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL, fkAccountId,'Keyword SP Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT  fkAccountId ,fkProfileId,campaignId,adgroupId,keywordId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_keyword_reports_downloaded_data_sp`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,adgroupId,keywordId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Keyword SP Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_keyword_reports_download_links_sp` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_keyword_reports_downloaded_data_sp` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL,fkAccountId,'Productads Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT '`tbl_ams_productsads_reports_downloaded_data`', fkAccountId ,fkProfileId,campaignId,adgroupId,adId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_productsads_reports_downloaded_data`
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,adgroupId,adId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL,fkAccountId,'Productads Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_productsads_reports_download_links` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_productsads_reports_downloaded_data` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL,fkAccountId,'Productads SD Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT  fkAccountId ,fkProfileId,campaignId,adgroupId,ASIN,sku,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_productsads_reports_downloaded_data_sd`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") 
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,adgroupId,ASIN,sku
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Productads SD Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_productsads_reports_download_links_sd` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_productsads_reports_downloaded_data_sd` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL, fkAccountId,'Target Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT fkAccountId ,fkProfileId,campaignId,targetId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_targets_reports_downloaded_data`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") 
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,targetId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL, fkAccountId,'Target Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_targets_reports_download_links` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_targets_reports_downloaded_data` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT NULL, fkAccountId,'Target SB Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT fkAccountId ,fkProfileId,campaignId,targetId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_targets_reports_downloaded_data_sb`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") 
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,targetId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT NULL,fkAccountId,'Target SB Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_targets_reports_download_links_sb` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_targets_reports_downloaded_data_sb` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        UNION
            SELECT Null,fkAccountId,'Target SD Data Duplication',COUNT(*) AS reptitve_count,reportDate FROM
            (SELECT fkAccountId ,fkProfileId,campaignId,targetId,reportDate, COUNT(fkaccountId) AS cnt
            FROM replica_adtec.`tbl_ams_targets_reports_downloaded_data_sd`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") 
            GROUP BY fkAccountId,reportDate,fkProfileId,campaignId,targetId
            HAVING cnt> 1)A 
            GROUP BY fkAccountId,reportDate
            UNION
            SELECT Null,fkAccountId,'Target SD Data Not Present In Table',COUNT(*)AS reptitve_count,reportDate FROM replica_adtec.`tbl_ams_targets_reports_download_links_sd` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_targets_reports_downloaded_data_sd` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ) AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d") AND fileSize > 22
        GROUP BY   fkAccountId,reportDate
        
        ;
        
          
          IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSDataDuplication'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSDataDuplication'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSLinkDuplication` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSLinkDuplication` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSLinkDuplication`(in startdate varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          /*DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
          */
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
          
        
        DELETE FROM replica_adtec.`tbl_ams_link_duplication` where DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d");
          INSERT INTO replica_adtec.`tbl_ams_link_duplication`
        SELECT NULL, fkAccountId, 'Adgroup_SB_Links'  , STATUS,COUNT(*)
         AS cnt, reportDate
        FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sb`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId, 'Adgroup_SD_Links' , STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sd`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId,'Adgroup_SP_Links', STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sp`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId, 'Campaign_SB_Links', STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sb`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId, 'Campaign_SD_Links', STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sd`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId,'Campaign_SP_Links', STATUS,COUNT(*)
         AS cnt ,reportDate
        FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sp`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId,'Keyword_SB_Links' , STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_keyword_reports_download_links_sb`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId, 'Keyword_SP_Links', STATUS,COUNT(*)
         AS cnt ,reportDate
        FROM replica_adtec.`tbl_ams_keyword_reports_download_links_sp`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId, 'Productads_Links' , STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_productsads_reports_download_links`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId, 'Productads_Links_SD' , STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_productsads_reports_download_links_sd`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId,'Target_Links', STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_targets_reports_download_links`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId,'Target_SB_Links',STATUS,COUNT(*)
         AS cnt,reportDate
        FROM replica_adtec.`tbl_ams_targets_reports_download_links_sb`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        UNION
        SELECT NULL, fkAccountId, 'Target_SD_Links', STATUS,COUNT(*)
         AS cnt ,reportDate
        FROM replica_adtec.`tbl_ams_targets_reports_download_links_sd`
        GROUP BY STATUS,fkAccountId,reportDate
        HAVING cnt> 1 
         OR (cnt = 1 AND STATUS != 'SUCCESS')
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
        ;		  
          IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSLinkDuplication'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSLinkDuplication'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSLinkError` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSLinkError` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSLinkError`(in report_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
          
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
          delete from replica_adtec.`tbl_ams_link_error` where DATE_FORMAT(Report_date,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d");
         
        INSERT INTO tbl_ams_link_error
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sb` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'AdGroup_SB'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sd` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'AdGroup_SD'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sp` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'AdGroup_SP'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_asin_reports_download_links` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'ASINs'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sb` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Campaign_SB'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sd` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Campaign_SD'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sp` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Campaign_SP'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_keyword_reports_download_links_sb` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Keyword_SB'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_keyword_reports_download_links_sp` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Keyword_SP'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_productsads_reports_download_links` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Product_Ads'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_productsads_reports_download_links_sd` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'SD_Product_Ads'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_targets_reports_download_links` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Product_Targeting'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_targets_reports_download_links_sb` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Product_Targeting_SB'
        UNION
        SELECT NULL,`fkAccountId`,`profileID`,`reportType`,`reportDate` FROM replica_adtec.`tbl_ams_report_id` WHERE fkAccountId NOT IN
        (
        SELECT fkAccountId FROM replica_adtec.`tbl_ams_targets_reports_download_links_sd` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        )
        AND DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") AND reportType = 'Product_Targeting_SD'
        ORDER BY 2
        ;
          
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSLinkError'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSLinkError'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSNewProfile` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSNewProfile` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSNewProfile`(in report_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
          
                
          SELECT
           profileId,
           countryCode,
           NAME,
           creationDate 
           FROM replica_adtec.`tbl_ams_profiles`
           WHERE DATE_FORMAT(LEFT(creationDate,10),"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")
        
          ;
          
          IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSNewProfile'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSNewProfile'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateDataDuplication` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateDataDuplication` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateDataDuplication`(in start_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
         
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
        
            SELECT 
            `Account_Id`,
            `Report_Type_Data`,
            `Repetitive_Count`,
            reportDate
            FROM 
            replica_adtec.`tbl_ams_data_duplication`
            where DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
            ;
              
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateDataDuplication'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateDataDuplication'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateLink` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateLink` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateLink`(in start_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
         
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
        
            SELECT 
            `report_type_link`,
            `total_link_count`,
            reportDate
            FROM 
            replica_adtec.`tbl_ams_total_link`
            where DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
            ;
              
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateLink'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateLink'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateLinkDuplication` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateLinkDuplication` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateLinkDuplication`(in start_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
         
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
        
            SELECT 
            `Account_Id`,
            `Report_Type_Link`,
            `Status`,
            `Repetitive_Count`,
            reportDate
            FROM 
            replica_adtec.`tbl_ams_link_duplication`
            where DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
            ;
              
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateLinkDuplication'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateLinkDuplication'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateLinkError` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateLinkError` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateLinkError`(in start_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
         
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
        
            SELECT 
            `Account_Id`,
            `Profile_id`,
            `Report_Type`,
            Report_date
            FROM 
            replica_adtec.`tbl_ams_report_id_error`
            where DATE_FORMAT(Report_date,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
            ;
              
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateLinkError'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateLinkError'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateProfile` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateProfile` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateProfile`(IN startdate VARCHAR(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
         DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
        
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
         
            SELECT 
            `id`,
            `profileId`,
            `name`,
            `countryCode`,
            `isActive`,
            `creationDate`,
            `flag`,
            reportDate
            FROM
            replica_adtec.`tbl_ams_profiles_validate`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            ;
              
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateProfile'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateProfile'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateReportId` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateReportId` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateReportId`(in start_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
         
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
        
            SELECT 
            `report_type_id`,
            `total_report_id`
            FROM 
            replica_adtec.`tbl_ams_total_report_id`
            where DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
            ;
              
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateReportId'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateReportId'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateReportIdError` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateReportIdError` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateReportIdError`(in start_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
         
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
        
            SELECT 
            `Account_Id`,
            `Profile_id`,
            `Report_Type`,
            Report_date
            FROM 
            replica_adtec.`tbl_ams_report_id_error`
            where DATE_FORMAT(Report_date,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
            ;
              
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateReportIdError'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateReportIdError'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateReportIdMandatory` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateReportIdMandatory` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateReportIdMandatory`(in start_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
         
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
        
            SELECT 
            `report_type_id`,
            `total_report_id`
            FROM replica_adtec.`tbl_ams_report_id_mandatory`
            where DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
            ;
              
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateReportIdMandatory'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSPopulateReportIdMandatory'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSPopulateScoreCard` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSPopulateScoreCard` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSPopulateScoreCard`(in start_date varchar(50))
BEGIN
              DECLARE max_date DATE DEFAULT NULL ;
              DECLARE `_rollback` BOOL DEFAULT 0 ;
              
              
               DECLARE EXIT HANDLER FOR SQLEXCEPTION 
              BEGIN
                -- ERROR
                SELECT 
                  "Syntax Error" ;
                SET `_rollback` = 1 ;
                ROLLBACK ;
              END ;
             
              
             /* DECLARE EXIT HANDLER FOR SQLWARNING 
              BEGIN
                -- WARNING
                SELECT 
                  "Warning by DB" ;
                SET `_rollback` = 1 ;
                ROLLBACK;
              END ;
              
            */ 
             
             
              START TRANSACTION ;
              
             
              SET autocommit = 0 ;
            
                SELECT 
                `Total_Report_Id`
                ,`Total_Link_Reports`
                ,`New_Profile`
                ,`Active_Profile`
                ,`InActive_Profile`
                ,`Profile_Incompatible_with_SD`,
                `Agency_Type`
                FROM
                replica_adtec.`tbl_ams_score_card`
                WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(start_date,"%Y-%m-%d")
                
                ;
                  
                IF `_rollback` THEN
              INSERT INTO adtec_bi.`etl_logs`
                 ( `log_id`
                  , `Stored_Procedure_Name`
                  , `Execution_status`
                  , `LogDate`
                 )
                 VALUES
                 ( NULL
                  , 'spAMSPopulateScoreCard'
                  , 'RollBack'
                  , CURRENT_TIMESTAMP()
                 )
              ;
              
              ROLLBACK;
              ELSE
              INSERT INTO adtec_bi.`etl_logs`
                 ( `log_id`
                  , `Stored_Procedure_Name`
                  , `Execution_status`
                  , `LogDate`
                 )
                 VALUES
                 ( NULL
                  , 'spAMSPopulateScoreCard'
                  , 'Commit'
                  , CURRENT_TIMESTAMP()
                 )
              ;
              
              COMMIT;
              END
              IF;
              
            END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSScoreCard` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSScoreCard` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSScoreCard`(in report_date varchar(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
          delete from replica_adtec.`tbl_ams_score_card` where DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d");
            INSERT INTO replica_adtec.`tbl_ams_score_card`
          (
              id,
            Total_Report_Id ,
            Total_Link_Reports ,
            New_Profile ,
            Active_Profile ,
            InActive_Profile ,
            Profile_Incompatible_with_SD ,
            Agency_Type ,
            `reportDate` ,
            `creationDate`
          )
          (	
            SELECT
            NULL,
              ( SELECT 
                COUNT(*) AS Total_Report_Id
                FROM replica_adtec.`tbl_ams_report_id` 
                WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")) AS Total_Report_Id, 
              (SELECT
                COUNT(*) AS Total_Link_Reports
            FROM (
            SELECT *
            FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sb`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sd`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_adgroup_reports_download_links_sp`
            
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_asin_reports_download_links`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sb`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sd`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_campaigns_reports_download_links_sp`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_keyword_reports_download_links_sb`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_keyword_reports_download_links_sp`
        
            UNION ALL
        
            SELECT * 
            FROM 
            replica_adtec.`tbl_ams_productsads_reports_download_links`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_productsads_reports_download_links_sd`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_targets_reports_download_links`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_targets_reports_download_links_sb`
        
            UNION ALL
        
            SELECT *
            FROM replica_adtec.`tbl_ams_targets_reports_download_links_sd`
            ) t
            WHERE DATE_FORMAT(t.reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")) AS Total_Link_Reports,
             ( SELECT
                COUNT(profileid) AS New_Profile 
                FROM replica_adtec.`tbl_ams_profiles`
                WHERE DATE_FORMAT(LEFT(creationDate,10),"%Y-%m-%d")=DATE_FORMAT(report_date,"%Y-%m-%d")) AS New_Profile,
            (SELECT 
                COUNT(isActive) AS Active_Profile
                FROM replica_adtec.`tbl_ams_profiles`
                WHERE isActive = 1
                AND TYPE != 'agency'
                AND DATE_FORMAT(LEFT(creationDate,10),"%Y-%m-%d") <= DATE_FORMAT(report_date,"%Y-%m-%d")		
                ) AS Active_Profile,
            (SELECT 
                COUNT(isActive) AS InActive_Profile
                FROM replica_adtec.`tbl_ams_profiles`
                WHERE isActive = 0
                AND DATE_FORMAT(LEFT(creationDate,10),"%Y-%m-%d") <= DATE_FORMAT(report_date,"%Y-%m-%d")) AS InActive_Profile,
            (SELECT 
                COUNT(CountryCode) AS  Profile_Incompatible_with_SD
                FROM replica_adtec.`tbl_ams_profiles`
                WHERE CountryCode = 'MX'
                AND TYPE != 'agency'
                AND DATE_FORMAT(LEFT(creationDate,10),"%Y-%m-%d") <=DATE_FORMAT(report_date,"%Y-%m-%d")) AS Profile_Incompatible_with_SD,
            (SELECT 
                COUNT(TYPE) AS Agency_Type
                FROM replica_adtec.`tbl_ams_profiles`
                WHERE TYPE = 'agency'
                AND DATE_FORMAT(LEFT(creationDate,10),"%Y-%m-%d") <=DATE_FORMAT(report_date,"%Y-%m-%d")) AS Agency_Type,
                (SELECT 
                 DISTINCT(reportDate)
                FROM replica_adtec.`tbl_ams_report_id`
                WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d")) AS reportDate,
                
                Current_Date AS creationDate
                )
                
          ;
          
            IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSScoreCard'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSScoreCard'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spMasterHealthDashboard` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMasterHealthDashboard` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMasterHealthDashboard`(in `max_date` varchar(20))
BEGIN
        	
            DECLARE `_rollback` BOOL DEFAULT 0;
            DECLARE EXIT HANDLER FOR SQLEXCEPTION
            BEGIN
                -- ERROR
                SELECT "Syntax Error" ;
                SET `_rollback` = 1 ;
                ROLLBACK ;
            END;
            -- BEGIN
                -- WARNING
            --	SELECT "Warning by DB";
            --	SET `_rollback` = 1 ;
            --	ROLLBACK;
            -- END;
            START TRANSACTION;
            
            SET autocommit = 0;
                        
            CALL replica_adtec.spAMSScoreCard(max_date);
            CALL replica_adtec.spAMSProfileValidate(max_date);
            CALL replica_adtec.spAMSTotalReportIDMandatory(); 
            CALL replica_adtec.spAMSTotalReportID(max_date);
            CALL replica_adtec.spAMSTotalLink(max_date);
            CALL replica_adtec.spAMSLinkDuplication(max_date);
            CALL replica_adtec.`spAMSDataDuplication`(max_date);
            CALL replica_adtec.`spAMSAccountPerReport`(max_date); 
            CALL replica_adtec.spAMSLinkError(`max_date`);
            
            
        IF `_rollback` THEN
        INSERT INTO adtec_bi.`etl_logs`
           ( `log_id`
            ,`Stored_Procedure_Name`
            ,`Execution_status`
            ,`LogDate`
           )
           VALUES
           ( NULL
            ,'spMasterHealthDashboard'
            ,'RollBack'
            , CURRENT_TIMESTAMP()
           )
        ;
        ROLLBACK;
        ELSE
        INSERT INTO adtec_bi.`etl_logs`
           ( `log_id`
            ,`Stored_Procedure_Name`
            ,`Execution_status`
            ,`LogDate`
           )
           VALUES
           ( NULL
            ,'spMasterHealthDashboard'
            ,'Commit'
            , CURRENT_TIMESTAMP()
           )
        ;
        COMMIT;
        END
        IF;
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSProfileValidate` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSProfileValidate` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSProfileValidate`(IN report_date VARCHAR(50))
BEGIN
          DECLARE max_date DATE DEFAULT NULL ;
          DECLARE `_rollback` BOOL DEFAULT 0 ;
          
          
          DECLARE EXIT HANDLER FOR SQLEXCEPTION 
          BEGIN
            -- ERROR
            SELECT 
              "Syntax Error" ;
            SET `_rollback` = 1 ;
            ROLLBACK ;
          END ;
          
         /* DECLARE EXIT HANDLER FOR SQLWARNING 
          BEGIN
            -- WARNING
            SELECT 
              "Warning by DB" ;
            SET `_rollback` = 1 ;
            ROLLBACK;
          END ;
          
        */ 
         
         
          START TRANSACTION ;
          
         
          SET autocommit = 0 ;
          Delete FROm  replica_adtec.`tbl_ams_profiles_validate` where DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") ;
          INSERT INTO replica_adtec.`tbl_ams_profiles_validate`
             ( 
                `id`,
                `profileId`,
                `name`,
                `countryCode`,
                `isActive`,
                `creationDate`,
                `flag`,
                reportDate
            )
             (
                SELECT
                NULL,
                profileId, 
                `name`,
                `countryCode`,
                `isActive`,
                `creationDate`,
                CASE
                WHEN DATE_FORMAT(LEFT(creationDate,10),"%Y-%m-%d") = DATE_FORMAT(report_date,"%Y-%m-%d") THEN  1
                ELSE  0
                END AS flag,
                report_date
                    FROM
                replica_adtec.`tbl_ams_profiles`
                ORDER BY 6 DESC  
                )
          ;
          
          IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSProfileValidate'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSProfileValidate'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSTotalLink` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSTotalLink` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSTotalLink`(in startdate varchar(50))
BEGIN
              DECLARE max_date DATE DEFAULT NULL ;
              DECLARE `_rollback` BOOL DEFAULT 0 ;
              
             
              DECLARE EXIT HANDLER FOR SQLEXCEPTION 
              BEGIN
                -- ERROR
                SELECT 
                  "Syntax Error" ;
                SET `_rollback` = 1 ;
                ROLLBACK ;
              END ;
              
             /* DECLARE EXIT HANDLER FOR SQLWARNING 
              BEGIN
                -- WARNING
                SELECT 
                  "Warning by DB" ;
                SET `_rollback` = 1 ;
                ROLLBACK;
              END ;
              
            */ 
             
             
              START TRANSACTION ;
              
             
              SET autocommit = 0 ;
            Delete from replica_adtec.`tbl_ams_total_link` where  DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d");
            INSERT INTO  replica_adtec.`tbl_ams_total_link`
            SELECT NULL, 
            'SD_Product_Ads', COUNT(*) AS total_link_count,reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_productsads_reports_download_links_sd` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate 
            UNION
            SELECT
             NULL, 'AdGroup_SD', COUNT(*) AS total_link,reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_adgroup_reports_download_links_sd` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate 
            UNION
            SELECT 
            NULL,
            'Campaign_SD', COUNT(*) AS total_link,reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_campaigns_reports_download_links_sd` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate
            UNION
            SELECT NULL,'Product_Targeting_SD', COUNT(*) AS total_link_count ,reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_targets_reports_download_links_sd` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate 
            UNION
            SELECT 
            NULL,
            'Campaign_SP', COUNT(*) AS total_link_count,reportDate,
            CURRENT_DATE  FROM  replica_adtec.`tbl_ams_campaigns_reports_download_links_sp` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate
            UNION
            SELECT 
            NULL,
            'AdGroup_SP', 
            COUNT(*)AS total_link,
            reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_adgroup_reports_download_links_sp` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate
            UNION
            SELECT NULL ,
            'Keyword_SP', COUNT(*) AS total_link_count,reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_keyword_reports_download_links_sp` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate  
             UNION
            SELECT
            NULL, 
            'Product_Ads', COUNT(*) AS total_link_count , reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_productsads_reports_download_links` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate 
            UNION
            SELECT NULL,
            'ASINs', COUNT(*) AS total_link_count, reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_asin_reports_download_links` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate 
            UNION
            SELECT
            NULL, 
            'Product_Targeting', COUNT(*) AS total_link_count,reportDate,
            CURRENT_DATE   FROM   replica_adtec.`tbl_ams_targets_reports_download_links`
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate 
            UNION
            SELECT NULL, 'Keyword_SB', COUNT(*) AS total_link_count,reportDate,
            CURRENT_DATE   FROM  replica_adtec.`tbl_ams_keyword_reports_download_links_sb` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate  
            UNION
            SELECT  NULL,
            'Campaign_SB', COUNT(*) AS total_link,reportDate,
            CURRENT_DATE  
             FROM  replica_adtec.`tbl_ams_campaigns_reports_download_links_sb` 
             WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
             GROUP BY reportDate 
            UNION
            SELECT 
            NULL,
            'AdGroup_SB',
            COUNT(*) AS total_link_count,
            reportDate,
            CURRENT_DATE  
            FROM  replica_adtec.`tbl_ams_adgroup_reports_download_links_sb`
             WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
             GROUP BY reportDate 
            UNION
            SELECT NULL,
            'Product_Targeting_SB', COUNT(*) AS total_link_count,reportDate,
            CURRENT_DATE 
              FROM  replica_adtec.`tbl_ams_targets_reports_download_links_sb` 
            WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
            GROUP BY reportDate    ; 
        
              IF `_rollback` THEN
              INSERT INTO adtec_bi.`etl_logs`
                 ( `log_id`
                  , `Stored_Procedure_Name`
                  , `Execution_status`
                  , `LogDate`
                 )
                 VALUES
                 ( NULL
                  , 'spAMSTotalLink'
                  , 'RollBack'
                  , CURRENT_TIMESTAMP()
                 )
              ;
              
              ROLLBACK;
              ELSE
              INSERT INTO adtec_bi.`etl_logs`
                 ( `log_id`
                  , `Stored_Procedure_Name`
                  , `Execution_status`
                  , `LogDate`
                 )
                 VALUES
                 ( NULL
                  , 'spAMSTotalLink'
                  , 'Commit'
                  , CURRENT_TIMESTAMP()
                 )
              ;
              
              COMMIT;
              END
              IF;
              END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSTotalReportID` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSTotalReportID` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSTotalReportID`(in startdate varchar(50))
BEGIN
              DECLARE max_date DATE DEFAULT NULL ;
              DECLARE `_rollback` BOOL DEFAULT 0 ;
              
              
              DECLARE EXIT HANDLER FOR SQLEXCEPTION 
              BEGIN
                -- ERROR
                SELECT 
                  "Syntax Error" ;
                SET `_rollback` = 1 ;
                ROLLBACK ;
              END ;
              
             /* DECLARE EXIT HANDLER FOR SQLWARNING 
              BEGIN
                -- WARNING
                SELECT 
                  "Warning by DB" ;
                SET `_rollback` = 1 ;
                ROLLBACK;
              END ;
              
            */ 
             
             
              START TRANSACTION ;
              
             
              SET autocommit = 0 ;
            DELETE FROM replica_adtec.`tbl_ams_total_report_id` WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d");
            INSERT INTO replica_adtec.`tbl_ams_total_report_id`
            SELECT 
            NULL,
            reportType AS report_type_id , 
            COUNT(*) AS total_report_id, 
            reportDate ,
            CURRENT_DATE
            FROM replica_adtec.`tbl_ams_report_id`
             WHERE DATE_FORMAT(reportDate,"%Y-%m-%d") = DATE_FORMAT(startdate,"%Y-%m-%d")
             GROUP BY reportType ,
            reportDate
            ORDER BY 3 ASC
            ;
                    
              
              IF `_rollback` THEN
              INSERT INTO adtec_bi.`etl_logs`
                 ( `log_id`
                  , `Stored_Procedure_Name`
                  , `Execution_status`
                  , `LogDate`
                 )
                 VALUES
                 ( NULL
                  , 'spAMSTotalReportID'
                  , 'RollBack'
                  , CURRENT_TIMESTAMP()
                 )
              ;
              
              ROLLBACK;
              ELSE
              INSERT INTO adtec_bi.`etl_logs`
                 ( `log_id`
                  , `Stored_Procedure_Name`
                  , `Execution_status`
                  , `LogDate`
                 )
                 VALUES
                
                 ( NULL
                  , 'spAMSTotalReportID'
                  , 'Commit'
                  , CURRENT_TIMESTAMP()
                 )
              ;
              
              COMMIT;
              END
              IF;
              END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSTotalReportIDMandatory` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSTotalReportIDMandatory` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSTotalReportIDMandatory`()
BEGIN
              DECLARE max_date DATE DEFAULT NULL ;
              DECLARE `_rollback` BOOL DEFAULT 0 ;
              
              
              DECLARE EXIT HANDLER FOR SQLEXCEPTION 
              BEGIN
                -- ERROR
                SELECT 
                  "Syntax Error" ;
                SET `_rollback` = 1 ;
                ROLLBACK ;
              END ;
              
             /* DECLARE EXIT HANDLER FOR SQLWARNING 
              BEGIN
                -- WARNING
                SELECT 
                  "Warning by DB" ;
                SET `_rollback` = 1 ;
                ROLLBACK;
              END ;
              
            */ 
             
             
              START TRANSACTION ;
              
             
              SET autocommit = 0 ;
              
            
            DELETE FROM replica_adtec.`tbl_ams_report_id_mandatory` where reportDate =DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") ;
              INSERT INTO replica_adtec.`tbl_ams_report_id_mandatory`
            SELECT NULL,'SD_Product_Ads',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
               AND countrycode !='MX'
                GROUP BY  profileid
                HAVING cnt= 1)c
                UNION
            SELECT NULL,'AdGroup_SD',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
               AND countrycode !='MX'
                GROUP BY  profileid
                HAVING cnt= 1)c
                UNION
            SELECT NULL,'Campaign_SD',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
               AND countrycode !='MX'
                GROUP BY  profileid
                HAVING cnt= 1)c
                UNION
            SELECT NULL,'Product_Targeting_SD',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND countrycode !='MX'
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
                UNION
            SELECT NULL,'Campaign_SP',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
                UNION
            SELECT NULL,'AdGroup_SP',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
            
                UNION
            SELECT NULL,'Keyword_SP',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
                UNION
            SELECT NULL,'Product_Ads',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
            UNION
            SELECT NULL,'ASINs',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
                UNION
            SELECT NULL,'Product_Targeting',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
                UNION
            SELECT NULL,'Keyword_SB',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
            UNION
            SELECT NULL,'Campaign_SB',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
            UNION
            SELECT NULL,'AdGroup_SB',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
            UNION
            SELECT NULL,'Product_Targeting_SB',COUNT(total_report_id) AS cnt,
            DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY, "%Y%m%d") AS report_date, 
            CURRENT_DATE AS creation_date   FROM
            (SELECT COUNT(a.id) AS total_report_id,COUNT(a.profileid) AS cnt
                FROM replica_adtec.`tbl_ams_profiles`a
            LEFT JOIN `tbl_account` b ON (a.id = b.fkid)
             WHERE  isActive = 1
             AND TYPE != 'agency'
                GROUP BY  profileid
                HAVING cnt= 1)c
                ;
                  
          IF `_rollback` THEN
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSTotalReportIDMandatory'
              , 'RollBack'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          ROLLBACK;
          ELSE
          INSERT INTO adtec_bi.`etl_logs`
             ( `log_id`
              , `Stored_Procedure_Name`
              , `Execution_status`
              , `LogDate`
             )
             VALUES
             ( NULL
              , 'spAMSTotalReportIDMandatory'
              , 'Commit'
              , CURRENT_TIMESTAMP()
             )
          ;
          
          COMMIT;
          END
          IF;
          END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateKeywordTacos` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateKeywordTacos` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateKeywordTacos`(IN campaign_id BIGINT,IN keyword_id TEXT, IN reporttype VARCHAR(10), IN numofdays INT)
BEGIN
         SELECT
          `fkAccountId`,
          `fkProfileId`,
          `profile_name`,
          `campaignId`,
          `campaignName`,
          `adGroupId`,
          `adGroupName`,
          `keywordId`,
          `keywordText`,
          `matchType`,
          SUM(`impressions`) AS impression,
          SUM(`clicks`) AS clicks,
          SUM(`cost`) AS cost,
          SUM(`attributedConversions`) AS attributedConversions,
          SUM(`attributedConversionsSameSKU`) AS attributedConversionsSameSKU,
          SUM(`attributedUnitsOrdered`) AS attributedUnitsOrdered,
          SUM(`attributedSales`) AS  revenue,
          SUM(`attributedSalesSameSKU`) AS attributedSalesSameSKU,
            CASE
                WHEN  SUM(`impressions`) > 0 
                THEN ROUND(SUM(`clicks`) /  SUM(`impressions`), 2) 
                ELSE 0 
              END AS ctr,
              CASE
                WHEN SUM(`attributedSales`)  > 0 
                THEN ROUND( SUM(`cost`) / SUM(`attributedSales`), 2) 
                ELSE 0 
              END AS `acos`,
              CASE
                WHEN SUM(`clicks`) > 0 
                THEN ROUND(SUM(`cost`) / SUM(`clicks`), 2) 
                ELSE 0.00 
              END AS cpc,
              CASE
                WHEN SUM(`cost`)  > 0 
                THEN ROUND(SUM(`attributedSales`) / SUM(`cost`) , 2) 
                ELSE 0.00 
              END AS roas,
              CASE
                WHEN SUM(`attributedUnitsOrdered`) > 0 
                THEN ROUND(SUM(`cost`) / SUM(`attributedUnitsOrdered`), 2) 
                ELSE 0.00 
              END AS cpa
        FROM replica_adtec.`tbl_rtl_ams_keyword`
        WHERE `reportDate` >= DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
        AND campaignId = campaign_id
        AND FIND_IN_SET(keywordId , keyword_id)
        AND report_type = reporttype
        GROUP BY 
          `fkAccountId`,
          `fkProfileId`,
          `profile_name`,
          `campaignId`,
          `campaignName`,
          `adGroupId`,
          `adGroupName`,
          `keywordId`,
          `keywordText`,
          `matchType` ;
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateTargetTacos` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateTargetTacos` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateTargetTacos`(IN campaign_id BIGINT, IN target_id TEXT, IN numofdays INT)
BEGIN
        SELECT
            `fkAccountId`,
            `fkProfileId`,
            -- `profile_name`,
            `campaignId`,
            `campaignName`,
            `adGroupId`,
            `adGroupName`,
            `targetId`,
            `targetingText`,
            SUM(`impressions`) AS impression,
            SUM(`clicks`) AS clicks,
            SUM(`cost`) AS cost,
            SUM(`attributedConversions14d`) AS attributedConversions,
            SUM(`attributedConversions14dSameSKU`) AS attributedConversionsSameSKU,
            SUM(`attributedUnitsOrdered14d`) AS attributedUnitsOrdered,
            SUM(`attributedSales14d`) AS revenue,
            SUM(`attributedSales14dSameSKU`) AS attributedSalesSameSKU,
            
            CASE
            WHEN SUM(`impressions`) > 0
            THEN ROUND(SUM(`clicks`) / SUM(`impressions`), 2)
            ELSE 0
            END AS ctr,
            CASE
            WHEN SUM(`attributedSales14d`) > 0
            THEN ROUND( SUM(`cost`) / SUM(`attributedSales14d`), 2)
            ELSE 0
            END AS `acos`,
            CASE
            WHEN SUM(`clicks`) > 0
            THEN ROUND(SUM(`cost`) / SUM(`clicks`), 2)
            ELSE 0.00
            END AS cpc,
            CASE
            WHEN SUM(`cost`) > 0
            THEN ROUND(SUM(`attributedSales14d`) / SUM(`cost`) , 2)
            ELSE 0.00
            END AS roas,
            
            CASE
            WHEN SUM(`attributedUnitsOrdered14d`) > 0
            THEN ROUND(SUM(`cost`) / SUM(`attributedUnitsOrdered14d`), 2)
            ELSE 0.00
            END AS cpa
            FROM replica_adtec.`tbl_ams_targets_reports_downloaded_data_sd_for_biding_rule`
            WHERE `reportDate` >= DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
            AND campaignId = campaign_id
            AND FIND_IN_SET(targetId , target_id)
            GROUP BY
            `fkAccountId`,
            `fkProfileId`,
            -- `profile_name`,
            `campaignId`,
             `campaignName`,
            `adGroupId`,
            `adGroupName`,
            `targetId`,
            targetingText;
            -- `keywordText`,
            -- `matchType` ;
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spAMSTacos` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAMSTacos` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAMSTacos`(
				   IN campaign_id BIGINT,
				   IN id TEXT,
				   IN reporttype VARCHAR(10),
				   IN numofdays INT,
				   IN report VARCHAR(30))
BEGIN
            IF report ='keyword' THEN
              CALL replica_adtec.`spCalculateKeywordTacos`( campaign_id , id ,  reporttype ,  numofdays );
            ELSEIF report = 'target' THEN
              CALL replica_adtec.`spCalculateTargetTacos`( campaign_id , id ,  numofdays );
              END
            IF;
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateKeywordLevelBidMultipler` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateKeywordLevelBidMultipler` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateKeywordLevelBidMultipler`(IN campaign_id BIGINT,IN keyword_id TEXT)
BEGIN
         SELECT 
			fkProfileId,
			campaignId,
			campaignName,
			keywordId,
			SUM(`impressions`) AS Impressions
			 FROM 
			`tbl_ams_keyword_reports_downloaded_data_sp`
			WHERE 
			`reportDate`> DATE_ADD(DATE_ADD(CURRENT_DATE, INTERVAL -1 DAY), INTERVAL -2 WEEK) 
			AND reportDate < CURRENT_DATE
			AND campaignId = campaign_id
				AND FIND_IN_SET(keywordId , keyword_id) 
			GROUP BY 
			`fkProfileId`,
			campaignId,
			campaignName,
			keywordId
        ;
        END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAccountClient` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAccountClient` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAccountClient`()
BEGIN
  -- DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
 /* DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
*/ 
 
 
  START TRANSACTION ;
  
 
  SET autocommit = 0 ;
  
		
  INSERT INTO `replica_adtec`.`tbl_rtl_account_client`
     ( `agency_id`
      , `Agency_Name`
      , `client_id`
      , `client_name`
      , `client_email`
      , `client_account_password`
      , `client_creation`
      , `client_updation`
      , `account_id`
      , `marketplaceid`
      , `account_type`
      , `account_type_name`
      , `fkId`
      , `accountName`
      , `account_creation`
      , `account_updation`
      , `LoadDate`
     )
     (
     SELECT * FROM 
(
        SELECT
           aa.`fkAgencyId` AS Agency_id
         , cc.name         AS Agency_Name
         , aa.`id`         AS client_id
         , aa.`name`       AS client_name
         , aa.`email`      AS client_email
         , aa.`password`   AS Client_account_password
         , aa.`created_at` AS client_creation
         , aa.`updated_at` AS Client_updation
         , bb.`id`         AS AccountID
         ,
            -- bb.`fkClientId` ,
           bb.`marketPlaceID` AS marketplaceid
         , bb.`fkAccountType` AS AccountType
         , dd.name            AS Account_TypeName
         , bb.`fkId`
         , CASE 
           WHEN bb.fkAccountType = 1 THEN ams.name
           WHEN bb.fkAccountType = 2 THEN sc.merchant_name
           WHEN bb.fkAccountType = 3 THEN vc.vendor_name
           END AS AccountName
        -- , bb.`accountName`
         , bb.`created_at`     AS account_creation
         , bb.`updated_at`     AS account_updation
         , CURRENT_TIMESTAMP() AS LoadDate
        FROM
           `replica_adtec`.`tbl_brands` aa
           LEFT JOIN
              `replica_adtec`.`tbl_account` bb
              ON
                 (
                    aa.id = bb.`fkBrandId`
                 )
                 
           LEFT JOIN   `tbl_ams_profiles` ams 
           ON  CASE WHEN fkAccountType = 1 THEN  bb.fkid END = ams.id
           LEFT JOIN   `tbl_sc_config` sc 
           ON  CASE WHEN fkAccountType = 2 THEN  bb.fkid END = sc.mws_config_id
           LEFT JOIN    `tbl_vc_vendors` vc 
           ON  CASE WHEN fkAccountType = 3  THEN  bb.fkid END = vc.vendor_id
      
           LEFT JOIN
              `replica_adtec`.tbl_account_type dd
              ON
                 (
                    dd.id = bb.`fkAccountType`
                 )
           LEFT JOIN
              `replica_adtec`.tbl_agency cc
              ON
                 (
                    aa.`fkAgencyId` = cc.id
                 )
                 
                 )t
        WHERE t.`accountName` IS NOT NULL
 
     )
  ;
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAccountClient'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAccountClient'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSAdGroup` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSAdGroup` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSAdGroup`(IN `max_date` VARCHAR(20))
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO tbl_rtl_ams_adgroup
   ( `fkBatchId`
    , `fkAccountId`
    , `fkProfileId`
    , `profile_name`
    , `campaignId`
    , `campaignName`
    , `adGroupId`
    , `adGroupName`
    , `report_type`
    , `impressions`
    , `clicks`
    , `cost`
    , `attributedConversions`
    , `attributedConversionsSameSKU`
    , `attributedUnitsOrdered`
    , `attributedSales`
    , `attributedSalesSameSKU`
    , `reportDate`
    , `creationDate`
   )
   (
      SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `adGroupId`
       , `adGroupName`
       , 'SP'      AS report_type
       , `impressions`
       , `clicks`
       , cast(`cost` as decimal(19,2)) as `cost` 
       , `attributedConversions30d`         AS `attributedConversions`
       , `attributedConversions30dSameSKU`  AS `attributedConversionsSameSKU`
       , `attributedUnitsOrdered30d`     AS `attributedUnitsOrdered`
       , cast(`attributedSales30d` as decimal(19,2))            AS `attributedSales`
       , cast(`attributedSales30dSameSKU` as decimal(19,2))     AS `attributedSalesSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_adgroup_reports_downloaded_data_sp` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = max_date
      UNION
      SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `adGroupId`
	   , `adGroupName`
       , 'SB'      AS report_type
       , `impressions`
       , `clicks`
       , cast(`cost`AS DECIMAL(19,2)) as `cost`
       , 0                    AS `attributedConversions`
       , 0                    AS `attributedConversionsSameSKU`
       , 0                    AS`attributedUnitsOrdered`
       , cast(`attributedSales14d` as decimal(19,2)) AS `attributedSales`
       , 0                    AS `attributedSalesSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_adgroup_reports_downloaded_data_sb` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = max_date
      UNION
      SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `adGroupId`
	   , `adGroupName`
       , 'SD'      AS report_type
       , `impressions`
       , `clicks`
       , cast(`cost` as decimal(19,2)) as `cost`
       , 0 AS `attributedConversions`
       , 0 AS `attributedConversionsSameSKU`
       , 0 AS`attributedUnitsOrdered`
       , 0 AS `attributedSales`
       , 0 AS `attributedSalesSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_adgroup_reports_downloaded_data_sd` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = max_date
   )
;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSAdGroup'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSAdGroup'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSASIN` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSASIN` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSASIN`(IN `max_date` VARCHAR(20))
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO tbl_rtl_ams_asin
   (     `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , `profile_name`
       , `campaignId`
       , `campaignName`
       , `adGroupId`
       , `adGroupName`
       , `keywordId`
       , `keywordText` 
       , `asin`
       , `otherAsin`
       , `sku`
       , `currency`
       , `matchType`
       , report_type
       , `attributedUnitsOrdered`
       , `attributedSalesOtherSKU`
       , `attributedUnitsOrderedOtherSKU`	
       , `reportDate`
       , `creationDate`
   )
   (
SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `adGroupId`
       , `adGroupName`
       , `keywordId`
       , `keywordText` 
       , `asin`
       , `otherAsin`
       , `sku`
       , `currency`
       , `matchType`
       , 'SP' AS `report_type`
       , `attributedUnitsOrdered30d`             AS `attributedUnitsOrdered`
       , `attributedSales30dOtherSKU`            AS `attributedSalesOtherSKU`
       , `attributedUnitsOrdered30dOtherSKU`     AS `attributedUnitsOrderedOtherSKU`	   
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_asin_reports_downloaded_sp` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = `max_date`
   )
;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSASIN'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSASIN'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSCampaign` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSCampaign` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSCampaign`(IN `max_date` VARCHAR(20))
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
   SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
   END ;
  
  /*
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
  
    
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
 */
 
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO tbl_rtl_ams_campaign
   ( `fkBatchId`
    , `fkAccountId`
    , `fkProfileId`
    , `profile_name`
    , `campaignId`
    , `campaignName`
    , `campaignStatus`
    , `campaignBudget`
    , `campaign_budget_type`
    , `campaign_type`
    , `impressions`
    , `clicks`
    , `cost`
    , `attributedConversions`
    , `attributedConversionsSameSKU`
    , `attributedUnitsOrdered`
    , `attributedSales`
    , `attributedSalesSameSKU`
    , `reportDate`
    , `creationDate`
   )
   (
      SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `campaignStatus`
       , `campaignBudget`
       , 'Monthly' AS campaignBudgetType
       , 'SP'      AS campaign_type
       , `impressions`
       , `clicks`
       , CAST(`cost` AS DECIMAL (19,2)) AS `cost`
       , `attributedConversions30d`         AS `attributedConversions`
       , `attributedConversions30dSameSKU`  AS `attributedConversionsSameSKU`
       , `attributedUnitsOrdered30d`     AS `attributedUnitsOrdered`
       , CAST(`attributedSales30d` AS DECIMAL(19,2))            AS `attributedSales`
       , CAST(`attributedSales30dSameSKU` AS DECIMAL(19,2))     AS `attributedSalesSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_campaigns_reports_downloaded_sp` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = max_date
      UNION
      SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `campaignStatus`
       , `campaignBudget`
       , 'Monthly' AS campaignBudgetType
       , 'SB'      AS campaign_type
       , `impressions`
       , `clicks`
       , CAST(`cost` AS DECIMAL (19,2)) AS `cost`
       , 0                    AS `attributedConversions`
       , 0                    AS `attributedConversionsSameSKU`
       , `UnitsSold14d`       AS `attributedUnitsOrdered`
       , CAST(`attributedSales14d` AS DECIMAL(19,2)) AS `attributedSales`
       , 0                    AS `attributedSalesSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_campaigns_reports_downloaded_sb` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = max_date
      UNION
      SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , 'Not Available' AS `campaignStatus`
       , 0         AS `campaignBudget`
       , 'Monthly' AS campaignBudgetType
       , 'SD'      AS campaign_type
       , `impressions`
       , `clicks`
       , CAST(`cost` AS DECIMAL (19,2)) AS `cost`
       , 0 AS `attributedConversions`
       , 0 AS `attributedConversionsSameSKU`
       , 0 AS`attributedUnitsOrdered`
       , CAST(`attributedSales14d` AS DECIMAL(19,2)) AS `attributedSales`
       , 0 AS `attributedSalesSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.tbl_ams_campaigns_reports_downloaded_sd a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = max_date
   )
;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSCampaign'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSCampaign'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
 
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSCampaignList` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSCampaignList` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSCampaignList`()
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO tbl_rtl_ams_campaign_list
   ( 
   fkAccountId, 
   fkProfileId,
   ProfileId,
   campaignId,
   campaignName,
   campaign_type
   )
   (
      SELECT DISTINCT
   
          
         `fkAccountId`
       , b.id AS fkProfileId
       , `fkProfileId` AS ProfileId
       , `campaignId`
       , `campaignName`
       , 'SP' AS campaign_type
     
      FROM
         `replica_adtec`.`tbl_ams_campaigns_reports_downloaded_sp` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
               
      UNION
      SELECT DISTINCT
         `fkAccountId`
       , b.id AS fkProfileId
       , `fkProfileId` AS ProfileId
       , `campaignId`
       , `campaignName`
       , 'SB' AS campaign_type
      FROM
         `replica_adtec`.`tbl_ams_campaigns_reports_downloaded_sb` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
  
      UNION
      SELECT DISTINCT
         `fkAccountId`
       , b.id AS fkProfileId
       , `fkProfileId` AS ProfileId
       , `campaignId`
       , `campaignName`
       , 'SD'      AS campaign_type
      FROM
         `replica_adtec`.tbl_ams_campaigns_reports_downloaded_sd a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
   
   )
;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSCampaignList'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSCampaignList'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSKeyword` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSKeyword` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSKeyword`(IN `max_date` VARCHAR(20))
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec`.tbl_rtl_ams_keyword_new
   ( `fkBatchId`
    , `fkAccountId`
    , `fkProfileId`
    , `profile_name`
    , `campaignId`
    , `campaignName`
    , `adGroupId`
    , `adGroupName`
    , `keywordId`
    , `keywordText`
    , `matchType`
    , `report_type`
    , `impressions`
    , `clicks`
    , `cost`
    , `attributedConversions`
    , `attributedConversionsSameSKU`
    , `attributedUnitsOrdered`
    , `attributedSales`
    , `attributedSalesSameSKU`
    , `reportDate`
    , `creationDate`
   )
   (
          SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , coalesce(`adGroupId`, -1)   AS `adGroupId`
       , coalesce(`adGroupName`,'N/A') AS `adGroupName` 
       , `keywordId`
       , `keywordText`
       , `matchType`
       , 'SP' as `report_type`
       , `impressions`
       , `clicks`
       , `cost`
       , `attributedConversions30d`
       , `attributedConversions30dSameSKU`
       , `attributedUnitsOrdered30d`
       , `attributedSales30d`
       , `attributedSales30dSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.tbl_ams_keyword_reports_downloaded_data_sp a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         reportDate = max_date
    UNION
    SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `adGroupId`
       , `adGroupName`
       , COALESCE(`keywordId`,-1) as `keywordId`
       , `keywordText`
       , `matchType`
       , 'SB' AS `report_type`
       , `impressions`
       , `clicks`
       , `cost`
       , `attributedConversions14d`
       , `attributedConversions14dSameSKU`
       , `attributedUnitsOrderedNewToBrand14d`
       , `attributedSales14d`
       , `attributedSales14dSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_keyword_reports_downloaded_data_sb` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         reportDate = max_date
   )
;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSKeyword'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSKeyword'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSKeywordNew` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSKeywordNew` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSKeywordNew`()
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO replica_adtec.tbl_rtl_ams_keyword (  `fkBatchId` ,
  `fkAccountId` ,
  `fkProfileId` ,
  `profile_name` ,
  `campaignId` ,
  `campaignName`, 
  `adGroupId` ,
  `adGroupName`, 
  `keywordId` ,
  `keywordText`, 
  `matchType` ,
  `report_type`, 
  `impressions`,
  `clicks` ,
  `cost` ,
  `attributedConversions` ,
  `attributedConversionsSameSKU` ,
  `attributedUnitsOrdered` ,
  `attributedSales` ,
  `attributedSalesSameSKU` ,
  `reportDate` ,
  `creationDate`)
SELECT   
  `fkBatchId`   ,
  `fkAccountId` ,
  `fkProfileId` ,
  `profile_name` ,
  `campaignId` ,
  `campaignName`, 
  `adGroupId` ,
  `adGroupName`, 
  `keywordId` ,
  `keywordText`, 
  `matchType` ,
  `report_type`, 
  `impressions`,
  `clicks` ,
  `cost` ,
  `attributedConversions` ,
  `attributedConversionsSameSKU` ,
  `attributedUnitsOrdered` ,
  `attributedSales` ,
  `attributedSalesSameSKU` ,
  `reportDate` ,
  `creationDate`
FROM tbl_rtl_ams_keyword_new;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSKeywordNew'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSKeywordNew'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSProdAds` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSProdAds` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSProdAds`(IN `max_date` VARCHAR(20))
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO tbl_rtl_ams_product_ads
   ( `fkBatchId`
    , `fkAccountId`
    , `fkProfileId`
    , `profile_name`
    , `campaignId`
    , `campaignName`
    , `adGroupId`
    , `adGroupName`
    , `report_type`
	, `adId`
	, `asin`
	, `sku`
    , `impressions`
    , `clicks`
    , `cost`
    , `attributedConversions`
    , `attributedConversionsSameSKU`
    , `attributedUnitsOrdered`
    , `attributedSales`
    , `attributedSalesSameSKU`
    , `attributedUnitsOrderedSameSKU`	
    , `reportDate`
    , `creationDate`
   )
   (
      SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `adGroupId`
       , `adGroupName`
       , 'SP'      AS report_type
       , `adId`
       , `asin`
       , `sku`
       , `impressions`
       , `clicks`
       , `cost` 
       , `attributedConversions30d`             AS `attributedConversions`
       , `attributedConversions30dSameSKU`      AS `attributedConversionsSameSKU`
       , `attributedUnitsOrdered30d`            AS `attributedUnitsOrdered`
       , `attributedSales30d`                   AS `attributedSales`
       , `attributedSales30dSameSKU`            AS `attributedSalesSameSKU`
       , `attributedUnitsOrdered30dSameSKU`     AS `attributedUnitsOrderedSameSKU`	   
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_productsads_reports_downloaded_data` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = max_date
      UNION
      SELECT
         `fkBatchId`
       , `fkAccountId`
       , `fkProfileId`
       , b.`name` AS `profile_name`
       , `campaignId`
       , `campaignName`
       , `adGroupId`
       , `adGroupName`
       , 'SD'      AS report_type
       , 0     AS `ad_id`
       , `asin`
       , `sku`
       , `impressions`
       , `clicks`
       , `cost`
       , `attributedConversions30d`                     AS `attributedConversions`
       , `attributedConversions30dSameSKU`              AS `attributedConversionsSameSKU`
       , `attributedUnitsOrdered30d`                    AS`attributedUnitsOrdered`
       , `attributedSales30d`                           AS `attributedSales`
       , `attributedSales30dSameSKU`                    AS `attributedSalesSameSKU`
       , 0                                              AS `attributedUnitsOrderedSameSKU`
       , `reportDate`
       , a.`creationDate`
      FROM
         `replica_adtec`.`tbl_ams_productsads_reports_downloaded_data_sd` a
         LEFT JOIN
            tbl_ams_profiles b
            ON
               (
                  a.`fkProfileId` = b.`profileId`
               )
      WHERE
         LEFT(fkBatchId,8) = `max_date`
   )
;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSProdAds'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSProdAds'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSProfile` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSProfile` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSProfile`()
BEGIN
   DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
  
INSERT INTO tbl_rtl_ams_profile
   ( `profile_id`
    , `profile_name`
    , `isActive`
   )
   (
      SELECT
         `profileId`
       , `NAME`
       , `isActive`
      FROM
         `replica_adtec`.`tbl_ams_profiles` a
      WHERE
         profileId IS NOT NULL
);
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSProfile'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSProfile'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLAMSTarget` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLAMSTarget` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLAMSTarget`(IN `max_date` VARCHAR(20))
BEGIN
    DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    -- ERROR
    SELECT 
      'Syntax Error' ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      'Warning by DB';
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
DELETE FROM `replica_adtec`.tbl_ams_targets_reports_downloaded_data_sd_for_biding_rule WHERE reportDate = max_date;
INSERT INTO `replica_adtec`.`tbl_ams_targets_reports_downloaded_data_sd_for_biding_rule`
   ( `fkBatchId`
    , `fkAccountId`
    , `fkProfileId`
    , `fkConfigId`
    , `campaignId`
    , `campaignName`
    , `adGroupId`
    , `adGroupName`
    , `targetId`
    , `targetingText`
    , `impressions`
    , `clicks`
    , `cost`
    , `currency`
    , `attributedConversions14d`
    , `attributedConversions14dSameSKU`
    , `attributedUnitsOrdered14d`
    , `attributedSales14d`
    , `attributedSales14dSameSKU`
    , `reportDate`
    , `creationDate`
   )
   (
          SELECT
           `fkBatchId`
         , `fkAccountId`
         , `fkProfileId`
         , `fkConfigId`
         , `campaignId`
         , `campaignName`
         , `adGroupId`
         , `adGroupName`
         , `targetId`
         , `targetingText`
         , `impressions`
         , `clicks`
         , `cost`
         , `currency`
         , `attributedConversions14d`
         , `attributedConversions14dSameSKU`
         , `attributedUnitsOrdered14d`
         , `attributedSales14d`
         , `attributedSales14dSameSKU`
         , `reportDate`
         , CURRENT_DATE AS `creationDate`
      FROM `replica_adtec`.`tbl_ams_targets_reports_downloaded_data_sd`
      WHERE
         reportDate = max_date
   )
;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSTarget'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLAMSTarget'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLInventoryMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLInventoryMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLInventoryMaster`(IN `max_date` VARCHAR(20))
BEGIn   
  
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  
  SET autocommit = 0 ;
		
INSERT INTO `replica_adtec`.`tbl_rtl_inventory_master`
   ( `rtl_inven_id`
    , `fk_account_id`
    , `asins`
    , `sku`
    ,`fulfillment_channel`
    , `seller_inv_units`
    , `unseller_inv_units`
    , `capture_date`
    , `batchid`
    , `LoadDate`
   )
   (
      SELECT  DISTINCT
         null,
         t.`fkAccountId`
       ,t.`asin`
       , COALESCE(t.sku,'N/A')                AS SKU
       , t.fulfillmentchannel as  fulfillmentchannel
       , COALESCE(SUM(sellableQuantity), 0)      sellableQuantity
       , COALESCE(SUM(unsellableQuantity), 0)    unsellableQuantity
       , t.CreatedAt                          AS capture_date
       ,t.`fkBatchId`
       , CURRENT_TIMESTAMP() AS Load_Date
      FROM
         (
            SELECT DISTINCT
               `fkBatchId`
             , `fkAccountId`
             ,`asin1`                      AS `asin`
             , COALESCE(`sellerSku`,'N/A') AS SKU
             , fulfillmentchannel
             , DATE(createdAt)                createdAt
            FROM
               `replica_adtec`.`tbl_sc_inventory_cat_active_report`
            WHERE
               LEFT(`fkBatchId`,8) = `max_date`
         )
         t
         LEFT JOIN
            `replica_adtec`.tbl_sc_inventory_fba_health_report aa
            ON
               (
                  aa.`fkBatchId`       = t.`fkBatchId`
                  AND aa.`fkAccountId` = t.`fkAccountId`
                  AND aa.`asin`        = t.`asin`
                  AND aa.`sku`         = t.sku
               )
      GROUP BY
         t.`fkAccountId`
       ,t.`asin`
       , COALESCE(t.sku,'N/A')
       , t.CreatedAt
       ,t.`fkBatchId`
       ,t.fulfillmentchannel
         -- ----------------------------------------------------------------------------
         UNION
         -- ----------------------------------------------------------------------------
        SELECT  DISTINCT NULL, `fkAccountId`,`asin`, 'N/A' AS SKU ,'N/A' as fulfillmentchannel,
        
           COALESCE(`sellable_on_hand_units`, 0) AS  sellableQuantity,
         COALESCE(`unsellable_on_hand_units`, 0) AS unsellableQuantity ,
           DATE(created_At)  AS capture_date ,batchid AS `fkBatchId`, CURRENT_TIMESTAMP() AS Load_Date
         FROM `replica_adtec`.`tbl_vc_daily_inventory` WHERE LEFT(`BatchId`,8) = `max_date`
         -- -----------------------------------------------------------------------------
   )
;
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLInventoryMaster'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLInventoryMaster'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLManager` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLManager` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLManager`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
 /* DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
*/ 
 
 
  START TRANSACTION ;
  
 
  SET autocommit = 0 ;
  
		
  INSERT INTO `replica_adtec`.`tbl_rtl_manager`
     ( 
	`id`,
	`Manager_id`,
	`Brand_id`,
	`Manager_name`,
	`created_at`,
	`updated_at`,
	`deleted_at`
	)
     (
        SELECT  
        Null,
	aa.`id` AS `Manager_id`,
	bb.`fkBrandId` AS `Brand_id`,
	aa.`name` AS `Manager_name`,
	bb.`created_at`,
	bb.`updated_at`,
	bb.`deleted_at`
        FROM
           `replica_adtec`.`users` aa
           INNER JOIN
              `replica_adtec`.`tbl_brand_association` bb
              ON
                 (
                    aa.`id` = bb.`fkManagerId`
                 )
         
     )
  ;
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLManager'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLManager'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLProductCatalogSC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLProductCatalogSC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLProductCatalogSC`(IN `max_date` VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
   
   
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
	
	
INSERT INTO `replica_adtec`.`tbl_rtl_product_catalog`
SELECT DISTINCT
   NULL
 , t.fkAccountId
 ,'N/A' AS last_refresh
 , t.asin
 , t.sku
 , COALESCE(ee.model,'N/A') AS model
 , t.fulFillmentChannel     AS fulfillment_channel
 , t.sc_status
 , t.vc_status
 , 'N/A'                                        AS upc
 , COALESCE(ee.releaseDate,'0000-00-00')        AS release_date
 , COALESCE(ee.color,'N/A')                     AS color
 , COALESCE(ee.size,'N/A')                      AS size
 , CAST(dd.Price AS DECIMAL (19,2))            AS price
 , COALESCE(ee.itemWidth,'0.00')                AS product_width
 , COALESCE(ee.itemLength,'0.00')               AS product_length
 , COALESCE(ee.itemHeight,'0.00')               AS product_height
 , COALESCE(ee.itemWeight,'0.00')               AS product_ship_weight
 , COALESCE(ee.brand,'N/A')                     AS brand
 , COALESCE(ee.manufacturer,'N/A')              AS manufacturer
 , COALESCE(ee.binding,'N/A')                   AS binding
 , COALESCE(ee.productGroup,'N/A')              AS product_group
 , COALESCE(ee.productTypeName,'N/A')           AS product_type
 , COALESCE(ee.title,'N/A')                     AS product_title
 , COALESCE(ee.parentAsin,-1)                   AS parent_asin
 , COALESCE(ff.category_id,-1)                  AS category_id
 , COALESCE(ff.category_name,'N/A')             AS category_name
 , COALESCE(ff.subcategory_id,-1)               AS subcategory_id
 , COALESCE(ff.subcategory_name,'N/A')          AS subcategory_name
 , COALESCE(ff.sales_rank,-1)                   AS salesRank
 , DATE_FORMAT(LEFT(t.fkBatchId,8), "%Y-%m-%d") AS capture_date
 , t.fkBatchId                                  AS BatchId
 , CURRENT_TIMESTAMP()                          AS Load_Date
FROM
   (
   /*
      SELECT DISTINCT
         fkBatchId
       , fkAccountId
       , ASIN
       , COALESCE(sku,'N/A')                AS sku
       , COALESCE(fulFillmentChannel,'N/A') AS fulFillmentChannel
       , 0                                  AS vc_status, 1 AS sc_status
       , DATE(createdAt)                    AS createdAt
      FROM
         `replica_adtec`.tbl_sc_sales_orders_report
      WHERE
         LEFT(`fkBatchId`,8) = `max_date`
         AND orderstatus     = 'Shipped'
         
      UNION
      */
      SELECT DISTINCT
         fkBatchId
       , fkAccountId
       , ASIN
       , COALESCE(sku,'N/A')                AS sku
       , COALESCE(fulFillmentChannel,'N/A') AS fulFillmentChannel
       , 0                                  AS vc_status, 1 AS sc_status
       , DATE(createdAt)                    AS createdAt
      FROM
         `replica_adtec`.tbl_sc_sales_orders_updt_report
      WHERE
         LEFT(`fkBatchId`,8) = `max_date`
         AND orderstatus     = 'Shipped'
      UNION
      SELECT DISTINCT
         fkBatchId
       , fkAccountId
       , asin1                              AS ASIN
       , COALESCE(sellersku,'N/A')          AS sku
       , COALESCE(fulFillmentChannel,'N/A') AS fulFillmentChannel
       , 0                                  AS vc_status, 1 AS sc_status
       , DATE(createdAt)                    AS createdAt
      FROM
         `replica_adtec`.tbl_sc_inventory_cat_active_report
      WHERE
         LEFT(`fkBatchId`,8) = `max_date`
   )
   t
   LEFT JOIN
      (
         SELECT
            fkAccountId
          , asin1
          ,`fkBatchId`
          , COALESCE(sellersku,'N/A') sellersku
          , fulfillmentchannel
          , price AS price
         FROM
            `replica_adtec`.tbl_sc_inventory_cat_active_report
         WHERE
            LEFT(`fkBatchId`,8) = `max_date`
      )
      dd
      ON
         (
            dd.fkAccountId           = t.fkAccountId
            AND dd.asin1             = t.asin
            AND t.fulfillmentchannel = COALESCE(dd.FulfillmentChannel,'N/A')
            AND t.sku                = COALESCE(sellersku,'N/A')
         )
   LEFT JOIN
      (
         SELECT *
         FROM
            `replica_adtec`.tbl_sc_product_details
         WHERE
            isActive         = 1
            AND SOURCE       = 'SC'
            AND currencycode = 'USD'
      )
      ee
      ON
         (
            ee.fkAccountId = t.fkAccountId
            AND ee.asin    = t.asin
         )
   LEFT JOIN
      (
         SELECT *
         FROM
            replica_adtec.tbl_rtl_product_salesrank
      )
      ff
      ON
         (
            ff.fk_account_id = t.fkAccountId
            AND ff.asin      = t.asin
         )
;
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLProductCatalogSC'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLProductCatalogSC'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLProductSalesRank` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLProductSalesRank` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLProductSalesRank`(IN `max_date` VARCHAR(20))
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
 
 
  START TRANSACTION ;
  
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec`.`tbl_rtl_product_salesrank`
SELECT DISTINCT
   NULL
 , t.fkAccountId
 , t.asin
 , t.productCategoryIdd
 , t.productCategory
 , t.subcategoryId
 , t.subcategoryName
 ,
    -- t.salesRnk,
    sales.salesrank AS salesRnk
 , t.fkBatchId
 , CURRENT_TIMESTAMP() AS Load_Date
FROM
   (
      SELECT *
      FROM
         (
            SELECT
               aa.fksellerconfigid
             , aa.asin
             , aa.fkAccountId
             , aa.fkBatchId
             , CASE
                  WHEN aa.categoryTreeSequence = t.categoryTreeSequence
                     THEN aa.productcategoryid
                     ELSE ' '
               END AS productCategoryIdd
             , CASE
                  WHEN aa.categoryTreeSequence = t.categoryTreeSequence
                     THEN aa.productcategoryName
                     ELSE ' '
               END AS productCategory
             ,
                -- CASE WHEN  t.categoryTreeSequence IS NULL THEN aa.productcategoryName ELSE ' ' END AS SubproductCategory,
                subcategoryid
             , subcategoryName
            FROM
               `replica_adtec`.`tbl_sc_product_category_details` aa
               LEFT JOIN
                  (
                     SELECT
                        fkAccountId
                      , ASIN
                      , MAX(categoryTreeSequence) categoryTreeSequence
                     FROM
                        `replica_adtec`.tbl_sc_product_category_details
                     WHERE
                        SOURCE                 = 'SC'
                        AND categorytreenumber = 1
                     GROUP BY
                        fkAccountId
                      , ASIN
                  )
                  t
                  ON
                     (
                        t.`fkAccountId`            = aa.`fkAccountId`
                        AND t.ASIN                 = aa.`asin`
                        AND t.categoryTreeSequence = aa.`categoryTreeSequence`
                     )
               LEFT JOIN
                  (
                     SELECT
                        fkAccountId
                      , ASIN
                      , productcategoryid    AS subcategoryid
                      , productcategoryName  AS subcategoryName
                      , categoryTreeSequence AS categoryTreeSequenceMin
                     FROM
                        `replica_adtec`.tbl_sc_product_category_details
                     WHERE
                        categoryTreeSequence   = 1
                        AND SOURCE             = 'SC'
                        AND categorytreenumber = 1
                  )
                  min_t
                  ON
                     (
                        min_t.`fkAccountId` = aa.`fkAccountId`
                        AND min_t.ASIN      = aa.`asin`
                     )
            WHERE
               SOURCE                 = 'SC'
               AND categorytreenumber = 1 -- AND aa.ASIN = 'B011RBRVVQ'
            ORDER BY
               ASIN
             , aa.`categoryTreeSequence` DESC
         )
         t
      WHERE
         productCategoryIdd != ' '
   )
   t
   LEFT JOIN
      `replica_adtec`.tbl_sc_catalog_fba_health_report sales
      ON
         (
            t.`fkAccountId`    = sales.`fkAccountId`
            AND t.`asin`       =sales.`asin`
            AND sales.currency = 'USD'
         ) --   AND LEFT(sales.fkBatchID,8) = `max_date`
WHERE
   LEFT(sales.fkBatchID,8) = `max_date`
   -- WHERE LEFT(t.fkBatchId,8) = '20200126'
;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLProductSalesRank'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLProductSalesRank'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLPurchaseOrderMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLPurchaseOrderMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLPurchaseOrderMaster`(IN `max_date` VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 
 
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec`.`tbl_rtl_purchaseorder_master`
   ( `rtl_po_id`
    , `fk_account_id`
    , `po`
    , `hand_off_type`
    , `ship_location`
    , `model_number`
    , `asins`
    , `sku`
    , `title`
    , `po_status`
    , `delivery_window_start`
    , `delivery_window_end`
    , `backorder`
    , `expected_ship_date`
    , `confirmed_ship_date`
    , `case_size`
    , `submitted_cases`
    , `accepted_cases`
    , `received_cases`
    , `outstanding_cases`
    , `str_case_cost`
    , `str_total_cost`
    , `order_date`
    , `case_cost`
    , `total_cost`
    , `accepted_case`
    , `rejected_case`
    , `total_po_cost`
    , `capture_date`
    , `batchid`
    , `LoadDate`
   )
   (
      SELECT
         NULL
       , `fkaccountid` AS fk_account_id
       , `po`
       , `hand_off_type`
       , `ship_to_location` AS ship_location
       , `model_number`
       , `asin`
       , `sku`
       , `title`
       , `status` AS po_status
       , `delivery_window_start`
       , `delivery_window_end`
       , `backorder`
       , `expected_delivery_date`  AS expected_ship_date
       , `confirmed_delivery_date` AS confirmed_ship_date
       , `case_size`
       , `submitted_cases`
       , `accepted_cases`
       , `received_cases`
       , `outstanding_cases`
       , `case_cost`  AS str_case_cost
       , `total_cost` AS str_total_cost
       , `orderon_date`
       , `case_cost`
       , `total_cost`
       , `accepted_cases` * `case_cost`                                                                    AS accepted_case
       , ( `submitted_cases` - `accepted_cases` ) * `case_cost`                                            AS rejected_case
       , ( (`accepted_cases` * `case_cost`) + ( ( `submitted_cases` - `accepted_cases` ) * `case_cost` ) ) AS total_po_cost
       , capture_date                                                                                      AS capture_date
       , `batchId`
       , CURRENT_TIMESTAMP() AS LoadDate
      FROM
         `replica_adtec`.`tbl_vc_purchaseorders`
      WHERE
         LEFT(`batchId`,8) = `max_date`
   )
;
  
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLPurchaseOrderMaster'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLPurchaseOrderMaster'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLSaleMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLSaleMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLSaleMaster`(IN `max_date` VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 
 /*
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  */
  
  START TRANSACTION ;
  
  SET autocommit = 0 ;
  
	
INSERT INTO `replica_adtec`.`tbl_rtl_sale_master`
   (`rtl_sal_id`
    , `fk_account_id`
    , `asin`
    , `fulfillment_channel`
    , `sku`
    , `shipped_cogs`
    , `shipped_unit`
    , `shipped_cogs_last_year`
    , `shipped_units_last_year`
    , `capture_date`
    , `batchid`
    , `LoadDate`
   )
   (
      SELECT
         NULL
       , t.`fkAccountId`
       ,t.`asin`
       , t.fulfillmentchannel
       , sku
       , shipped_cogs
       , `shipped_units`
       , 0.0 AS `shipped_cogs_last_year`
       , 0 `shipped_units_last_year`
       , DATE(t.`createdAt`) AS createdAt
       ,t.`fkBatchId`
       , CURRENT_TIMESTAMP()
      FROM
         (
         /*
            SELECT
               `fkBatchId`
             ,`fkAccountId`
             ,`asin`
             , COALESCE(fulFillmentChannel,'N/A')                AS fulfillmentchannel
             , COALESCE(sku,'N/A')                                  sku
             , DATE(createdAt)                                      createdAt
             , SUM(COALESCE(CAST(itemprice AS DECIMAL(19,2)),0)) AS `shipped_cogs`
             , SUM(COALESCE(quantity,0))                         AS `shipped_units`
            FROM
               `replica_adtec`.`tbl_sc_sales_orders_report`
            WHERE
               LEFT(`fkBatchId`,8) = `max_date`
               AND orderstatus     = 'Shipped'
            GROUP BY
               `fkBatchId`
             ,`fkAccountId`
             ,`asin`
            , COALESCE(fulFillmentChannel,'N/A')
             , COALESCE(sku,'N/A')
            , DATE(createdAt)
            UNION
            */
            SELECT
               `fkBatchId`
             ,`fkAccountId`
             ,`asin`
             , COALESCE(fulFillmentChannel,'N/A')                AS fulfillmentchannel
             , COALESCE(sku,'N/A')                                  sku
             , DATE(createdAt)                                      createdAt
             , SUM(COALESCE(CAST(itemprice AS DECIMAL(19,2)),0)) AS `shipped_cogs`
             , SUM(COALESCE(CAST(quantity AS DECIMAL(19,2)),0))  AS `shipped_units`
            FROM
               `replica_adtec`.`tbl_sc_sales_orders_updt_report`
            WHERE
               LEFT(`fkBatchId`,8) = `max_date`
               AND orderstatus     = 'Shipped'
            GROUP BY
               `fkBatchId`
             ,`fkAccountId`
             ,`asin`
             , COALESCE(fulFillmentChannel,'N/A')
             , COALESCE(sku,'N/A')
             , DATE(createdAt)
         )
         t
         -- -----------------------------------------------------------------------------
           UNION
         -- -----------------------------------------------------------------------------
        SELECT  NULL, `fkaccountid` AS `fkAccountId`,`asin` ,'N/A' AS fulfillment_channel ,'N/A' AS sku ,
          SUM(COALESCE(CAST(`shipped_cogs` AS DECIMAL(19,2)),0)) `shipped_cogs`,SUM(COALESCE(`shipped_units`,0)) `shipped_units`,
         SUM(COALESCE(CAST(`shipped_cogs_last_year` AS DECIMAL(19,2)),0)) `shipped_cogs_last_year`,SUM(COALESCE(`shipped_units_last_year` ,0)) `shipped_units_last_year`,
          DATE(created_at) AS createdAt  ,LEFT(`BatchId`,8) AS `fkBatchId`,CURRENT_TIMESTAMP()
          FROM `replica_adtec`.`tbl_vc_daily_sales`  WHERE LEFT(`BatchId`,8) =  `max_date`
         GROUP BY  `fkaccountid`,`asin` ,DATE(created_at) ,LEFT(`BatchId`,8),CURRENT_TIMESTAMP()
         -- -----------------------------------------------------------------------------
   )
;
/*  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLSaleMaster'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLSaleMaster'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
  */
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLTruncates` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLTruncates` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLTruncates`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 
 
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
	
	TRUNCATE TABLE replica_adtec.`tbl_rtl_account_client`;
	TRUNCATE TABLE replica_adtec.`tbl_rtl_ams_profile`;
	TRUNCATE TABLE replica_adtec.`tbl_rtl_sale_master`;
	TRUNCATE TABLE replica_adtec.`tbl_rtl_inventory_master`;
	Truncate Table replica_adtec.`tbl_rtl_ams_keyword_new`;
	TRUNCATE TABLE replica_adtec.`tbl_rtl_purchaseorder_master`;
	TRUNCATE TABLE replica_adtec.`tbl_rtl_product_catalog`; 
	TRUNCATE TABLE replica_adtec.`tbl_rtl_product_salesrank`; 
	TRUNCATE TABLE replica_adtec.`tbl_rtl_ams_campaign`; 
	TRUNCATE TABLE replica_adtec.`tbl_rtl_ams_adgroup`; 
	TRUNCATE TABLE replica_adtec.`tbl_rtl_ams_product_ads`; 
	TRUNCATE TABLE replica_adtec.`tbl_rtl_ams_asin`; 
	TRUNCATE TABLE replica_adtec.`tbl_rtl_ams_campaign_list`;
	TRUNCATE TABLE replica_adtec.tbl_rtl_ams_asin_list;
	TRUNCATE TABLE replica_adtec.tbl_rtl_purchaseorder_master;
	TRUNCATE TABLE replica_adtec.tbl_rtl_scraping;
	
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLTruncates'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLTruncates'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLProductCatalogVC` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLProductCatalogVC` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLProductCatalogVC`(IN `max_date` VARCHAR (20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  -- ========================================================================
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  -- ========================================================================
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  -- ========================================================================
  START TRANSACTION ;
  -- ========================================================================
  SET autocommit = 0 ;
  -- ===============================================================================================
  INSERT INTO `replica_adtec`.`tbl_rtl_product_catalog` 
  SELECT 
    NULL,
    t.fk_account_id,
    'N/A' AS last_refresh
    ,t.asin,
    'N/A' AS sku,
    bb.model_style_number AS model,
    'N/A' AS fulfillment_channel,
    t.sc_status,
    t.vc_status,
    bb.upc,
    bb.release_date,
    bb.colour AS color,
    bb.apparel_size AS size,
    COALESCE(CAST(bb.list_price AS DECIMAL (9, 2)),- 1) AS price,
    bb.apparel_size_width AS product_width,
    '10 inches' AS product_length,
    '6 inches' AS product_height,
    '8.8 ounces' AS product_ship_weight,
    COALESCE(bb.brand, 'N/A') AS brand,
    bb.manufacturer_code AS manufacturer,
    bb.binding,
    bb.product_group,
    'N/A' AS product_type,
    COALESCE(bb.product_title, 'N/A') AS product_title,
    COALESCE(bb.parent_asin, - 1) AS parent_asin,
    COALESCE(ff.productCategoryId, - 1) AS category_id,
    COALESCE(ff.productCategoryName, 'N/A') AS category_name,
    COALESCE(ff.productSubCategoryId, - 1) AS subcategory_id,
    COALESCE(ff.productSubCategoryName,'N/A') AS subcategory_name,
    COALESCE(ff.salesRank, - 1) AS salesRank,
    t.capturedate AS capture_date,
    t.BatchId AS BatchId,
    CURRENT_TIMESTAMP() AS Load_Date 
  FROM
 
 (
SELECT DISTINCT BatchId,fk_account_id,ASIN,1 AS vc_status,0 AS sc_status,MAX(DATE(t.capture_date)) AS capturedate,MAX(DATE(t.createdAt)) AS createdAt
FROM
(
SELECT DISTINCT BatchId,fkaccountid AS fk_account_id,ASIN,1 AS vc_status,0 AS sc_status,DATE(rec_date) AS capture_date,DATE(created_At) AS createdAt 
FROM `replica_adtec`.tbl_vc_daily_inventory WHERE LEFT(`BatchId`, 8) = `max_date` 
UNION
SELECT DISTINCT BatchId,fkaccountid AS fk_account_id,ASIN,1 AS vc_status,0 AS sc_status,DATE(sale_date) AS capture_date,DATE(created_At) AS createdAt 
FROM `replica_adtec`.tbl_vc_daily_sales WHERE LEFT(`BatchId`, 8) = `max_date`
) t 
GROUP BY BatchId,fk_account_id,ASIN
) t 
LEFT JOIN `replica_adtec`.tbl_vc_product_catalog bb 
ON (bb.fkaccountid = t.fk_account_id AND bb.ASIN = t.ASIN AND LEFT(bb.BatchId, 8) = `max_date`)   
LEFT JOIN ( SELECT * FROM `replica_adtec`.tbl_sc_processed_sales_rank WHERE SOURCE = 'VC' AND DATE_FORMAT(createdAt, "%Y%m%d") = `max_date`) ff 
ON (ff.fkaccountid = t.fk_account_id AND ff.asin = t.asin AND SOURCE = 'VC' AND DATE_FORMAT(ff.createdAt, "%Y%m%d") = `max_date`) 
;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spRTLProductCatalogVC',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spRTLProductCatalogVC',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLProductCatalogSCLookup` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLProductCatalogSCLookup` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLProductCatalogSCLookup`(IN `max_date` VARCHAR(20))
BEGIN
    
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
UPDATE
   `replica_adtec`.`tbl_rtl_product_catalog` aa
   LEFT JOIN
      `replica_adtec`.tbl_sc_product_details bb
      ON
         (
            aa.fk_account_id   = bb.fkaccountid
            AND aa.asin        = bb.asin
            AND aa.price IS NULL
         )
         SET `price` = bb.itemamount WHERE LEFT(bb.fkbatchid,8) = `max_date`;
UPDATE
   `replica_adtec`.`tbl_rtl_product_catalog` aa
   LEFT JOIN
      `replica_adtec`.tbl_sc_sales_orders_updt_report bb
      ON
         (
            aa.fk_account_id   = bb.fkaccountid
            AND aa.asin        = bb.asin
            AND aa.price IS NULL
         )
         SET `price` = bb.itemprice WHERE LEFT(bb.fkbatchid,8) = `max_date`;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLProductCatalogSCLookup'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLProductCatalogSCLookup'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spRTLScraping` */

/*!50003 DROP PROCEDURE IF EXISTS  `spRTLScraping` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spRTLScraping`(IN `max_date` VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
 -- DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    -- ERROR
  --  SELECT 
   -- SET `_rollback` = 1 ;
   -- ROLLBACK ;
 -- END ;
 
 
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec`.`tbl_rtl_scraping`
   (   account_id
       , `asin`
       , total_reviews
       , reviews_count
       , average_review 
    , `capture_date`
    , `LoadDate`
   )
   (
      SELECT
         b.accountId
       , a.`asin`
       , totalReviews
      , CASE WHEN totalReviews = '0' THEN 0 ELSE TRIM(REPLACE(SUBSTRING(totalReviews,1,POSITION(' ' IN totalReviews)-1), ',', '')) END  AS reviews_count
       , averageReview 
       , capturedAt                                                                                     AS capture_date
       , CURRENT_TIMESTAMP() AS LoadDate
      FROM
         `replica_adtec`.`tbl_asins_result` a 
         inner join replica_adtec.`tbl_active_asins` b
         on a.asin = b.asin
      WHERE
         DATE_FORMAT(capturedAt,'%Y%m%d')= date_format(`max_date`,'%Y%m%d')
   )
;
  
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLScraping'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spRTLScraping'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateActiveAsinTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateActiveAsinTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateActiveAsinTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
 
 
  START TRANSACTION ;
  
 
  SET autocommit = 0 ;
truncate table `replica_adtec`.tbl_active_asins;
set max_date= (select max(rec_date) from `replica_adtec`.`tbl_vc_daily_inventory`);
insert into `replica_adtec`.tbl_active_asins(
accountId,
`asin`
)		
(
SELECT 	fkAccountId,ASIN FROM 	
(
SELECT fkAccountId,ASIN FROM `replica_adtec`.`tbl_vc_daily_inventory`  
WHERE rec_date = (SELECT MAX(rec_date) FROM `replica_adtec`.`tbl_vc_daily_inventory`)
UNION
SELECT `fkAccountId`,asin1 AS ASIN FROM `replica_adtec`.`tbl_sc_catalog_cat_active_report`
WHERE  reportRequestDate = (SELECT MAX(reportRequestDate) FROM `replica_adtec`.`tbl_sc_catalog_cat_active_report`)
)a
GROUP BY fkAccountId,ASIN
);
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateActiveAsinTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateActiveAsinTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spMasterRTL` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMasterRTL` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMasterRTL`(IN `max_date` VARCHAR(20))
BEGIN
	
	DECLARE `_rollback` BOOL DEFAULT 0;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	START TRANSACTION;
	
	SET autocommit = 0;
	
	CALL `replica_adtec`.spRTLTruncates();
	CALL `replica_adtec`.spRTLAccountClient();
	CALL `replica_adtec`.spRTLAMSProfile();
	CALL `replica_adtec`.spRTLSaleMaster(`max_date`);
	CALL `replica_adtec`.spRTLInventoryMaster(`max_date`);
	-- CALL `replica_adtec`.spRTLProductSalesRank(`max_date`);
	CALL `replica_adtec`.spRTLProductCatalogSC(`max_date`);
	CALL `replica_adtec`.spRTLProductCatalogSCLookup(`max_date`);
	CALL `replica_adtec`.spRTLProductCatalogVC(`max_date`);
	
	call `replica_adtec`.spRTLAMSCampaign(`max_date`);
	CALL `replica_adtec`.spRTLAMSAdgroup(`max_date`);
	CALL `replica_adtec`.spRTLAMSKeyword(`max_date`);
	CALL replica_adtec.spRTLAMSKeywordNew();
	CALL `replica_adtec`.spRTLAMSProdAds(`max_date`);
	CALL `replica_adtec`.spRTLAMSASIN(`max_date`);
	Call `replica_adtec`.spRTLAMSTarget(max_date);	
	CALL `spRTLPurchaseOrderMaster`(`max_date`);
	CALL `spRTLScraping`(`max_date`);
	CALL `replica_adtec`.spRTLAMSCampaignList();
	CALL `replica_adtec`.spRTLAMSASINLIST();
	CALL replica_adtec.`spPopulateActiveAsinTable`();
	call replica_adtec.`spUpdateTargetBiddingRule`(`max_date`);
	
	
IF `_rollback` THEN
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spMasterRTL'
    ,'RollBack'
    , CURRENT_TIMESTAMP()
   )
;
ROLLBACK;
ELSE
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spMasterRTL'
    ,'Commit'
    , CURRENT_TIMESTAMP()
   )
;
COMMIT;
END
IF;
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
