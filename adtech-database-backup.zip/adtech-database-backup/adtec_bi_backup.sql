/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 8.0.17 : Database - replica_adtec_bi
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`replica_adtec_bi` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

/*Table structure for table `dim_account` */

DROP TABLE IF EXISTS `dim_account`;

CREATE TABLE `dim_account` (
  `Account_Key` int(11) NOT NULL AUTO_INCREMENT,
  `Account_ID` bigint(20) unsigned NOT NULL,
  `Client_ID` int(11) NOT NULL,
  `marketplaceid` bigint(20) NOT NULL,
  `Account_Type` int(11) NOT NULL,
  `Account_Type_name` varchar(191) NOT NULL,
  `fkId` bigint(20) NOT NULL,
  `Account_Name` varchar(191) NOT NULL,
  `account_creation` timestamp NULL DEFAULT NULL,
  `account_updation` timestamp NULL DEFAULT NULL,
  `effective_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `flag` tinyint(4) NOT NULL,
  `load_date` date DEFAULT NULL,
  PRIMARY KEY (`Account_Key`)
) ENGINE=InnoDB AUTO_INCREMENT=1032 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_adgroup` */

DROP TABLE IF EXISTS `dim_adgroup`;

CREATE TABLE `dim_adgroup` (
  `adgroup_key` int(11) NOT NULL AUTO_INCREMENT,
  `camp_type_key` int(11) NOT NULL,
  `profile_key` bigint(20) NOT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `adgroup_id` bigint(20) NOT NULL,
  `adgroup_name` varchar(191) NOT NULL,
  `load_date` date DEFAULT NULL,
  `campaign_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`adgroup_key`)
) ENGINE=InnoDB AUTO_INCREMENT=32799 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_asins` */

DROP TABLE IF EXISTS `dim_asins`;

CREATE TABLE `dim_asins` (
  `asins_key` int(11) NOT NULL AUTO_INCREMENT,
  `camp_type_key` int(11) NOT NULL,
  `profile_key` bigint(20) NOT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `adgroup_id` bigint(20) NOT NULL,
  `adgroup_name` varchar(191) NOT NULL,
  `keyword_id` bigint(20) NOT NULL,
  `keyword_name` varchar(191) NOT NULL,
  `asin` varchar(40) DEFAULT NULL,
  `other_asin` varchar(1000) DEFAULT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `currency` varchar(50) DEFAULT NULL,
  `match_type` varchar(50) NOT NULL,
  `load_date` date DEFAULT NULL,
  `campaign_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`asins_key`)
) ENGINE=InnoDB AUTO_INCREMENT=734113 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_brand` */

DROP TABLE IF EXISTS `dim_brand`;

CREATE TABLE `dim_brand` (
  `Client_Key` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `Agency_Name` varchar(200) NOT NULL,
  `Client_ID` bigint(20) unsigned NOT NULL,
  `Client_Name` varchar(200) NOT NULL,
  `Client_Email` varchar(191) NOT NULL,
  `client_account_password` varchar(191) NOT NULL,
  `Client_Creation_date` timestamp NOT NULL,
  `client_updation_date` timestamp NOT NULL,
  `load_date` date DEFAULT NULL,
  PRIMARY KEY (`Client_Key`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_campaign` */

DROP TABLE IF EXISTS `dim_campaign`;

CREATE TABLE `dim_campaign` (
  `camp_key` int(11) NOT NULL AUTO_INCREMENT,
  `camp_type_key` int(11) NOT NULL,
  `profile_key` bigint(20) NOT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `campaign_status` varchar(50) DEFAULT NULL,
  `campaign_budget_type` varchar(50) DEFAULT NULL,
  `load_date` date DEFAULT NULL,
  `campaign_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`camp_key`),
  KEY `IDX_DIM_CAMPID_TYPEKEY` (`campaign_id`,`camp_type_key`)
) ENGINE=InnoDB AUTO_INCREMENT=29326 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_date` */

DROP TABLE IF EXISTS `dim_date`;

CREATE TABLE `dim_date` (
  `date_key` int(11) NOT NULL,
  `full_date` date DEFAULT NULL,
  `date_name` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `date_name_us` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `date_name_eu` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `day_of_week` tinyint(4) NOT NULL,
  `day_name_of_week` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `day_of_month` tinyint(4) NOT NULL,
  `day_of_year` smallint(6) NOT NULL,
  `weekday_weekend` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `week_of_month` tinyint(4) NOT NULL,
  `week_name_of_month` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `week_of_year` tinyint(4) NOT NULL,
  `week_name_of_year` char(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `month_name` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `month_of_year` tinyint(4) NOT NULL,
  `is_last_day_of_month` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `calendar_quarter` tinyint(4) NOT NULL,
  `calendar_year` smallint(6) NOT NULL,
  `calendar_year_month` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `calendar_year_qtr` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fiscal_month_of_year` tinyint(4) NOT NULL,
  `fiscal_quarter` tinyint(4) NOT NULL,
  `fiscal_year` int(11) NOT NULL,
  `fiscal_year_month` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fiscal_year_qtr` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Weekly_date_Range` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`date_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `dim_keyword` */

DROP TABLE IF EXISTS `dim_keyword`;

CREATE TABLE `dim_keyword` (
  `keyword_key` int(11) NOT NULL AUTO_INCREMENT,
  `camp_type_key` int(11) NOT NULL,
  `profile_key` bigint(20) NOT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `adgroup_id` bigint(20) NOT NULL,
  `adgroup_name` varchar(191) NOT NULL,
  `keyword_id` bigint(20) NOT NULL,
  `keyword_name` varchar(191) NOT NULL,
  `match_type` varchar(50) NOT NULL,
  `load_date` date DEFAULT NULL,
  `campaign_type` varchar(5) NOT NULL,
  PRIMARY KEY (`keyword_key`)
) ENGINE=InnoDB AUTO_INCREMENT=670111 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_manager` */

DROP TABLE IF EXISTS `dim_manager`;

CREATE TABLE `dim_manager` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Manager_id` bigint(20) unsigned NOT NULL,
  `Brand_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Manager_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `Flag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `dim_product` */

DROP TABLE IF EXISTS `dim_product`;

CREATE TABLE `dim_product` (
  `product_key` int(11) NOT NULL AUTO_INCREMENT,
  `camp_type_key` int(11) NOT NULL,
  `profile_key` bigint(20) NOT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(200) DEFAULT NULL,
  `adgroup_id` bigint(20) NOT NULL,
  `adgroup_name` varchar(191) NOT NULL,
  `ad_id` bigint(20) NOT NULL,
  `asin` varchar(40) NOT NULL,
  `sku` varchar(40) NOT NULL,
  `load_date` date NOT NULL,
  `campaign_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`product_key`)
) ENGINE=InnoDB AUTO_INCREMENT=126753 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_product_category_master` */

DROP TABLE IF EXISTS `dim_product_category_master`;

CREATE TABLE `dim_product_category_master` (
  `pm_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) NOT NULL,
  `ASIN` varchar(20) NOT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `category_name` varchar(150) DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `subcategory_name` varchar(150) DEFAULT NULL,
  `effective_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `flag` tinyint(4) NOT NULL,
  `load_date` date DEFAULT NULL,
  PRIMARY KEY (`pm_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1246 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_product_master` */

DROP TABLE IF EXISTS `dim_product_master`;

CREATE TABLE `dim_product_master` (
  `pm_key` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) NOT NULL,
  `ASIN` varchar(20) NOT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `fulfillment_channel` text,
  `sc_status` tinyint(4) DEFAULT NULL,
  `vc_status` tinyint(4) DEFAULT NULL,
  `load_date` date DEFAULT NULL,
  PRIMARY KEY (`pm_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1246 DEFAULT CHARSET=utf8;

/*Table structure for table `dim_product_master_attributes` */

DROP TABLE IF EXISTS `dim_product_master_attributes`;

CREATE TABLE `dim_product_master_attributes` (
  `pm_att_key` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) NOT NULL,
  `asin` varchar(20) NOT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `upc` varchar(20) NOT NULL,
  `release_date` date NOT NULL,
  `colour` varchar(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `size` varchar(50) NOT NULL,
  `product_length` varchar(50) NOT NULL,
  `product_width` varchar(50) NOT NULL,
  `product_height` varchar(50) NOT NULL,
  `parent_asin` varchar(20) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `manufacturer` varchar(50) NOT NULL,
  `product_group` varchar(100) NOT NULL,
  `product_type` varchar(50) NOT NULL,
  `binding` varchar(150) NOT NULL,
  `capture_date` timestamp NOT NULL,
  `last_refresh` date NOT NULL,
  `rec_refresh` date NOT NULL,
  `load_date` datetime NOT NULL,
  PRIMARY KEY (`pm_att_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `dim_product_master_attributes_transactions` */

DROP TABLE IF EXISTS `dim_product_master_attributes_transactions`;

CREATE TABLE `dim_product_master_attributes_transactions` (
  `pm_att_transac_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) NOT NULL,
  `ASIN` varchar(20) NOT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `upc` varchar(20) DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `color` varchar(100) DEFAULT NULL,
  `product_title` varchar(255) DEFAULT NULL,
  `size` varchar(50) DEFAULT NULL,
  `product_length` varchar(50) DEFAULT NULL,
  `product_width` varchar(50) DEFAULT NULL,
  `product_height` varchar(50) DEFAULT NULL,
  `parent_asins` varchar(20) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(150) DEFAULT NULL,
  `product_group` varchar(100) DEFAULT NULL,
  `product_type` varchar(50) DEFAULT NULL,
  `binding` varchar(150) DEFAULT NULL,
  `price` decimal(19,4) DEFAULT NULL,
  `product_ship_weight` varchar(50) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`pm_att_transac_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `dim_purchaseorder` */

DROP TABLE IF EXISTS `dim_purchaseorder`;

CREATE TABLE `dim_purchaseorder` (
  `po_key` int(11) NOT NULL AUTO_INCREMENT,
  `po` varchar(255) DEFAULT NULL,
  `hand_off_type` varchar(255) DEFAULT NULL,
  `ship_location` varchar(255) DEFAULT NULL,
  `model_number` varchar(255) DEFAULT NULL,
  `asins` varchar(255) NOT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `title` varchar(1000) DEFAULT NULL,
  `po_status` varchar(255) DEFAULT NULL,
  `delivery_window_start` varchar(255) DEFAULT NULL,
  `delivery_window_end` varchar(255) DEFAULT NULL,
  `backorder` varchar(30) DEFAULT NULL,
  `expected_ship_date` varchar(255) DEFAULT NULL,
  `confirmed_ship_date` varchar(255) DEFAULT NULL,
  `load_date` date DEFAULT NULL,
  PRIMARY KEY (`po_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `dim_scraping` */

DROP TABLE IF EXISTS `dim_scraping`;

CREATE TABLE `dim_scraping` (
  `scrap_key` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT NULL,
  `asin` varchar(50) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `LoadDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`scrap_key`)
) ENGINE=InnoDB AUTO_INCREMENT=1102 DEFAULT CHARSET=utf8;

/*Table structure for table `etl_logs` */

DROP TABLE IF EXISTS `etl_logs`;

CREATE TABLE `etl_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `Stored_Procedure_Name` varchar(200) NOT NULL,
  `Execution_status` varchar(200) NOT NULL,
  `LogDate` datetime DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43393 DEFAULT CHARSET=utf8;

/*Table structure for table `fact_ams_adgroup` */

DROP TABLE IF EXISTS `fact_ams_adgroup`;

CREATE TABLE `fact_ams_adgroup` (
  `client_key` int(11) NOT NULL,
  `account_key` int(11) NOT NULL,
  `date_key` int(11) NOT NULL,
  `adgroup_key` int(11) NOT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_fct_ams` (`adgroup_key`,`account_key`,`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `fact_ams_asins` */

DROP TABLE IF EXISTS `fact_ams_asins`;

CREATE TABLE `fact_ams_asins` (
  `client_key` int(11) NOT NULL,
  `account_key` int(11) NOT NULL,
  `date_key` int(11) NOT NULL,
  `asins_key` int(11) NOT NULL,
  `attributedunitsordered` int(11) DEFAULT NULL,
  `sales_other_sku` decimal(19,2) DEFAULT NULL,
  `units_ordered_other_sku` int(11) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_fct_ams` (`asins_key`,`account_key`,`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `fact_ams_campaign` */

DROP TABLE IF EXISTS `fact_ams_campaign`;

CREATE TABLE `fact_ams_campaign` (
  `client_key` int(11) NOT NULL,
  `account_key` int(11) NOT NULL,
  `date_key` int(11) NOT NULL,
  `camp_key` int(11) NOT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `campaign_budget` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_fct_ams` (`camp_key`,`account_key`,`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `fact_ams_keyword` */

DROP TABLE IF EXISTS `fact_ams_keyword`;

CREATE TABLE `fact_ams_keyword` (
  `client_key` int(11) NOT NULL,
  `account_key` int(11) NOT NULL,
  `date_key` int(11) NOT NULL,
  `keyword_key` int(11) NOT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_fct_ams` (`keyword_key`,`account_key`,`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `fact_ams_product` */

DROP TABLE IF EXISTS `fact_ams_product`;

CREATE TABLE `fact_ams_product` (
  `client_key` int(11) NOT NULL,
  `account_key` int(11) NOT NULL,
  `date_key` int(11) NOT NULL,
  `product_key` int(11) NOT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `order_units` int(11) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_fct_ams` (`product_key`,`batchid`,`account_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `fact_inventory_master` */

DROP TABLE IF EXISTS `fact_inventory_master`;

CREATE TABLE `fact_inventory_master` (
  `Client_Key` int(11) NOT NULL,
  `Account_Key` int(11) NOT NULL,
  `date_key` int(11) NOT NULL,
  `pm_key` int(11) NOT NULL,
  `pm_cat_id` int(11) NOT NULL,
  `sellable_inv_units` int(11) NOT NULL,
  `unsellable_inv_units` int(11) NOT NULL,
  `price` decimal(19,4) NOT NULL,
  `salesrank` bigint(20) NOT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_fct_inv` (`Account_Key`,`pm_cat_id`,`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `fact_purchaseorder` */

DROP TABLE IF EXISTS `fact_purchaseorder`;

CREATE TABLE `fact_purchaseorder` (
  `Client_Key` int(11) NOT NULL,
  `Account_Key` int(11) NOT NULL,
  `date_key` int(11) NOT NULL,
  `po_key` int(11) NOT NULL,
  `case_size` varchar(255) DEFAULT NULL,
  `submitted_cases` int(11) DEFAULT NULL,
  `accepted_cases` int(11) DEFAULT NULL,
  `received_cases` int(11) DEFAULT NULL,
  `outstanding_cases` int(11) DEFAULT NULL,
  `str_case_cost` varchar(50) DEFAULT NULL,
  `str_total_cost` varchar(50) DEFAULT NULL,
  `case_cost` int(11) DEFAULT NULL,
  `total_cost` int(11) DEFAULT NULL,
  `accepted_case` int(11) DEFAULT NULL,
  `rejected_case` int(11) DEFAULT NULL,
  `total_po_cost` int(11) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_fct_po` (`Account_Key`,`po_key`,`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `fact_sales_master` */

DROP TABLE IF EXISTS `fact_sales_master`;

CREATE TABLE `fact_sales_master` (
  `Client_Key` int(11) NOT NULL,
  `Account_Key` int(11) NOT NULL,
  `date_key` int(11) NOT NULL,
  `pm_key` int(11) NOT NULL,
  `pm_cat_id` int(11) NOT NULL,
  `shipped_cogs` decimal(19,2) NOT NULL,
  `shipped_units` int(11) NOT NULL,
  `shipped_cogs_last_year` decimal(19,2) NOT NULL,
  `shipped_units_last_year` int(11) NOT NULL,
  `price` decimal(19,2) NOT NULL,
  `salesrank` bigint(20) NOT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `fact_scraping` */

DROP TABLE IF EXISTS `fact_scraping`;

CREATE TABLE `fact_scraping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_key` int(11) DEFAULT NULL,
  `account_key` int(11) DEFAULT NULL,
  `date_key` int(11) DEFAULT NULL,
  `scrap_key` int(11) DEFAULT NULL,
  `total_reviews` varchar(500) DEFAULT NULL,
  `reviews_count` int(11) DEFAULT NULL,
  `average_review` decimal(19,2) DEFAULT NULL,
  `capture_date` varchar(50) DEFAULT NULL,
  `load_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103324 DEFAULT CHARSET=utf8;

/*Table structure for table `map_ams_campaign_taging` */

DROP TABLE IF EXISTS `map_ams_campaign_taging`;

CREATE TABLE `map_ams_campaign_taging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint(20) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  `tag` varchar(20) DEFAULT NULL,
  `tag_type` smallint(6) DEFAULT NULL,
  `unique_column` varchar(100) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `updation_date` timestamp NULL DEFAULT NULL,
  `load_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `map_ams_profile` */

DROP TABLE IF EXISTS `map_ams_profile`;

CREATE TABLE `map_ams_profile` (
  `profile_key` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) NOT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`profile_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2171 DEFAULT CHARSET=utf8;

/*Table structure for table `map_ams_report_type` */

DROP TABLE IF EXISTS `map_ams_report_type`;

CREATE TABLE `map_ams_report_type` (
  `camp_type_key` int(11) NOT NULL AUTO_INCREMENT,
  `camp_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`camp_type_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Table structure for table `map_category_override` */

DROP TABLE IF EXISTS `map_category_override`;

CREATE TABLE `map_category_override` (
  `category_id` bigint(20) DEFAULT NULL,
  `catgory_name` varchar(255) DEFAULT NULL,
  `override_category_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `map_product_override` */

DROP TABLE IF EXISTS `map_product_override`;

CREATE TABLE `map_product_override` (
  `asin` varchar(20) DEFAULT NULL,
  `product_title` varchar(255) DEFAULT NULL,
  `overrided_product_title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=289 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `prst_tbl_ams_adgroup` */

DROP TABLE IF EXISTS `prst_tbl_ams_adgroup`;

CREATE TABLE `prst_tbl_ams_adgroup` (
  `brand_id` int(11) DEFAULT NULL,
  `brand_name` varchar(191) DEFAULT NULL,
  `accouint_id` int(11) DEFAULT NULL,
  `account_name` varchar(191) DEFAULT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  `date_key` int(11) DEFAULT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(255) DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `adGroupName` varchar(191) NOT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `acos` decimal(19,4) DEFAULT NULL,
  `cpc` decimal(19,4) DEFAULT NULL,
  `ctr` decimal(19,4) DEFAULT NULL,
  `cpa` decimal(19,4) DEFAULT NULL,
  `roas` decimal(19,4) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_ams_asins` */

DROP TABLE IF EXISTS `prst_tbl_ams_asins`;

CREATE TABLE `prst_tbl_ams_asins` (
  `brand_id` int(11) DEFAULT NULL,
  `brand_name` varchar(191) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `account_name` varchar(191) DEFAULT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  `date_key` int(11) DEFAULT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(255) DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `adGroupName` varchar(191) NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `keywordText` varchar(191) NOT NULL,
  `asin` varchar(40) DEFAULT NULL,
  `other_asin` varchar(1000) DEFAULT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `currency` varchar(50) DEFAULT NULL,
  `match_type` varchar(50) NOT NULL,
  `attributedunitsordered` int(11) DEFAULT NULL,
  `sales_other_sku` decimal(19,2) DEFAULT NULL,
  `units_ordered_other_sku` int(11) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_ams_campaign` */

DROP TABLE IF EXISTS `prst_tbl_ams_campaign`;

CREATE TABLE `prst_tbl_ams_campaign` (
  `brand_id` int(11) DEFAULT NULL,
  `brand_name` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `accouint_id` int(11) DEFAULT NULL,
  `account_name` varchar(191) DEFAULT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  `date_key` int(11) DEFAULT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(255) DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT NULL,
  `campaign_budget` decimal(19,2) DEFAULT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `acos` decimal(19,4) DEFAULT NULL,
  `cpc` decimal(19,4) DEFAULT NULL,
  `ctr` decimal(19,4) DEFAULT NULL,
  `cpa` decimal(19,4) DEFAULT NULL,
  `roas` decimal(19,4) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_prst_ams` (`batchid`,`accouint_id`,`profile_id`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_ams_keyword` */

DROP TABLE IF EXISTS `prst_tbl_ams_keyword`;

CREATE TABLE `prst_tbl_ams_keyword` (
  `brand_id` int(11) DEFAULT NULL,
  `brand_name` varchar(191) DEFAULT NULL,
  `accouint_id` int(11) DEFAULT NULL,
  `account_name` varchar(191) DEFAULT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  `date_key` int(11) DEFAULT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(255) DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `adGroupName` varchar(191) NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `keywordText` varchar(191) NOT NULL,
  `matchType` varchar(50) NOT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `acos` decimal(19,4) DEFAULT NULL,
  `cpc` decimal(19,4) DEFAULT NULL,
  `ctr` decimal(19,4) DEFAULT NULL,
  `cpa` decimal(19,4) DEFAULT NULL,
  `roas` decimal(19,4) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_prst_ams` (`batchid`,`profile_id`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_ams_product` */

DROP TABLE IF EXISTS `prst_tbl_ams_product`;

CREATE TABLE `prst_tbl_ams_product` (
  `brand_id` int(11) DEFAULT NULL,
  `brand_name` varchar(191) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `account_name` varchar(191) DEFAULT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  `date_key` int(11) DEFAULT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(255) DEFAULT NULL,
  `campaign_type` varchar(100) DEFAULT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `adGroupName` varchar(191) NOT NULL,
  `ad_id` bigint(20) NOT NULL,
  `asin` varchar(40) NOT NULL,
  `sku` varchar(40) NOT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `order_units` int(11) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `acos` decimal(19,4) DEFAULT NULL,
  `cpc` decimal(19,4) DEFAULT NULL,
  `ctr` decimal(19,4) DEFAULT NULL,
  `cpa` decimal(19,4) DEFAULT NULL,
  `roas` decimal(19,4) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_prst_ams` (`asin`,`batchid`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_asins_detail` */

DROP TABLE IF EXISTS `prst_tbl_asins_detail`;

CREATE TABLE `prst_tbl_asins_detail` (
  `client_id` bigint(20) unsigned NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `fk_account_id` int(11) NOT NULL,
  `accountName` varchar(191) NOT NULL,
  `ASIN` varchar(20) NOT NULL,
  `product_title` varchar(255) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `subcategory_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_product_master` */

DROP TABLE IF EXISTS `prst_tbl_product_master`;

CREATE TABLE `prst_tbl_product_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) DEFAULT NULL,
  `ASIN` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `product_title` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `fullfillment_channel` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `acos` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `order_units` int(11) DEFAULT NULL,
  `shipped_units` int(11) DEFAULT NULL,
  `qtd_shipped_units` int(11) DEFAULT NULL,
  `ytd_shipped_units` int(11) DEFAULT NULL,
  `mtd_shipped_units` int(11) DEFAULT NULL,
  `wtd_shipped_units` int(11) DEFAULT NULL,
  `last_week_shipped_units` int(11) DEFAULT NULL,
  `price` decimal(19,2) DEFAULT NULL,
  `price_diff_30d` decimal(19,2) DEFAULT NULL,
  `salesrank` int(11) DEFAULT NULL,
  `prsc_diff_salesrank_pre_30d` decimal(19,2) DEFAULT NULL,
  `sellable_inv_units` int(11) DEFAULT NULL,
  `unsellable_inv_units` int(11) DEFAULT NULL,
  `po_units` int(11) DEFAULT NULL,
  `review_score` decimal(19,2) DEFAULT NULL,
  `review_score_30d` decimal(19,2) DEFAULT NULL,
  `review_count` int(11) DEFAULT NULL,
  `review_count_30d` int(11) DEFAULT NULL,
  `ytd_po_units` int(11) DEFAULT NULL,
  `mtd_po_units` int(11) DEFAULT NULL,
  `qtd_po_units` int(11) DEFAULT NULL,
  `wtd_po_units` int(11) DEFAULT NULL,
  `last_week_po_units` int(11) DEFAULT NULL,
  `batchid` bigint(20) DEFAULT NULL,
  `load_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32768 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Table structure for table `prst_tbl_purchase_order` */

DROP TABLE IF EXISTS `prst_tbl_purchase_order`;

CREATE TABLE `prst_tbl_purchase_order` (
  `account_id` int(11) DEFAULT NULL,
  `po` varchar(255) DEFAULT NULL,
  `asin` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `po_status` varchar(255) DEFAULT NULL,
  `title` varchar(1000) DEFAULT NULL,
  `case_size` varchar(255) DEFAULT NULL,
  `submitted_cases` int(11) DEFAULT NULL,
  `accepted_cases` int(11) DEFAULT NULL,
  `received_cases` int(11) DEFAULT NULL,
  `outstanding_cases` int(11) DEFAULT NULL,
  `str_case_cost` varchar(50) DEFAULT NULL,
  `str_total_cost` varchar(50) DEFAULT NULL,
  `case_cost` int(11) DEFAULT NULL,
  `total_cost` int(11) DEFAULT NULL,
  `accepted_case` int(11) DEFAULT NULL,
  `rejected_case` int(11) DEFAULT NULL,
  `total_po_cost` int(11) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_prst_po` (`asin`,`batchid`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_sales_asin_monthly` */

DROP TABLE IF EXISTS `prst_tbl_sales_asin_monthly`;

CREATE TABLE `prst_tbl_sales_asin_monthly` (
  `year_` varchar(15) DEFAULT NULL,
  `Month_` varchar(100) NOT NULL,
  `fk_account_id` int(11) DEFAULT NULL,
  `first_day_of_month` varchar(100) DEFAULT NULL,
  `last_day_of_month` varchar(100) DEFAULT NULL,
  `ASIN` varchar(20) NOT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `subcategory_id` varchar(100) DEFAULT NULL,
  `subcategory_name` varchar(100) DEFAULT NULL,
  `shipped_cogs` decimal(19,2) NOT NULL,
  `shipped_units` int(11) NOT NULL,
  `shipped_cogs_last_year` decimal(19,2) NOT NULL,
  `shipped_units_last_year` int(11) NOT NULL,
  `price` decimal(19,2) DEFAULT NULL,
  `salesrank` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_sales_asin_weekly` */

DROP TABLE IF EXISTS `prst_tbl_sales_asin_weekly`;

CREATE TABLE `prst_tbl_sales_asin_weekly` (
  `year_` varchar(15) DEFAULT NULL,
  `week_` varchar(100) NOT NULL,
  `fk_account_id` int(11) DEFAULT NULL,
  `first_day_of_week` varchar(15) DEFAULT NULL,
  `last_day_of_week` varchar(15) DEFAULT NULL,
  `ASIN` varchar(20) NOT NULL,
  `category_id` varchar(100) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `subcategory_id` varchar(100) DEFAULT NULL,
  `subcategory_name` varchar(100) DEFAULT NULL,
  `shipped_cogs` decimal(19,2) NOT NULL,
  `shipped_units` int(11) NOT NULL,
  `shipped_cogs_last_year` decimal(19,2) NOT NULL,
  `shipped_units_last_year` int(11) NOT NULL,
  `price` decimal(19,2) DEFAULT NULL,
  `salesrank` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_scraping` */

DROP TABLE IF EXISTS `prst_tbl_scraping`;

CREATE TABLE `prst_tbl_scraping` (
  `asin` varchar(50) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `total_reviews` varchar(500) DEFAULT NULL,
  `reviews_count` int(11) DEFAULT NULL,
  `average_review` decimal(19,2) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `load_date` date DEFAULT NULL,
  KEY `idx_prst_scrp` (`asin`,`capture_date`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_tbl_temp_product_master` */

DROP TABLE IF EXISTS `prst_tbl_temp_product_master`;

CREATE TABLE `prst_tbl_temp_product_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `product_title` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `fullfillment_channel` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `order_conversion` int(11) DEFAULT NULL,
  `order_units` int(11) DEFAULT NULL,
  `shipped_units` int(11) DEFAULT NULL,
  `price` decimal(19,2) DEFAULT NULL,
  `salesrank` int(11) DEFAULT NULL,
  `sellable_inv_units` int(11) DEFAULT NULL,
  `unsellable_inv_units` int(11) DEFAULT NULL,
  `po_units` int(11) DEFAULT NULL,
  `reviews_count` int(11) DEFAULT NULL,
  `reviews_score` decimal(19,2) DEFAULT NULL,
  `batchid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1578907 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Table structure for table `prst_vew_comp_cards` */

DROP TABLE IF EXISTS `prst_vew_comp_cards`;

CREATE TABLE `prst_vew_comp_cards` (
  `cc_id` int(11) NOT NULL AUTO_INCREMENT,
  `asin` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `daily_pre_paid` int(11) DEFAULT NULL,
  `daily_post_paid` int(11) DEFAULT NULL,
  `record_date` date DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`cc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_vew_daily_comp_cards` */

DROP TABLE IF EXISTS `prst_vew_daily_comp_cards`;

CREATE TABLE `prst_vew_daily_comp_cards` (
  `account_id` int(11) DEFAULT NULL,
  `asin` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `daily_pre_paid` int(11) DEFAULT NULL,
  `daily_post_paid` int(11) DEFAULT NULL,
  `record_date` date DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_vew_inventory_table` */

DROP TABLE IF EXISTS `prst_vew_inventory_table`;

CREATE TABLE `prst_vew_inventory_table` (
  `DATE` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fk_account_id` int(11) DEFAULT NULL,
  `ASIN` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tag` varchar(100) DEFAULT NULL,
  `category_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `category_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `subcategory_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `subcategory_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `product_title` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `fullfillment_channel` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sellable_inv_units` int(11) NOT NULL,
  `unsellable_inv_units` int(11) NOT NULL,
  `price` decimal(19,2) DEFAULT NULL,
  `salesrank` bigint(20) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_prst_inv` (`ASIN`,`batchid`,`fk_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Table structure for table `prst_vew_monthly_comp_cards` */

DROP TABLE IF EXISTS `prst_vew_monthly_comp_cards`;

CREATE TABLE `prst_vew_monthly_comp_cards` (
  `account_id` int(11) DEFAULT NULL,
  `asin` varchar(20) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `monthly_pre_paid` int(11) DEFAULT NULL,
  `monthly_post_paid` int(11) DEFAULT NULL,
  `record_date` date DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_vew_peformance_ytd` */

DROP TABLE IF EXISTS `prst_vew_peformance_ytd`;

CREATE TABLE `prst_vew_peformance_ytd` (
  `profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `account_name` varchar(225) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `acos` decimal(19,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_vew_performance_pre30dayTable` */

DROP TABLE IF EXISTS `prst_vew_performance_pre30dayTable`;

CREATE TABLE `prst_vew_performance_pre30dayTable` (
  `profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `account_name` varchar(191) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `acos_` decimal(19,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_vew_performance_pre30dayTable_grand_total` */

DROP TABLE IF EXISTS `prst_vew_performance_pre30dayTable_grand_total`;

CREATE TABLE `prst_vew_performance_pre30dayTable_grand_total` (
  `grand_total` varchar(191) DEFAULT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `acos_` decimal(19,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_vew_perfromance_wow` */

DROP TABLE IF EXISTS `prst_vew_perfromance_wow`;

CREATE TABLE `prst_vew_perfromance_wow` (
  `impressions` decimal(19,2) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_vew_product_table` */

DROP TABLE IF EXISTS `prst_vew_product_table`;

CREATE TABLE `prst_vew_product_table` (
  `DATE` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fk_account_id` int(11) DEFAULT NULL,
  `ASIN` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tag` varchar(100) DEFAULT NULL,
  `category_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `category_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `subcategory_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `subcategory_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `product_title` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `fullfillment_channel` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `shipped_cogs` decimal(19,2) NOT NULL,
  `shipped_units` int(11) NOT NULL,
  `shipped_cogs_last_year` decimal(19,2) NOT NULL,
  `shipped_units_last_year` int(11) NOT NULL,
  `price` decimal(19,2) DEFAULT NULL,
  `salesrank` bigint(20) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `loaddate` date DEFAULT NULL,
  KEY `idx_prst_vcsc` (`ASIN`,`category_id`,`subcategory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Table structure for table `prst_vew_top10_campaign` */

DROP TABLE IF EXISTS `prst_vew_top10_campaign`;

CREATE TABLE `prst_vew_top10_campaign` (
  `top_camp_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) DEFAULT NULL,
  `spend` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `acos` decimal(19,2) DEFAULT NULL,
  `record_date` date DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`top_camp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `prst_vew_weekly_comp_cards` */

DROP TABLE IF EXISTS `prst_vew_weekly_comp_cards`;

CREATE TABLE `prst_vew_weekly_comp_cards` (
  `account_id` int(11) DEFAULT NULL,
  `asin` varchar(20) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `weekly_pre_paid` int(11) DEFAULT NULL,
  `weekly_post_paid` int(11) DEFAULT NULL,
  `record_date` date DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `stage_account_client` */

DROP TABLE IF EXISTS `stage_account_client`;

CREATE TABLE `stage_account_client` (
  `rtl_acc_cl_id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `Agency_Name` varchar(200) NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `client_name` varchar(200) NOT NULL,
  `client_email` varchar(191) NOT NULL,
  `client_account_password` varchar(191) NOT NULL,
  `client_creation` timestamp NOT NULL,
  `client_updation` timestamp NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `marketplaceid` bigint(20) NOT NULL,
  `account_type` int(11) NOT NULL,
  `account_type_name` varchar(191) NOT NULL,
  `fkId` bigint(20) NOT NULL,
  `accountName` varchar(191) NOT NULL,
  `account_creation` timestamp NULL DEFAULT NULL,
  `account_updation` timestamp NULL DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`rtl_acc_cl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1024 DEFAULT CHARSET=utf8;

/*Table structure for table `stage_adgroup` */

DROP TABLE IF EXISTS `stage_adgroup`;

CREATE TABLE `stage_adgroup` (
  `fk_batch_id` bigint(20) DEFAULT NULL,
  `fk_account_id` int(11) DEFAULT NULL,
  `fk_profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(191) DEFAULT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `adgroup_id` bigint(20) DEFAULT NULL,
  `adgroup_name` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `campaign_type` varchar(4) DEFAULT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `conversions` int(11) DEFAULT NULL,
  `conversions_same_sku` int(11) DEFAULT NULL,
  `unit_ordered` int(11) DEFAULT NULL,
  `sales` decimal(19,2) DEFAULT NULL,
  `sales_same_sku` decimal(19,2) DEFAULT NULL,
  `report_date` date DEFAULT NULL,
  `creation_date` date DEFAULT NULL,
  KEY `idx_stg_ams` (`fk_account_id`,`report_date`,`adgroup_id`,`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `stage_ams_asin` */

DROP TABLE IF EXISTS `stage_ams_asin`;

CREATE TABLE `stage_ams_asin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkAccountId` int(11) DEFAULT NULL,
  `fkProfileId` bigint(20) DEFAULT NULL,
  `profile_name` varchar(191) DEFAULT NULL,
  `campaignId` bigint(20) DEFAULT NULL,
  `campaignName` varchar(191) DEFAULT NULL,
  `adGroupId` bigint(20) DEFAULT NULL,
  `adGroupName` varchar(191) DEFAULT NULL,
  `keywordId` bigint(20) DEFAULT NULL,
  `keywordText` varchar(191) DEFAULT NULL,
  `asin` varchar(40) DEFAULT NULL,
  `other_asin` varchar(40) DEFAULT NULL,
  `sku` varchar(40) DEFAULT NULL,
  `currency` varchar(50) DEFAULT NULL,
  `matchType` varchar(50) DEFAULT NULL,
  `campaign_type` varchar(5) DEFAULT NULL,
  `attributedUnitsOrdered` int(11) DEFAULT NULL,
  `sales_other_sku` decimal(19,2) DEFAULT NULL,
  `units_ordered_other_sku` int(11) DEFAULT NULL,
  `reportDate` date DEFAULT NULL,
  `creationDate` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_stg_ams` (`fkAccountId`,`reportDate`,`campaignId`,`adGroupId`,`keywordId`,`asin`)
) ENGINE=InnoDB AUTO_INCREMENT=11440 DEFAULT CHARSET=utf8;

/*Table structure for table `stage_ams_profile` */

DROP TABLE IF EXISTS `stage_ams_profile`;

CREATE TABLE `stage_ams_profile` (
  `stage_ams_profile` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) NOT NULL,
  `profile_name` varchar(100) DEFAULT NULL,
  `isActive` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`stage_ams_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=2048 DEFAULT CHARSET=utf8;

/*Table structure for table `stage_asin_tags` */

DROP TABLE IF EXISTS `stage_asin_tags`;

CREATE TABLE `stage_asin_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) DEFAULT NULL,
  `ASIN` varchar(100) DEFAULT NULL,
  `fkTagId` int(11) DEFAULT NULL,
  `tag` varchar(100) DEFAULT NULL,
  `fullFillmentChannel` text,
  `uniqueColumn` varchar(100) DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `stage_campaign` */

DROP TABLE IF EXISTS `stage_campaign`;

CREATE TABLE `stage_campaign` (
  `stg_cmp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_batch_id` bigint(20) unsigned NOT NULL,
  `fk_account_id` bigint(20) unsigned NOT NULL,
  `fk_profile_id` bigint(20) unsigned NOT NULL,
  `profile_name` varchar(191) DEFAULT NULL,
  `campaign_id` bigint(20) unsigned DEFAULT NULL,
  `campaign_name` varchar(255) DEFAULT NULL,
  `campaign_status` varchar(50) DEFAULT NULL,
  `campaign_budget` decimal(19,2) DEFAULT NULL,
  `campaign_budget_type` varchar(50) DEFAULT NULL,
  `campaign_type` varchar(20) DEFAULT NULL,
  `impressions` decimal(19,2) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `attributedConversions` decimal(19,2) DEFAULT NULL,
  `attributedConversionsSameSKU` decimal(19,2) DEFAULT NULL,
  `attributedUnitsOrdered` decimal(19,2) DEFAULT NULL,
  `attributedSales` decimal(19,2) DEFAULT NULL,
  `attributedSalesSameSKU` decimal(19,2) DEFAULT NULL,
  `report_date` date DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`stg_cmp_id`),
  KEY `idx_stg_ams` (`fk_account_id`,`report_date`,`campaign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16384 DEFAULT CHARSET=utf8;

/*Table structure for table `stage_inventory_master` */

DROP TABLE IF EXISTS `stage_inventory_master`;

CREATE TABLE `stage_inventory_master` (
  `rtl_inven_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) DEFAULT NULL,
  `asins` varchar(20) NOT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `fulfillment_channel` text,
  `seller_inv_units` int(11) DEFAULT NULL,
  `unseller_inv_units` int(11) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`rtl_inven_id`),
  KEY `idx_stg_inv` (`fk_account_id`,`batchid`,`asins`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `stage_keyword` */

DROP TABLE IF EXISTS `stage_keyword`;

CREATE TABLE `stage_keyword` (
  `stg_keyword_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) DEFAULT NULL,
  `fkAccountId` int(11) NOT NULL,
  `fkProfileId` bigint(20) NOT NULL,
  `profile_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_type` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `cost` decimal(19,2) NOT NULL,
  `attributedConversions` int(11) NOT NULL,
  `attributedConversionsSameSKU` int(11) NOT NULL,
  `attributedUnitsOrdered` int(11) NOT NULL,
  `attributedSales` decimal(19,2) NOT NULL,
  `attributedSalesSameSKU` decimal(19,2) NOT NULL,
  `reportDate` int(11) NOT NULL,
  `creationDate` datetime NOT NULL,
  PRIMARY KEY (`stg_keyword_id`),
  KEY `idx_stg_ams` (`fkAccountId`,`reportDate`,`campaignId`,`adGroupId`,`keywordId`)
) ENGINE=InnoDB AUTO_INCREMENT=131071 DEFAULT CHARSET=utf8;

/*Table structure for table `stage_manager` */

DROP TABLE IF EXISTS `stage_manager`;

CREATE TABLE `stage_manager` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Manager_id` bigint(20) unsigned NOT NULL,
  `Brand_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Manager_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `stage_product_ads` */

DROP TABLE IF EXISTS `stage_product_ads`;

CREATE TABLE `stage_product_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_batch_id` bigint(20) DEFAULT NULL,
  `fk_account_id` int(11) DEFAULT NULL,
  `fk_profile_id` bigint(20) DEFAULT NULL,
  `profile_name` varchar(191) DEFAULT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `campaign_name` varchar(191) DEFAULT NULL,
  `adgroup_id` bigint(20) DEFAULT NULL,
  `adgroup_name` varchar(191) DEFAULT NULL,
  `campaign_type` varchar(4) DEFAULT NULL,
  `ad_id` bigint(20) DEFAULT NULL,
  `asin` varchar(40) DEFAULT NULL,
  `sku` varchar(40) DEFAULT NULL,
  `impressions` int(11) DEFAULT NULL,
  `clicks` int(11) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `conversions` int(11) DEFAULT NULL,
  `conversions_same_sku` int(11) DEFAULT NULL,
  `unit_ordered` int(11) DEFAULT NULL,
  `sales` decimal(19,2) DEFAULT NULL,
  `sales_same_sku` decimal(19,2) DEFAULT NULL,
  `unit_ordered_same_sku` int(11) DEFAULT NULL,
  `report_date` date DEFAULT NULL,
  `creation_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_stg_ams` (`fk_account_id`,`report_date`,`campaign_id`,`asin`)
) ENGINE=InnoDB AUTO_INCREMENT=65536 DEFAULT CHARSET=utf8;

/*Table structure for table `stage_product_catalog` */

DROP TABLE IF EXISTS `stage_product_catalog`;

CREATE TABLE `stage_product_catalog` (
  `tbl_pc_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) NOT NULL,
  `last_refresh` varchar(20) NOT NULL,
  `ASIN` varchar(20) NOT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `fulfillment_channel` text,
  `sc_status` tinyint(4) DEFAULT NULL,
  `vc_status` tinyint(4) DEFAULT NULL,
  `upc` varchar(20) DEFAULT NULL,
  `release_date` varchar(20) DEFAULT NULL,
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `price` decimal(19,4) DEFAULT NULL,
  `product_width` varchar(50) DEFAULT NULL,
  `product_length` varchar(50) DEFAULT NULL,
  `product_height` varchar(50) DEFAULT NULL,
  `product_ship_weight` varchar(50) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(150) DEFAULT NULL,
  `binding` varchar(150) DEFAULT NULL,
  `product_group` varchar(100) DEFAULT NULL,
  `product_type` varchar(50) DEFAULT NULL,
  `product_title` varchar(255) DEFAULT NULL,
  `parent_asins` varchar(20) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `subcategory_name` varchar(100) DEFAULT NULL,
  `salesrank` bigint(20) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`tbl_pc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `stage_purchaseorder_master` */

DROP TABLE IF EXISTS `stage_purchaseorder_master`;

CREATE TABLE `stage_purchaseorder_master` (
  `stg_po_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) DEFAULT NULL,
  `po` varchar(255) DEFAULT NULL,
  `hand_off_type` varchar(255) DEFAULT NULL,
  `ship_location` varchar(255) DEFAULT NULL,
  `model_number` varchar(255) DEFAULT NULL,
  `asins` varchar(255) NOT NULL,
  `sku` varchar(1000) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `po_status` varchar(20) DEFAULT NULL,
  `delivery_window_start` varchar(255) DEFAULT NULL,
  `delivery_window_end` varchar(255) DEFAULT NULL,
  `backorder` varchar(30) DEFAULT NULL,
  `expected_ship_date` varchar(255) DEFAULT NULL,
  `confirmed_ship_date` varchar(255) DEFAULT NULL,
  `case_size` varchar(255) DEFAULT NULL,
  `submitted_cases` int(11) DEFAULT NULL,
  `accepted_cases` int(11) DEFAULT NULL,
  `received_cases` int(11) DEFAULT NULL,
  `outstanding_cases` int(11) DEFAULT NULL,
  `str_case_cost` varchar(50) DEFAULT NULL,
  `str_total_cost` varchar(50) DEFAULT NULL,
  `order_date` varchar(255) DEFAULT NULL,
  `case_cost` int(11) DEFAULT NULL,
  `total_cost` int(11) DEFAULT NULL,
  `accepted_case` int(11) DEFAULT NULL,
  `rejected_case` int(11) DEFAULT NULL,
  `total_po_cost` int(11) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`stg_po_id`),
  KEY `idx_stg_po` (`fk_account_id`,`batchid`,`po`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `stage_sales_master` */

DROP TABLE IF EXISTS `stage_sales_master`;

CREATE TABLE `stage_sales_master` (
  `rtl_sal_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_account_id` int(11) DEFAULT NULL,
  `ASIN` varchar(20) NOT NULL,
  `fulfillment_channel` text,
  `sku` varchar(1000) DEFAULT NULL,
  `shipped_cogs` decimal(19,2) DEFAULT NULL,
  `shipped_unit` int(11) DEFAULT NULL,
  `shipped_cogs_last_year` decimal(19,2) DEFAULT NULL,
  `shipped_units_last_year` int(11) DEFAULT NULL,
  `capture_date` timestamp NULL DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL,
  `LoadDate` datetime DEFAULT NULL,
  PRIMARY KEY (`rtl_sal_id`),
  KEY `idx_stg_sale` (`fk_account_id`,`batchid`,`ASIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `stage_scraping` */

DROP TABLE IF EXISTS `stage_scraping`;

CREATE TABLE `stage_scraping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT NULL,
  `asin` varchar(50) DEFAULT NULL,
  `total_reviews` varchar(500) DEFAULT NULL,
  `reviews_count` int(10) unsigned DEFAULT NULL,
  `average_review` decimal(19,2) DEFAULT NULL,
  `capture_date` date DEFAULT NULL,
  `LoadDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_stg_scrp` (`account_id`,`capture_date`,`asin`)
) ENGINE=InnoDB AUTO_INCREMENT=1024 DEFAULT CHARSET=utf8;

/*Table structure for table `tb_ams_api` */

DROP TABLE IF EXISTS `tb_ams_api`;

CREATE TABLE `tb_ams_api` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `grant_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `refresh_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_secret` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_Ams_Parameter_Types` */

DROP TABLE IF EXISTS `tbl_Ams_Parameter_Types`;

CREATE TABLE `tbl_Ams_Parameter_Types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parameterName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isSd` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `isSp` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `isSb` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `isActive` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_account` */

DROP TABLE IF EXISTS `tbl_account`;

CREATE TABLE `tbl_account` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBrandId` bigint(20) DEFAULT NULL,
  `marketPlaceID` bigint(20) NOT NULL,
  `fkAccountType` int(11) NOT NULL,
  `fkId` bigint(20) NOT NULL,
  `accountName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_account_login` */

DROP TABLE IF EXISTS `tbl_account_login`;

CREATE TABLE `tbl_account_login` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `loginId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkAccountType` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_account_type` */

DROP TABLE IF EXISTS `tbl_account_type`;

CREATE TABLE `tbl_account_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_accounts_asins` */

DROP TABLE IF EXISTS `tbl_accounts_asins`;

CREATE TABLE `tbl_accounts_asins` (
  `fkAccountId` bigint(20) DEFAULT NULL,
  `fkAsinId` bigint(20) NOT NULL,
  `uniqueColumn` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdaAt` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `tbl_accounts_asins_uniquecolumn_unique` (`uniqueColumn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_active_asins` */

DROP TABLE IF EXISTS `tbl_active_asins`;

CREATE TABLE `tbl_active_asins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountId` int(11) DEFAULT NULL,
  `asin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_agency` */

DROP TABLE IF EXISTS `tbl_agency`;

CREATE TABLE `tbl_agency` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_agency_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_download_links_sb` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_download_links_sb`;

CREATE TABLE `tbl_ams_adgroup_reports_download_links_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_download_links_sd` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_download_links_sd`;

CREATE TABLE `tbl_ams_adgroup_reports_download_links_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_download_links_sp` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_download_links_sp`;

CREATE TABLE `tbl_ams_adgroup_reports_download_links_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sb` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sb`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sb_archived` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sb_archived`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sb_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudget` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignBudgetType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedDetailPageViewsClicks14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrdersNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedOrderRateNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSalesNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrand14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrderedNewToBrandPercentage14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitsSold14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dpv14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sd` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sd`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sd` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sd_archived` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sd_archived`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sd_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sp` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sp`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_adgroup_reports_downloaded_data_sp_archived` */

DROP TABLE IF EXISTS `tbl_ams_adgroup_reports_downloaded_data_sp_archived`;

CREATE TABLE `tbl_ams_adgroup_reports_downloaded_data_sp_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions1dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `impressions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions30dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedConversions14dSameSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clicks` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_advertising_schedule_files` */

DROP TABLE IF EXISTS `tbl_ams_advertising_schedule_files`;

CREATE TABLE `tbl_ams_advertising_schedule_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkScheduleId` bigint(20) DEFAULT NULL,
  `fkParameterTypeId` bigint(20) DEFAULT NULL,
  `parameterTypeName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filePath` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completeFilePath` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `devServerLink` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apiServerLink` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isDataFound` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `isFileDeleted` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_asin_reports_download_links` */

DROP TABLE IF EXISTS `tbl_ams_asin_reports_download_links`;

CREATE TABLE `tbl_ams_asin_reports_download_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `profileID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `reportId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statusDetails` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `isDone` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_asin_reports_downloaded_sp` */

DROP TABLE IF EXISTS `tbl_ams_asin_reports_downloaded_sp`;

CREATE TABLE `tbl_ams_asin_reports_downloaded_sp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `otherAsin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_asin_reports_downloaded_sp_archived` */

DROP TABLE IF EXISTS `tbl_ams_asin_reports_downloaded_sp_archived`;

CREATE TABLE `tbl_ams_asin_reports_downloaded_sp_archived` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fkBatchId` bigint(20) NOT NULL,
  `fkAccountId` bigint(20) NOT NULL,
  `fkReportsDownloadLinksId` int(11) NOT NULL,
  `fkProfileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `otherAsin` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered1dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered7dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered14dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedUnitsOrdered30dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales1dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales7dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales14dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attributedSales30dOtherSKU` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportDate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` date NOT NULL,
  `attributedUnitsOrdered1d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered7d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered14d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `attributedUnitsOrdered30d` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_ams_authtoken` */

DROP TABLE IF EXISTS `tbl_ams_authtoken`;

CREATE TABLE `tbl_ams_authtoken` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `client_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `refresh_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_in` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` datetime NOT NULL,
  `updationDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_cron` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_cron`;

CREATE TABLE `tbl_ams_bidding_rule_cron` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `sponsoredType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriodDays` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `runStatus` tinyint(1) NOT NULL DEFAULT '0',
  `currentRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nextRunTime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `checkRule` tinyint(1) NOT NULL DEFAULT '0',
  `ruleResult` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `emailSent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_invalid_profile` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_invalid_profile`;

CREATE TABLE `tbl_ams_bidding_rule_invalid_profile` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkId` bigint(20) NOT NULL,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_keywordId_list` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_keywordId_list`;

CREATE TABLE `tbl_ams_bidding_rule_keywordId_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkId` bigint(20) NOT NULL,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `profileId` bigint(20) NOT NULL,
  `reportType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` bigint(20) NOT NULL,
  `adGroupId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `keywordText` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `matchType` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` decimal(8,2) NOT NULL,
  `servingStatus` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastUpdatedDate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rule_preset` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rule_preset`;

CREATE TABLE `tbl_ams_bidding_rule_preset` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `presetName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `integerValues` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `thenClause` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidBy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `andOr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriod` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriodDays` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rules` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rules`;

CREATE TABLE `tbl_ams_bidding_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkUserId` bigint(20) NOT NULL,
  `fKPreSetRule` bigint(20) NOT NULL,
  `ruleName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsoredType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriod` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lookBackPeriodDays` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pfCampaigns` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `profileId` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `integerValues` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `thenClause` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidBy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `andOr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ccEmails` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `fkBrandId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_rules_portfolio_campaign_data_cron` */

DROP TABLE IF EXISTS `tbl_ams_bidding_rules_portfolio_campaign_data_cron`;

CREATE TABLE `tbl_ams_bidding_rules_portfolio_campaign_data_cron` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkBiddingRuleId` bigint(20) NOT NULL,
  `sponsoredType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `profileId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `portfolioId` bigint(20) NOT NULL,
  `reportType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `isDone` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_bidding_tracker` */

DROP TABLE IF EXISTS `tbl_ams_bidding_tracker`;

CREATE TABLE `tbl_ams_bidding_tracker` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profileId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adGroupId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportType` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldBid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywordId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creationDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_ams_campaign_list` */

DROP TABLE IF EXISTS `tbl_ams_campaign_list`;

CREATE TABLE `tbl_ams_campaign_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkProfileId` bigint(20) NOT NULL,
  `fkConfigId` bigint(20) NOT NULL DEFAULT '1',
  `profileId` bigint(20) NOT NULL,
  `portfolioId` bigint(20) NOT NULL,
  `campaignId` bigint(20) NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaignType` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetingType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `premiumBidAdjustment` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dailyBudget` decimal(8,2) NOT NULL,
  `budget` decimal(8,2) NOT NULL,
  `endDate` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidOptimization` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `budgetType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `servingStatus` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pageType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandLogoAssetID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `headline` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shouldOptimizeAsins` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brandLogoUrl` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asins` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `strategy` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `predicate` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_calculate_asins_level_shippedunits` */

DROP TABLE IF EXISTS `tbl_calculate_asins_level_shippedunits`;

CREATE TABLE `tbl_calculate_asins_level_shippedunits` (
  `shipped_units` decimal(19,2) DEFAULT NULL,
  `ASIN` varchar(255) DEFAULT NULL,
  `product_title` varchar(255) DEFAULT NULL,
  `fullfillment_channel` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_campaign_tags_assigned` */

DROP TABLE IF EXISTS `tbl_campaign_tags_assigned`;

CREATE TABLE `tbl_campaign_tags_assigned` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campaignId` bigint(20) unsigned NOT NULL,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `fkTagId` bigint(20) unsigned NOT NULL,
  `tag` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `uniqueColumn` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_campaign_tags_assigned_uniquecolumn_unique` (`uniqueColumn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_inventory_all_details` */

DROP TABLE IF EXISTS `tbl_inventory_all_details`;

CREATE TABLE `tbl_inventory_all_details` (
  `client_id` bigint(20) DEFAULT NULL,
  `client_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `fk_account_id` int(11) DEFAULT NULL,
  `accountName` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ASIN` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `product_title` varchar(255) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `subcategory_id` bigint(20) DEFAULT NULL,
  `subcategory_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_inventory_brands_override` */

DROP TABLE IF EXISTS `tbl_inventory_brands_override`;

CREATE TABLE `tbl_inventory_brands_override` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkAccountId` bigint(20) unsigned NOT NULL,
  `overrideLabel` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_inventory_brands_override_fkaccountid_unique` (`fkAccountId`)
) ENGINE=InnoDB AUTO_INCREMENT=1031 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_inventory_category_override` */

DROP TABLE IF EXISTS `tbl_inventory_category_override`;

CREATE TABLE `tbl_inventory_category_override` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkCategoryId` bigint(20) unsigned NOT NULL,
  `overrideLabel` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_inventory_category_override_fkcategoryid_unique` (`fkCategoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_inventory_products_override` */

DROP TABLE IF EXISTS `tbl_inventory_products_override`;

CREATE TABLE `tbl_inventory_products_override` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `asin` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `overrideLabel` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_inventory_products_override_asin_unique` (`asin`)
) ENGINE=InnoDB AUTO_INCREMENT=1246 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_inventory_sub_category_override` */

DROP TABLE IF EXISTS `tbl_inventory_sub_category_override`;

CREATE TABLE `tbl_inventory_sub_category_override` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fkSubCategoryId` bigint(20) unsigned NOT NULL,
  `overrideLabel` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_inventory_sub_category_override_fksubcategoryid_unique` (`fkSubCategoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `tbl_map_account_override` */

DROP TABLE IF EXISTS `tbl_map_account_override`;

CREATE TABLE `tbl_map_account_override` (
  `fk_account_id` int(11) NOT NULL,
  `accountName` varchar(191) NOT NULL,
  `override_accountName` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_map_subcategory_override` */

DROP TABLE IF EXISTS `tbl_map_subcategory_override`;

CREATE TABLE `tbl_map_subcategory_override` (
  `subcategory_id` bigint(20) NOT NULL,
  `subcategory_name` varchar(191) NOT NULL,
  `override_subcatgoryName` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_prst_vew_peformance_ytd_grand_total` */

DROP TABLE IF EXISTS `tbl_prst_vew_peformance_ytd_grand_total`;

CREATE TABLE `tbl_prst_vew_peformance_ytd_grand_total` (
  `Grand_total` varchar(15) DEFAULT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  `cost` decimal(19,2) DEFAULT NULL,
  `acos_` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_acc_adgroup` */

DROP TABLE IF EXISTS `vald_ams_acc_adgroup`;

CREATE TABLE `vald_ams_acc_adgroup` (
  `account_id` int(11) DEFAULT NULL,
  `fact_impressions` int(11) DEFAULT NULL,
  `stage_impressions` int(11) DEFAULT NULL,
  `diff_impressions` int(11) DEFAULT NULL,
  `fact_clicks` int(11) DEFAULT NULL,
  `stage_clicks` int(11) DEFAULT NULL,
  `diff_clicks` int(11) DEFAULT NULL,
  `fact_cost` decimal(19,2) DEFAULT NULL,
  `stage_cost` decimal(19,2) DEFAULT NULL,
  `diff_cost` decimal(19,2) DEFAULT NULL,
  `fact_order_conversion` int(11) DEFAULT NULL,
  `stage_order_conversion` int(11) DEFAULT NULL,
  `diff_order_conversion` int(11) DEFAULT NULL,
  `fact_revenue` decimal(19,2) DEFAULT NULL,
  `stage_revenue` decimal(19,2) DEFAULT NULL,
  `diff_revenue` decimal(19,2) DEFAULT NULL,
  `batchid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_acc_asin` */

DROP TABLE IF EXISTS `vald_ams_acc_asin`;

CREATE TABLE `vald_ams_acc_asin` (
  `account_id` int(11) DEFAULT NULL,
  `fact_unit_ordered` int(11) DEFAULT NULL,
  `stage_unit_ordered` int(11) DEFAULT NULL,
  `diff_unit_ordered` int(11) DEFAULT NULL,
  `fact_sales_other_sku` decimal(19,2) DEFAULT NULL,
  `stage_sales_other_sku` decimal(19,2) DEFAULT NULL,
  `diff_sales_other_sku` decimal(19,2) DEFAULT NULL,
  `fact_unit_ordered_other_sku` int(11) DEFAULT NULL,
  `stage_unit_ordered_other_sku` int(11) DEFAULT NULL,
  `diff_unit_ordered_other_sku` int(11) DEFAULT NULL,
  `batchid` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_acc_campaign` */

DROP TABLE IF EXISTS `vald_ams_acc_campaign`;

CREATE TABLE `vald_ams_acc_campaign` (
  `account_id` int(11) NOT NULL,
  `fact_impressions` int(11) DEFAULT NULL,
  `stage_impressions` int(11) DEFAULT NULL,
  `diff_impressions` int(11) DEFAULT NULL,
  `fact_clicks` int(11) DEFAULT NULL,
  `stage_clicks` int(11) DEFAULT NULL,
  `diff_clicks` int(11) DEFAULT NULL,
  `fact_cost` decimal(19,2) DEFAULT NULL,
  `stage_cost` decimal(19,2) DEFAULT NULL,
  `diff_cost` decimal(19,2) DEFAULT NULL,
  `fact_camp_budget` decimal(19,2) DEFAULT NULL,
  `stage_camp_budget` decimal(19,2) DEFAULT NULL,
  `diff_camp_budget` decimal(19,2) DEFAULT NULL,
  `fact_order_conversion` int(11) DEFAULT NULL,
  `stage_order_conversion` int(11) DEFAULT NULL,
  `diff_order_conversion` int(11) DEFAULT NULL,
  `fact_revenue` decimal(19,2) DEFAULT NULL,
  `stage_revenue` decimal(19,2) DEFAULT NULL,
  `diff_revenue` decimal(19,2) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_acc_keyword` */

DROP TABLE IF EXISTS `vald_ams_acc_keyword`;

CREATE TABLE `vald_ams_acc_keyword` (
  `account_id` int(11) DEFAULT NULL,
  `fact_impressions` int(11) DEFAULT NULL,
  `stage_impressions` int(11) DEFAULT NULL,
  `diff_impressions` int(11) DEFAULT NULL,
  `fact_clicks` int(11) DEFAULT NULL,
  `stage_clicks` int(11) DEFAULT NULL,
  `diff_clicks` int(11) DEFAULT NULL,
  `fact_cost` decimal(19,2) DEFAULT NULL,
  `stage_cost` decimal(19,2) DEFAULT NULL,
  `diff_cost` decimal(19,2) DEFAULT NULL,
  `fact_order_conversion` int(11) DEFAULT NULL,
  `stage_order_conversion` int(11) DEFAULT NULL,
  `diff_order_conversion` int(11) DEFAULT NULL,
  `fact_revenue` decimal(19,2) DEFAULT NULL,
  `stage_revenue` decimal(19,2) DEFAULT NULL,
  `diff_revenue` decimal(19,2) DEFAULT NULL,
  `batchid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_acc_product` */

DROP TABLE IF EXISTS `vald_ams_acc_product`;

CREATE TABLE `vald_ams_acc_product` (
  `account_id` int(11) DEFAULT NULL,
  `fact_impressions` int(11) DEFAULT NULL,
  `stage_impressions` int(11) DEFAULT NULL,
  `diff_impressions` int(11) DEFAULT NULL,
  `fact_clicks` int(11) DEFAULT NULL,
  `stage_clicks` int(11) DEFAULT NULL,
  `diff_clicks` int(11) DEFAULT NULL,
  `fact_cost` decimal(19,2) DEFAULT NULL,
  `stage_cost` decimal(19,2) DEFAULT NULL,
  `diff_cost` decimal(19,2) DEFAULT NULL,
  `fact_order_conversion` int(11) DEFAULT NULL,
  `stage_order_conversion` int(11) DEFAULT NULL,
  `diff_order_conversion` int(11) DEFAULT NULL,
  `fact_revenue` decimal(19,2) DEFAULT NULL,
  `stage_revenue` decimal(19,2) DEFAULT NULL,
  `diff_revenue` decimal(19,2) DEFAULT NULL,
  `batchid` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_campaign` */

DROP TABLE IF EXISTS `vald_ams_campaign`;

CREATE TABLE `vald_ams_campaign` (
  `fact_impressions` int(11) DEFAULT NULL,
  `stage_impressions` int(11) DEFAULT NULL,
  `diff_impressions` int(11) DEFAULT NULL,
  `fact_clicks` int(11) DEFAULT NULL,
  `stage_clicks` int(11) DEFAULT NULL,
  `diff_clicks` int(11) DEFAULT NULL,
  `fact_cost` decimal(19,2) DEFAULT NULL,
  `stage_cost` decimal(19,2) DEFAULT NULL,
  `diff_cost` decimal(19,2) DEFAULT NULL,
  `fact_camp_budget` decimal(19,2) DEFAULT NULL,
  `stage_camp_budget` decimal(19,2) DEFAULT NULL,
  `diff_camp_budget` decimal(19,2) DEFAULT NULL,
  `fact_order_conversion` int(11) DEFAULT NULL,
  `stage_order_conversion` int(11) DEFAULT NULL,
  `diff_order_conversion` int(11) DEFAULT NULL,
  `fact_revenue` decimal(19,2) DEFAULT NULL,
  `stage_revenue` decimal(19,2) DEFAULT NULL,
  `diff_revenue` decimal(19,2) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_date_adgroup` */

DROP TABLE IF EXISTS `vald_ams_date_adgroup`;

CREATE TABLE `vald_ams_date_adgroup` (
  `fact_impressions` int(11) DEFAULT NULL,
  `stage_impressions` int(11) DEFAULT NULL,
  `diff_impressions` int(11) DEFAULT NULL,
  `fact_clicks` int(11) DEFAULT NULL,
  `stage_clicks` int(11) DEFAULT NULL,
  `diff_clicks` int(11) DEFAULT NULL,
  `fact_cost` decimal(19,2) DEFAULT NULL,
  `stage_cost` decimal(19,2) DEFAULT NULL,
  `diff_cost` decimal(19,2) DEFAULT NULL,
  `fact_order_conversion` int(11) DEFAULT NULL,
  `stage_order_conversion` int(11) DEFAULT NULL,
  `diff_order_conversion` int(11) DEFAULT NULL,
  `fact_revenue` decimal(19,2) DEFAULT NULL,
  `stage_revenue` decimal(19,2) DEFAULT NULL,
  `diff_revenue` decimal(19,2) DEFAULT NULL,
  `batchid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_date_asin` */

DROP TABLE IF EXISTS `vald_ams_date_asin`;

CREATE TABLE `vald_ams_date_asin` (
  `fact_unit_ordered` int(11) DEFAULT NULL,
  `stage_unit_ordered` int(11) DEFAULT NULL,
  `diff_unit_ordered` int(11) DEFAULT NULL,
  `fact_sales_other_sku` decimal(19,2) DEFAULT NULL,
  `stage_sales_other_sku` decimal(19,2) DEFAULT NULL,
  `diff_sales_other_sku` decimal(19,2) DEFAULT NULL,
  `fact_unit_ordered_other_sku` int(11) DEFAULT NULL,
  `stage_unit_ordered_other_sku` int(11) DEFAULT NULL,
  `diff_unit_ordered_other_sku` int(11) DEFAULT NULL,
  `batchid` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_date_keyword` */

DROP TABLE IF EXISTS `vald_ams_date_keyword`;

CREATE TABLE `vald_ams_date_keyword` (
  `fact_impressions` int(11) DEFAULT NULL,
  `stage_impressions` int(11) DEFAULT NULL,
  `diff_impressions` int(11) DEFAULT NULL,
  `fact_clicks` int(11) DEFAULT NULL,
  `stage_clicks` int(11) DEFAULT NULL,
  `diff_clicks` int(11) DEFAULT NULL,
  `fact_cost` decimal(19,2) DEFAULT NULL,
  `stage_cost` decimal(19,2) DEFAULT NULL,
  `diff_cost` decimal(19,2) DEFAULT NULL,
  `fact_order_conversion` int(11) DEFAULT NULL,
  `stage_order_conversion` int(11) DEFAULT NULL,
  `diff_order_conversion` int(11) DEFAULT NULL,
  `fact_revenue` decimal(19,2) DEFAULT NULL,
  `stage_revenue` decimal(19,2) DEFAULT NULL,
  `diff_revenue` decimal(19,2) DEFAULT NULL,
  `batchid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_ams_date_product` */

DROP TABLE IF EXISTS `vald_ams_date_product`;

CREATE TABLE `vald_ams_date_product` (
  `fact_impressions` int(11) DEFAULT NULL,
  `stage_impressions` int(11) DEFAULT NULL,
  `diff_impressions` int(11) DEFAULT NULL,
  `fact_clicks` int(11) DEFAULT NULL,
  `stage_clicks` int(11) DEFAULT NULL,
  `diff_clicks` int(11) DEFAULT NULL,
  `fact_cost` decimal(19,2) DEFAULT NULL,
  `stage_cost` decimal(19,2) DEFAULT NULL,
  `diff_cost` decimal(19,2) DEFAULT NULL,
  `fact_order_conversion` int(11) DEFAULT NULL,
  `stage_order_conversion` int(11) DEFAULT NULL,
  `diff_order_conversion` int(11) DEFAULT NULL,
  `fact_revenue` decimal(19,2) DEFAULT NULL,
  `stage_revenue` decimal(19,2) DEFAULT NULL,
  `diff_revenue` decimal(19,2) DEFAULT NULL,
  `batchid` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_date_purchaseorders` */

DROP TABLE IF EXISTS `vald_date_purchaseorders`;

CREATE TABLE `vald_date_purchaseorders` (
  `fact_total_cost` decimal(19,2) DEFAULT NULL,
  `stage_total_cost` decimal(19,2) DEFAULT NULL,
  `diff_total_cost` decimal(19,2) DEFAULT NULL,
  `fact_accepted_case_cost` decimal(19,2) DEFAULT NULL,
  `stage_accepted_case_cost` decimal(19,2) DEFAULT NULL,
  `diff_accepted_case_cost` decimal(19,2) DEFAULT NULL,
  `fact_rejected_case_cost` decimal(19,2) DEFAULT NULL,
  `stage_rejected_case_cost` decimal(19,2) DEFAULT NULL,
  `diff_rejected_case_cost` decimal(19,2) DEFAULT NULL,
  `fact_total_po_cost` decimal(19,2) DEFAULT NULL,
  `stage_total_po_cost` decimal(19,2) DEFAULT NULL,
  `diff_total_po_cost` decimal(19,2) DEFAULT NULL,
  `batchid` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_inventory_account` */

DROP TABLE IF EXISTS `vald_inventory_account`;

CREATE TABLE `vald_inventory_account` (
  `fk_account_id` int(11) DEFAULT NULL,
  `stage_seller_inv_units` decimal(19,4) DEFAULT NULL,
  `fact_seller_inv_units` decimal(19,4) DEFAULT NULL,
  `seller_inv_units_diff` decimal(19,4) DEFAULT NULL,
  `stage_unseller_inv_units` decimal(19,4) DEFAULT NULL,
  `fact_unseller_inv_units` decimal(19,4) DEFAULT NULL,
  `unseller_inv_units_diff` decimal(19,4) DEFAULT NULL,
  `table_validation` varchar(100) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_inventory_date` */

DROP TABLE IF EXISTS `vald_inventory_date`;

CREATE TABLE `vald_inventory_date` (
  `stage_seller_inv_units` decimal(19,4) DEFAULT NULL,
  `fact_seller_inv_units` decimal(19,4) DEFAULT NULL,
  `seller_inv_units_diff` decimal(19,4) DEFAULT NULL,
  `stage_unseller_inv_units` decimal(19,4) DEFAULT NULL,
  `fact_unseller_inv_units` decimal(19,4) DEFAULT NULL,
  `unseller_inv_units_diff` decimal(19,4) DEFAULT NULL,
  `table_validation` varchar(100) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_purchesorder_account` */

DROP TABLE IF EXISTS `vald_purchesorder_account`;

CREATE TABLE `vald_purchesorder_account` (
  `fk_account_id` int(11) DEFAULT NULL,
  `stage_total_cost` decimal(19,4) DEFAULT NULL,
  `fact_total_cost` decimal(19,4) DEFAULT NULL,
  `total_cost_diff` decimal(19,4) DEFAULT NULL,
  `stage_accepted_case` decimal(19,4) DEFAULT NULL,
  `fact_accepted_case` decimal(19,4) DEFAULT NULL,
  `accepted_case_diff` decimal(19,4) DEFAULT NULL,
  `stage_rejected_case` decimal(19,4) DEFAULT NULL,
  `fact_rejected_case` decimal(19,4) DEFAULT NULL,
  `rejected_case_diff` decimal(19,4) DEFAULT NULL,
  `stage_total_po_cost` decimal(19,4) DEFAULT NULL,
  `fact_total_po_cost` decimal(19,4) DEFAULT NULL,
  `total_po_cost_diff` decimal(19,4) DEFAULT NULL,
  `table_validation` varchar(100) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_sales_account` */

DROP TABLE IF EXISTS `vald_sales_account`;

CREATE TABLE `vald_sales_account` (
  `fk_account_id` int(11) DEFAULT NULL,
  `stage_shipped_cogs` decimal(19,4) DEFAULT NULL,
  `fact_shipped_cogs` decimal(19,4) DEFAULT NULL,
  `shipped_cogs_diff` decimal(19,4) DEFAULT NULL,
  `stage_shipped_unit` decimal(19,4) DEFAULT NULL,
  `fact_shipped_unit` decimal(19,4) DEFAULT NULL,
  `shipped_unit_diff` decimal(19,4) DEFAULT NULL,
  `table_validation` varchar(100) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_sales_date` */

DROP TABLE IF EXISTS `vald_sales_date`;

CREATE TABLE `vald_sales_date` (
  `stage_shipped_cogs` decimal(19,4) DEFAULT NULL,
  `fact_shipped_cogs` decimal(19,4) DEFAULT NULL,
  `shipped_cogs_diff` decimal(19,4) DEFAULT NULL,
  `stage_shipped_unit` decimal(19,4) DEFAULT NULL,
  `fact_shipped_unit` decimal(19,4) DEFAULT NULL,
  `shipped_unit_diff` decimal(19,4) DEFAULT NULL,
  `table_validation` varchar(100) DEFAULT NULL,
  `batchid` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_scraping_account` */

DROP TABLE IF EXISTS `vald_scraping_account`;

CREATE TABLE `vald_scraping_account` (
  `stage_Accountkey` int(11) DEFAULT NULL,
  `stage_review_count` decimal(19,4) DEFAULT NULL,
  `fact_review_count` decimal(19,4) DEFAULT NULL,
  `review_cost_diff` decimal(19,4) DEFAULT NULL,
  `table_validation` varchar(100) DEFAULT NULL,
  `stage_capture_date` varchar(50) DEFAULT NULL,
  `fact_capture_date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `vald_scraping_date` */

DROP TABLE IF EXISTS `vald_scraping_date`;

CREATE TABLE `vald_scraping_date` (
  `FactReviewCount` double(19,2) DEFAULT NULL,
  `StageReviewCount` double(19,2) DEFAULT NULL,
  `DiffReviewCount` double(19,2) DEFAULT NULL,
  `FactBatchID` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `StageBatchID` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/* Procedure structure for procedure `spPopulatePresentationCompCardTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationCompCardTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationCompCardTable`(IN max_date VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
		-- WARNING
	
	START TRANSACTION;
  
	SET autocommit = 0;
DELETE FROM `replica_adtec_bi`.`presentation_comp_card_vew` 
WHERE record_date  = DATE_FORMAT(max_date,'%Y-%m-%d');
INSERT INTO `replica_adtec_bi`.`presentation_comp_card_vew`
            (
            
              `cc_id`,
             `asin`,
             `category_id`,
             `subcategory_id`,
             daily_Pre_Paid,
             `daily_post_paid`,
             `record_date`,
             `creation_date`
          
             )
(
SELECT  NULL, aa.ASIN,aa.category_id,aa.subcategory_id, daily_Pre_Paid,
COALESCE(daily_Post_Paid,-1)  AS daily_Post_Paid,max_date
,NOW() AS creation_date
FROM
(
SELECT
1 AS pre_sr,ASIN,category_id,subcategory_id,
COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Pre_Paid
 FROM `tbl_cat_subcat_asin_vew_daily`
 
 WHERE DATE_FORMAT(`DATE`, '%Y-%m-%d')  >  DATE_SUB(DATE_FORMAT('20200101','%Y-%m-%d'), INTERVAL 6 DAY)
 AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <=  DATE_SUB(DATE_FORMAT('20200101', '%Y-%m-%d'), INTERVAL 1 DAY)
 AND    (YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2019 OR  YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020)
 AND COALESCE(salesrank,-1) != -1
 
  GROUP BY   ASIN,category_id,subcategory_id
)aa
LEFT JOIN 
(
SELECT
1 AS post_sr,ASIN,category_id,subcategory_id,
COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Post_Paid
 FROM `tbl_cat_subcat_asin_vew_daily`
 WHERE DATE_FORMAT(`DATE`, '%Y-%m-%d')  >  DATE_SUB(DATE_FORMAT('20200101','%Y-%m-%d'), INTERVAL 1 DAY)
 AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <=  DATE_SUB(DATE_FORMAT('20200101', '%Y-%m-%d'), INTERVAL -4 DAY) 
 AND     (YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2019 OR  YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020)
 AND COALESCE(salesrank,-1) != -1
 GROUP BY ASIN,category_id,subcategory_id 
)bb ON (aa.asin=bb.asin AND aa.category_id=bb.category_id AND aa.subcategory_id=bb.subcategory_id)
);
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulatePresentationCompCardTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulatePresentationCompCardTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spExpireExistingAccount` */

/*!50003 DROP PROCEDURE IF EXISTS  `spExpireExistingAccount` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spExpireExistingAccount`()
BEGIN
 DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
/* expire the existing Account Row                                   */
UPDATE 
  replica_adtec_bi.dim_account a,
  replica_adtec_bi.stage_account_client b 
SET
  expiry_date = SUBDATE(CURRENT_DATE,0)
  ,flag = 0
WHERE a.Account_ID = b.Account_ID 
  AND (
    a.Account_Name <> b.`accountName`
    OR a.`Account_Type` <> b.`account_type`
    OR a.`Account_Type_name` <> b.`account_type_name`
  ) 
  AND expiry_date = '9999-12-31' ;
  
  
    IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spExpireExistingAccount',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spExpireExistingAccount',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
  
  
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spExpireExistingProductCategory` */

/*!50003 DROP PROCEDURE IF EXISTS  `spExpireExistingProductCategory` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spExpireExistingProductCategory`()
BEGIN
UPDATE 
  dim_product_category_master a,
  stage_product_catalog b 
SET
  expiry_date = SUBDATE(CURRENT_DATE,0)
  ,flag = 0
WHERE a.fk_account_id  = b.fk_account_id AND a.`ASIN` = b.`ASIN`
  AND (
    a.`category_id` <> b.`category_id`  
 OR a.category_name <> b.category_name
 OR a.`subcategory_id` <> b.`subcategory_id`
 OR a.`subcategory_name` <> b.`subcategory_name`
  
   
  ) 
  AND expiry_date = '9999-12-31' ;
   
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spNewRowForChangingProductCategory` */

/*!50003 DROP PROCEDURE IF EXISTS  `spNewRowForChangingProductCategory` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spNewRowForChangingProductCategory`()
BEGIN
    
    INSERT INTO dim_product_category_master
SELECT DISTINCT
  NULL,
 
  b.fk_account_id,
  b.ASIN,
  b.category_id,
  b.category_name,
  b.subcategory_id,
  b.subcategory_name,
  
  b.capture_date,
  b.`last_refresh`,
             
  CURRENT_DATE,
  '9999-12-31',
  1,
  CURRENT_TIMESTAMP
FROM
  dim_product_category_master a,
  stage_product_catalog b 
  
  WHERE a.fk_account_id  = b.fk_account_id AND a.`ASIN` = b.`ASIN`
  AND (
    a.`category_id` <> b.`category_id`  
 OR a.category_name <> b.category_name
 OR a.`subcategory_id` <> b.`subcategory_id`
 OR a.`subcategory_name` <> b.`subcategory_name`
  ) 
  
  
  
  AND EXISTS 
  (
  SELECT 
    * 
  FROM
    dim_product_category_master xx
  WHERE b.fk_account_id  = xx.fk_account_id AND b.`ASIN` = xx.`ASIN`
    AND a.expiry_date = SUBDATE(CURRENT_DATE, 0)
   
   
    AND NOT EXISTS 
    (SELECT 
      * 
    FROM
      dim_product_category_master yy
    WHERE b.fk_account_id  = yy.fk_account_id AND b.`ASIN` = yy.`ASIN`
      AND yy.expiry_date = '9999-12-31') );
      
      
      
      
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateTimeComTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateTimeComTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateTimeComTable`(in `max_var` varchar(20))
Begin
	
	declare `year` varchar(4);
	declare `month` Varchar(2);
	declare `day` varchar(2);
	declare `Max_Date` date;
	set `Max_Date` = date_format(`max_var`,'%Y-%m-%d');
	set `year`=Year(Max_Date);
	set `month`=month(Max_Date);
	set `day`=day(Max_Date);
	SELECT 
	   b.ytd
	   ,a.mtd
	   ,a.pm_key
	   ,`month`
	FROM
	   (SELECT
		pm_key
		,ROUND (COALESCE(SUM(shipped_units)/
				(SELECT 
				   SUM(shipped_units) 
				FROM 
				   fact_sales_master 
				WHERE 
				   DATE_FORMAT(
				   date_key,'%Y-%m-%d') 
				BETWEEN 
				   DATE_FORMAT(
				   CONCAT(`year`-1,'0101'),'%Y-%m-%d')
				AND 
				   DATE_FORMAT(
				   CONCAT(`year`-1,RIGHT(Max_Date,4)),'%Y-%m-%d') 
				GROUP BY 
				   pm_key)
		   ,0),2) AS ytd
		FROM 
		   fact_sales_master 
		WHERE 
		   DATE_FORMAT(
		   date_key,'%Y-%m-%d') 
		BETWEEN 
		   DATE_FORMAT(
		   CONCAT(`year`,'0101'),'%Y-%m-%d') 
		AND 
		   `Max_Date`
		GROUP BY 
		   pm_key)b 
		
	INNER JOIN
	   (SELECT 
		b.pm_key
		,ROUND (COALESCE(SUM(shipped_units)/
			(SELECT 
			   SUM(shipped_units)
			FROM 
			   fact_sales_master
			WHERE 
			   pm_key = b.pm_key
			AND
				CASE WHEN `month` > 1 THEN
					   DATE_FORMAT(date_key,'%Y-%m-%d') 
					BETWEEN 
					   DATE_FORMAT(
					   CONCAT(`year`,LPAD(`month`-1,2,'0'),'01'),'%Y-%m-%d') 
					AND 
					   DATE_FORMAT(
					   CONCAT(`year`,LPAD(`month`-1,2,'0'),`day`),'%Y-%m-%d')
				ELSE 
					   DATE_FORMAT(date_key,'%Y-%m-%d') 
					BETWEEN 
					   DATE_FORMAT(
					   CONCAT(`year`-1,'1201'),'%Y-%m-%d') 
					AND 
					   DATE_FORMAT(
					   CONCAT(`year`-1,'12',`day`),'%Y-%m-%d')
				END
			GROUP BY 
			   pm_key
		)
		   ,0),2) AS mtd
		FROM 
		   fact_sales_master b
		WHERE
		   DATE_FORMAT(date_key,'%Y-%m-%d') 
		BETWEEN 
		   DATE_FORMAT(
		   CONCAT(`year`,LPAD(`month`,2,'0'),'01'),'%Y-%m-%d') 
		AND 
		   DATE_FORMAT(`Max_date`,'%Y-%m-%d')
		GROUP BY 
		   pm_key	
		)a 
	ON a.pm_key=b.pm_key;
End */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePrestationDaily` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePrestationDaily` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePrestationDaily`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  TRUNCATE prst_vew_performance_daily;
  -- ===============================================================================================
INSERT INTO `replica_adtec_bi`.` prst_vew_performance_daily`
SELECT
`account_name`,
cost,
revenue,
CASE WHEN revenue > 0 THEN  (  `cost` / Revenue) ELSE 0 END AS acos_
 
 FROM
(
SELECT
  
  `account_name`,
 SUM( `cost`) cost,
 SUM(`revenue`) revenue
 
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
record_date >=   DATE_FORMAT(NOW()-30, "%Y-%m-%d")
AND record_date <= DATE_FORMAT(NOW(), "%Y-%m-%d")
GROUP BY `account_name`
)t;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      `spPopulatePresentationDaily`,
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      `spPopulatePresentationDaily`,
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateDimTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateDimTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateDimTable`(BeginDate DATETIME, EndDate DATETIME)
BEGIN
 
 # Holds a flag so we can determine if the date is the last day of month
 DECLARE LastDayOfMon CHAR(1);
 # Number of months to add to the date to get the current Fiscal date
 DECLARE FiscalYearMonthsOffset INT;
 # These two counters are used in our loop.
 DECLARE DateCounter DATETIME;    #Current date in loop
 DECLARE FiscalCounter DATETIME;  #Fiscal Year Date in loop
 SET FiscalYearMonthsOffset = 6;
 # Start the counter at the begin date
 SET DateCounter = BeginDate;
 WHILE DateCounter <= EndDate DO
            # Calculate the current Fiscal date as an offset of
            # the current date in the loop
            SET FiscalCounter = DATE_ADD(DateCounter, INTERVAL FiscalYearMonthsOffset MONTH);
            # Set value for IsLastDayOfMonth
            IF MONTH(DateCounter) = MONTH(DATE_ADD(DateCounter, INTERVAL 1 DAY)) THEN
               SET LastDayOfMon = 'N';
            ELSE
               SET LastDayOfMon = 'Y';
   END IF;
            # add a record into the date dimension table for this date
            INSERT  INTO replica_adtec_bi.dim_date
       (date_key
       ,full_date
       ,date_name
       ,date_name_us
       ,date_name_eu
       ,day_of_week
       ,day_name_of_week
       ,day_of_month
       ,day_of_year
       ,weekday_weekend
       ,week_of_month
       ,week_name_of_month
       ,week_of_year
       ,week_name_of_year
       ,month_name
       ,month_of_year
       ,is_last_day_of_month
       ,calendar_quarter
       ,calendar_year
       ,calendar_year_month
       ,calendar_year_qtr
       ,fiscal_month_of_year
       ,fiscal_quarter
       ,fiscal_year
       ,fiscal_year_month
       ,fiscal_year_qtr)
            VALUES  (
                      ( YEAR(DateCounter) * 10000 ) + ( MONTH(DateCounter)* 100 )+ DAY(DateCounter)  #DateKey
                    , DateCounter # FullDate
                    , CONCAT(CAST(YEAR(DateCounter) AS CHAR(4)),'/',DATE_FORMAT(DateCounter,'%m'),'/',DATE_FORMAT(DateCounter,'%d')) #DateName
                    , CONCAT(DATE_FORMAT(DateCounter,'%m'),'/',DATE_FORMAT(DateCounter,'%d'),'/',CAST(YEAR(DateCounter) AS CHAR(4)))#DateNameUS
                    , CONCAT(DATE_FORMAT(DateCounter,'%d'),'/',DATE_FORMAT(DateCounter,'%m'),'/',CAST(YEAR(DateCounter) AS CHAR(4)))#DateNameEU
                    , DAYOFWEEK(DateCounter) #DayOfWeek
                    , DAYNAME(DateCounter) #DayNameOfWeek
                    , DAYOFMONTH(DateCounter) #DayOfMonth
                    , DAYOFYEAR(DateCounter) #DayOfYear
                    , CASE DAYNAME(DateCounter)
                        WHEN 'Saturday' THEN 'Weekend'
                        WHEN 'Sunday' THEN 'Weekend'
                        ELSE 'Weekday'
                      END #WeekdayWeekend
                    , FLOOR((DAYOFMONTH(DateCounter) - 1) / 7) + 1 #WeekOfMonth
                    , CONCAT('Week ',FLOOR((DAYOFMONTH(DateCounter) - 1) / 7) + 1) #WeekName
                    , WEEK(DateCounter,6) #WeekOfYear
                    , CONCAT('Week ', WEEK(DateCounter,6))
                    , MONTHNAME(DateCounter) #MonthName
                    , MONTH(DateCounter) #MonthOfYear
                    , LastDayOfMon #IsLastDayOfMonth
                    , QUARTER(DateCounter) #CalendarQuarter
                    , YEAR(DateCounter) #CalendarYear
                    , CONCAT(CAST(YEAR(DateCounter) AS CHAR(4)),'-',DATE_FORMAT(DateCounter,'%m')) #CalendarYearMonth
                    , CONCAT(CAST(YEAR(DateCounter) AS CHAR(4)),'Q',QUARTER(DateCounter)) #CalendarYearQtr
                    , MONTH(FiscalCounter) #[FiscalMonthOfYear]
                    , QUARTER(FiscalCounter) #[FiscalQuarter]
                    , YEAR(FiscalCounter) #[FiscalYear]
                    , CONCAT(CAST(YEAR(FiscalCounter) AS CHAR(4)),'-',DATE_FORMAT(FiscalCounter,'%m')) #[FiscalYearMonth]
                    , CONCAT(CAST(YEAR(FiscalCounter) AS CHAR(4)),'Q',QUARTER(FiscalCounter)) #[FiscalYearQtr]
                    );
            # Increment the date counter for next pass thru the loop
            SET DateCounter = DATE_ADD(DateCounter, INTERVAL 1 DAY);
      END WHILE;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spUpdateDimProductMasterAttributes` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUpdateDimProductMasterAttributes` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUpdateDimProductMasterAttributes`()
BEGIN
DELETE
FROM `replica_adtec_bi`.`dim_product_master_attributes`
WHERE  ASIN IN  (SELECT DISTINCT asins FROM  stage_product_catalog);
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spWOWCheck` */

/*!50003 DROP PROCEDURE IF EXISTS  `spWOWCheck` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spWOWCheck`(IN max_date VARCHAR(20))
BEGIN
DECLARE `startdate` VARCHAR(20);
DECLARE `enddate` VARCHAR(20);
SET `startdate` = DATE_ADD(max_date,INTERVAL -(DAYOFWEEK(max_date)-1) DAY);
SET `enddate`=DATE_ADD(`startdate`,INTERVAL 7 DAY);
SELECT 	
		ROUND(COALESCE((SUM(shipped_units)-(SELECT 
		   SUM(shipped_units)
		FROM
		   fact_sales_master b
		WHERE
		b.pm_key = a.pm_key
		AND
		CASE WHEN WEEK(a.date_key) > 0 THEN
		   DATE_FORMAT(b.date_key,'%Y-%m-%d') BETWEEN DATE_ADD(startdate,INTERVAL -7 DAY)
			      AND   DATE_ADD(enddate,INTERVAL -7 DAY)
		 ELSE
		   b.date_key BETWEEN CONCAT(YEAR(a.date_key),'0101') AND a.date_key
		END
		GROUP BY
		   b.pm_key
		   
		   
		  ))/(
			SELECT 
		            SUM(shipped_units)
			FROM
			   fact_sales_master b
			WHERE
			   b.pm_key = a.pm_key
			AND
			CASE WHEN WEEK(a.date_key) > 0 THEN
			   DATE_FORMAT(b.date_key,'%Y-%m-%d') BETWEEN DATE_ADD(startdate,INTERVAL -7 DAY)
								AND   DATE_ADD(enddate,INTERVAL -7 DAY)
			ELSE
			   b.date_key BETWEEN CONCAT(YEAR(a.date_key),'0101') AND a.date_key
			END
			GROUP BY
			   b.pm_key
			
		  ),0)
		  ,2) AS WOW,
		  pm_key
FROM
   fact_sales_master a
WHERE
   a.date_key BETWEEN startdate AND enddate
GROUP BY
   a.pm_key
   ,a.date_key;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPresentPerfromanceYtd` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPresentPerfromanceYtd` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPresentPerfromanceYtd`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      `spPresentPerfromanceYtd`,
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      `spPresentPerfromanceYtd`,
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateClientDimTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateClientDimTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateClientDimTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
    
INSERT IGNORE INTO replica_adtec_bi.dim_brand
SELECT
DISTINCT 
  NULL,
  stage_account_client.`agency_id`,
  stage_account_client.`Agency_Name`,
  stage_account_client.`client_id`,
  stage_account_client.`client_name`,
  stage_account_client.`client_email`,
  stage_account_client.`client_account_password`,
  stage_account_client.`client_creation`,
  stage_account_client.`client_updation`,
  CURRENT_DATE
FROM `replica_adtec_bi`.`stage_account_client`
 LEFT JOIN replica_adtec_bi.dim_brand ON dim_brand.`Client_ID` = `stage_account_client`. `client_id`
 WHERE replica_adtec_bi.dim_brand.`Client_ID` IS NULL;
 
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateClientDimTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateClientDimTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
  
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spNewRowForChangingAccount` */

/*!50003 DROP PROCEDURE IF EXISTS  `spNewRowForChangingAccount` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spNewRowForChangingAccount`()
BEGIN
 DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
      
/* add a new row for the changing Account                          */
INSERT INTO dim_account
SELECT DISTINCT
  NULL,
  b.Account_ID,
  cl.`Client_Key`,
 -- b.Client_ID,
  b.`marketplaceid`,
  b.`Account_Type`,
  b.`Account_Type_name`,
  b.`fkId`,
  b.`accountName`,
  b.`account_creation`,
  b.`account_updation`,
  
  CURRENT_DATE,
  '9999-12-31',
  1,
  CURRENT_DATE
FROM 
(
SELECT DISTINCT
 -- NULL,
  b.Account_ID,
  b.Client_ID,
  b.`marketplaceid`,
  b.`Account_Type`,
  b.`Account_Type_name`,
  b.`fkId`,
  b.`accountName`,
  b.`account_creation`,
  b.`account_updation`
  
  -- CURRENT_DATE,
  -- '9999-12-31',
  -- 1,
  -- CURRENT_TIMESTAMP
FROM
  replica_adtec_bi.dim_account a,
  replica_adtec_bi.stage_account_client b 
  WHERE a.Account_ID = b.Account_ID 
  AND (
    a.Account_Name <> b.`accountName`
    OR a.`Account_Type` <> b.`account_type`
    OR a.`Account_Type_name` <> b.`account_type_name`
  ) 
  
  AND EXISTS 
  (
  SELECT 
    * 
  FROM
    replica_adtec_bi.dim_account xx
  WHERE b.`account_id` = xx.`Account_ID` 
    AND a.expiry_date = SUBDATE(CURRENT_DATE, 0)
   
   
    AND NOT EXISTS 
    (SELECT 
      * 
    FROM
      replica_adtec_bi.dim_account yy
    WHERE b.`account_id` = yy.`Account_ID`
      AND yy.expiry_date = '9999-12-31') )
      
)b LEFT JOIN `dim_brand` cl ON (b.Client_ID = cl.`Client_ID`);
      
    IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spNewRowForChangingAccount',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spNewRowForChangingAccount',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
      
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spUpdateDimProductMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUpdateDimProductMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUpdateDimProductMaster`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
UPDATE replica_adtec_bi.dim_product_master AS l
 INNER JOIN replica_adtec_bi.stage_product_catalog   AS r
ON (l.fk_account_id  = r.fk_account_id   AND l.ASIN = r.ASIN AND l.sku = r.sku AND l.`fulfillment_channel` = r.`fulfillment_channel`)
SET 
 
 l.`model` = r.`model` , l.`Load_Date` = CURRENT_DATE
 WHERE l.`model` != r.`model` ;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spUpdateDimProductMaster',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spUpdateDimProductMaster',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelSalesValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelSalesValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelSalesValidationTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	-- Insert Data Date Validation Table To Validate Satge and Fact Has same data 
	-- (for a specific date) By subtracting Fact and Stage Shipped_COGS and Shipped Units
	insert Into `replica_adtec_bi`.`vald_sales_date`(
		SELECT 
		
		stage_shipped_cogs
		,fact_shipped_cogs
		,fact_shipped_cogs - stage_shipped_cogs AS shipped_cogs_diff
		,stage_shipped_unit
		,fact_shipped_unit
		,fact_shipped_unit - stage_shipped_unit AS shipped_unite_diff
		,'fact_sales_data_date_level'
		,stage_batchid
		FROM (
			SELECT 
			SUM(shipped_cogs) AS stage_shipped_cogs
			,SUM(shipped_unit) AS stage_shipped_unit
			,LEFT(batchid,8) AS stage_batchid
			FROM 
			`replica_adtec_bi`.`stage_sales_master`
			GROUP BY 
			LEFT(batchid,8)
)stage
 
		INNER JOIN (
			SELECT  
			SUM(shipped_cogs) AS fact_shipped_cogs
			,SUM(shipped_units) AS fact_shipped_unit
			,LEFT(batchid,8) AS fact_batchid
			FROM
			`replica_adtec_bi`.fact_sales_master
			WHERE 
			batchid = `max_date`
			GROUP BY 
			batchid
)fact  
		ON (stage_batchid = fact_batchid)
);
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateDateLevelSalesValidationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateDateLevelSalesValidationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
);
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelSalesValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelSalesValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelSalesValidationTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	-- Insert Data in Account Validation Table To Validate Satge and Fact Has same data 
	-- (for a specific Account) By subtracting Fact and Stage Shipped_COGS and Shipped Units
	INSERT INTO `replica_adtec_bi`.`vald_sales_account` (
		SELECT
		
		 stage_AccountKey
		,stage_shipped_cogs
		,fact_shipped_cogs
		,fact_shipped_cogs - stage_shipped_cogs AS shipped_cogs_diff
		,stage_shipped_unit
		,fact_shipped_unit
		,fact_shipped_unit - stage_shipped_unit AS shipped_unite_diff
		,'fact_sales_data_account_level'
		,stage_batchid
	FROM  (
		SELECT 
		fk_account_id AS stage_AccountKey
		,SUM(shipped_cogs) AS stage_shipped_cogs
		,SUM(shipped_unit) AS stage_shipped_unit
		,LEFT(batchid,8) AS stage_batchid
		FROM 
		`replica_adtec_bi`.`stage_sales_master`
 		GROUP BY 
 		fk_account_id
 		,LEFT(batchid,8)
)stage
 
	INNER JOIN (
		SELECT 
		cc.fk_account_id  AS fact_AccountKey   
		,SUM(shipped_cogs) AS fact_shipped_cogs
		,SUM(shipped_units) AS fact_shipped_unit
		,batchid AS fact_batchid
 		FROM
		`replica_adtec_bi`.fact_sales_master aa
		  LEFT JOIN replica_adtec_bi.`dim_product_category_master` cc ON (cc.`pm_cat_id` = aa.`pm_cat_id` )
 		WHERE 
 		batchid = `max_date`
  		GROUP BY 
  		cc.fk_account_id 
  		,batchid
)fact 
	ON (stage_AccountKey = fact_AccountKey)
);
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAccountLevelSalesValidationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAccountLevelSalesValidationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
);
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelInventoryValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelInventoryValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelInventoryValidationTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	-- Insert Data Date Validation Table To Validate Satge and Fact Has same data 
	-- (for a specific date) By subtracting Fact and Stage Shipped_COGS and Shipped Units
		INSERT INTO `replica_adtec_bi`.`vald_inventory_date`(
		SELECT 
		
		stage_seller_inv_units
		,fact_seller_inv_units
		,fact_seller_inv_units - stage_seller_inv_units AS seller_inv_units_diff
		,stage_unseller_inv_units
		,fact_unseller_inv_units
		,fact_unseller_inv_units - stage_unseller_inv_units AS unseller_inv_units_diff
		,'fact_inventory_data_date_level'
		,stage_batchid
		FROM (
			SELECT 
			SUM(seller_inv_units) AS stage_seller_inv_units
			,SUM(unseller_inv_units) AS stage_unseller_inv_units
			,left(batchid,8) AS stage_batchid
			FROM 
			`replica_adtec_bi`.`stage_inventory_master`
			GROUP BY 
			LEFT(batchid,8)
)stage
 
		INNER JOIN (
			SELECT  
			 SUM(sellable_inv_units) AS fact_seller_inv_units
			,SUM(unsellable_inv_units) AS fact_unseller_inv_units
			,batchid AS fact_batchid
			FROM
			`replica_adtec_bi`.fact_inventory_master
			WHERE 
			batchid = `max_date`
			GROUP BY 
			batchid
)fact  
		ON (stage_batchid = fact_batchid)
 );
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateDateLevelInventoryValidationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateDateLevelInventoryValidationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
);
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelInventoryValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelInventoryValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelInventoryValidationTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	-- Insert Data in Account Validation Table To Validate Satge and Fact Has same data 
	-- (for a specific Account) By subtracting Fact and Stage Shipped_COGS and Shipped Units
	        INSERT INTO `replica_adtec_bi`.`vald_inventory_account`(
		SELECT 
		
		stage_AccountKey
		,stage_seller_inv_units
		,fact_seller_inv_units
		,fact_seller_inv_units - stage_seller_inv_units AS seller_inv_units_diff
		,stage_unseller_inv_units
		,fact_unseller_inv_units
		,fact_unseller_inv_units - stage_unseller_inv_units AS unseller_inv_units_diff
		,'fact_inventory_data_account_level'
		,stage_batchid
		FROM (
			SELECT 
			fk_account_id AS stage_AccountKey
			,SUM(seller_inv_units) AS stage_seller_inv_units
			,SUM(unseller_inv_units) AS stage_unseller_inv_units
			,left(batchid,8) AS stage_batchid
			FROM 
			`replica_adtec_bi`.`stage_inventory_master`
			GROUP BY 
			fk_account_id,LEFT(batchid,8)
)stage
 
		INNER JOIN (
			SELECT  
			 cc.fk_account_id  AS fact_AccountKey 
			,SUM(sellable_inv_units) AS fact_seller_inv_units
			,SUM(unsellable_inv_units) AS fact_unseller_inv_units
			,batchid AS fact_batchid
			FROM
			`replica_adtec_bi`.fact_inventory_master aa
			  LEFT JOIN replica_adtec_bi.`dim_product_category_master` cc ON (cc.`pm_cat_id` = aa.`pm_cat_id` )
			WHERE 
			batchid = `max_date`
			GROUP BY 
			cc.fk_account_id  ,batchid
)fact  
		ON (stage_AccountKey = fact_AccountKey)
 );
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAccountLevelInventoryValidationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAccountLevelInventoryValidationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
);
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAmsFilters` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAmsFilters` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAmsFilters`()
BEGIN
  SELECT 
    profile_name,
    campaign_name,
    ' ' AS producttype,
    ' ' as strategytype 
  from
       prst_tbl_ams_campaign; 
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewAccountDimension` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewAccountDimension` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewAccountDimension`()
    SQL SECURITY INVOKER
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  
  SET autocommit = 0 ;
                                   
INSERT INTO dim_account
SELECT DISTINCT
   NULL
 , b.Account_ID
 , cl.`Client_Key`
 , b.`marketplaceid`
 , b.`Account_Type`
 , b.`Account_Type_name`
 , b.`fkId`
 , b.`accountName`
 , b.`account_creation`
 , b.`account_updation`
 , CURRENT_DATE
 , '9999-12-31'
 , 1
 , CURRENT_DATE
FROM
   (
      SELECT DISTINCT
         -- NULL,
          b.Account_ID
       , b.Client_ID
       , b.`marketplaceid`
       , b.`Account_Type`
       , b.`Account_Type_name`
       , b.`fkId`
       , b.`accountName`
       , b.`account_creation`
       , b.`account_updation`
         -- CURRENT_DATE,
          -- '9999-12-31',
          -- 1,
          -- CURRENT_TIMESTAMP
      FROM
         replica_adtec_bi.stage_account_client b
      WHERE
         Account_ID NOT IN
         (
            SELECT
               yy.Account_ID
            FROM
               dim_account          xx
             , stage_account_client yy
            WHERE
               xx.Account_ID = yy.Account_ID
         )
   )
   b
   LEFT JOIN
      `dim_brand` cl
      ON
         (
            b.Client_ID = cl.`Client_ID`
         )
;
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewAccountDimension'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  ROLLBACK;  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewAccountDimension'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  COMMIT;  
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewProductCategory` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewProductCategory` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewProductCategory`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  
  SET autocommit = 0 ;
INSERT INTO dim_product_category_master
SELECT DISTINCT
   NULL
 , b.category_id
 , b.category_name
 , b.capture_date
 , b.record_date
 , CURRENT_TIMESTAMP
 , CURRENT_DATE
 , '9999-12-31'
 , 1
 , CURRENT_TIMESTAMP
FROM
   stage_product_catalog b
WHERE
   b.category_id NOT IN
   (
      SELECT
         yy.category_id
      FROM
         dim_product_category_master xx
       , stage_product_catalog       yy
      WHERE
         xx.category_id = yy.category_id
   )
;
  
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewProductCategory'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  ROLLBACK;  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewProductCategory'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  COMMIT;  
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimProductCategoryMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimProductCategoryMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimProductCategoryMaster`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  
  SET autocommit = 0 ;
INSERT INTO dim_product_category_master
SELECT DISTINCT
   NULL
 , b.`fk_account_id`
 , b.`ASIN`
 , b.`category_id`
 , b.`category_name`
 , b.`subcategory_id`
 , b.`subcategory_name`
 , CURRENT_DATE
 , '9999-12-31'
 , 1
 , CURRENT_DATE
FROM
   replica_adtec_bi.stage_product_catalog b
WHERE
   (
      b.`fk_account_id`
    ,b.`ASIN`
   )
   NOT IN
   (
      SELECT
         yy.`fk_account_id`
       , yy.`ASIN`
      FROM
         replica_adtec_bi.dim_product_category_master xx
       , replica_adtec_bi.stage_product_catalog       yy
      WHERE
         xx.`fk_account_id` = yy.`fk_account_id`
         AND xx.`ASIN`      = yy.`ASIN`
   )
;
 
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimProductCategoryMaster'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimProductCategoryMaster'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimProductMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimProductMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimProductMaster`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
	
INSERT INTO dim_product_master
      SELECT DISTINCT
         Null
       , b.`fk_account_id`
       , b.`ASIN`
       , b.`sku`
       , b.`model`
       , b.`fulfillment_channel`
       , b.`sc_status`
       , b.`vc_status`
       , CURRENT_DATE AS `LoadDate`
      FROM
         `replica_adtec_bi`.`stage_product_catalog` b
         LEFT OUTER JOIN
            `replica_adtec_bi`.dim_product_master AS r
            ON
               (
                  b.fk_account_id             = r.fk_account_id
                  AND b.ASIN                  = r.ASIN
                  AND b.sku                   = r.sku
                  AND b.`fulfillment_channel` = r.`fulfillment_channel`
               )
      WHERE
         r.ASIN IS NULL
      ;
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewRecordDimProductMaster'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewRecordDimProductMaster'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimProductMasterAttributes` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimProductMasterAttributes` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimProductMasterAttributes`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
INSERT INTO dim_product_master_attributes
SELECT
   NULL
 , l.fk_account_id
 , l.asins
 , l.sku
 , l.upc
 , l.release_date
 , l.color
 , l.product_title
 , l.size
 , l.product_length
 , l.product_width
 , l.product_height
 , l.parent_asins
 , l.brand
 , l.manufacturer
 , l.product_group
 , l.product_type
 , l.binding
 , l.last_refresh
 , l.capture_date
 , l.record_date
 , CURRENT_TIMESTAMP
FROM
   replica_adtec_bi.stage_product_catalog AS l
;
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewRecordDimProductMasterAttributes'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  ROLLBACK;  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewRecordDimProductMasterAttributes'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  COMMIT;  
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimProductMasterAttributesTransactions` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimProductMasterAttributesTransactions` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimProductMasterAttributesTransactions`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
DELETE
FROM
   dim_product_master_attributes_transactions
WHERE
   LEFT(batchid,8) = '20191217'
;
INSERT INTO dim_product_master_attributes_transactions
SELECT DISTINCT
   NULL AS pm_att_transac_id
 , fk_account_id
 , ASIN
 , sku
 , upc
 , release_date
 , color
 , product_title
 , size
 , product_length
 , product_width
 , product_height
 , parent_asins
 , brand
 , manufacturer
 , product_group
 , product_type
 , binding
 , price
 , product_ship_weight
 , capture_date
 , batchid
 , CURRENT_TIMESTAMP AS LoadDate
FROM
   `replica_adtec_bi`.`stage_product_catalog`
WHERE
   LEFT(batchid,8) = '20191217'
;
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewRecordDimProductMasterAttributesTransactions'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  ROLLBACK;  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewRecordDimProductMasterAttributesTransactions'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  COMMIT;  
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCampaignMapping` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCampaignMapping` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCampaignMapping`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
		
INSERT INTO `map_ams_report_type`
SELECT DISTINCT
   NULL
 , campaign_type
FROM
   `replica_adtec_bi`.`stage_campaign`
WHERE
   campaign_type NOT IN
   (
      SELECT DISTINCT
         `camp_type`
      FROM
         `replica_adtec_bi`.`map_ams_report_type`
   )
;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spCampaignMapping'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spCampaignMapping'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateMOMPercentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateMOMPercentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateMOMPercentages`(
  IN pro_id BIGINT,
  IN campaignid BIGINT
)
BEGIN
  -- ===============================================================================================
  SELECT 
    COALESCE (
      CASE
        WHEN cur_impressions > 0 
        THEN ROUND(
          (
            (
              (
                pre_impressions - cur_impressions
              ) / cur_impressions
            ) * 100
          ),
          2
        ) 
        ELSE 0.00 
      END,
      0.0
    ) AS impressions_perc,
    COALESCE (
      CASE
        WHEN cur_revenue > 0 
        THEN ROUND(
          (((pre_cost - cur_cost) / cur_cost) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.0
    ) AS cost_perc,
    COALESCE (
      CASE
        WHEN cur_revenue > 0 
        THEN ROUND(
          (
            (
              (pre_revenue - cur_revenue) / cur_revenue
            ) * 100
          ),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS revenue_perc,
    COALESCE (
      CASE
        WHEN cur_acos > 0 
        THEN ROUND(
          (((pre_acos - cur_acos) / cur_acos) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS acos_perc,
    COALESCE (
      CASE
        WHEN cur_cpc > 0 
        THEN ROUND((((pre_cpc - cur_cpc) / cur_cpc) * 100), 2) 
        ELSE 0.00 
      END,
      0.00
    ) AS cpc_perc,
    COALESCE (
      CASE
        WHEN cur_roas > 0 
        THEN ROUND(
          (((pre_roas - cur_roas) / cur_roas) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS roas_perc 
  FROM
    (SELECT 
      cur.clicks AS cur_clicks,
      cur.impressions AS cur_impressions,
      pre.clicks AS pre_clicks,
      pre.impressions AS pre_impressions,
      cur.cost AS cur_cost,
      cur.revenue AS cur_revenue,
      pre.cost AS pre_cost,
      pre.revenue AS pre_revenue,
      CASE
        WHEN cur.impressions > 0 
        THEN ROUND(cur.clicks / cur.impressions, 2) 
        ELSE 0 
      END AS cur_ctr,
      CASE
        WHEN pre.impressions > 0 
        THEN ROUND(pre.clicks / pre.impressions, 2) 
        ELSE 0 
      END AS pre_ctr,
      CASE
        WHEN cur.revenue > 0 
        THEN ROUND(cur.cost / cur.revenue, 2) 
        ELSE 0 
      END AS cur_acos,
      CASE
        WHEN pre.revenue > 0 
        THEN ROUND(pre.cost / pre.revenue, 2) 
        ELSE 0 
      END AS pre_acos,
      CASE
        WHEN cur.clicks > 0 
        THEN ROUND(cur.cost / cur.clicks, 2) 
        ELSE 0.00 
      END AS cur_cpc,
      CASE
        WHEN pre.clicks > 0 
        THEN ROUND(pre.cost / pre.clicks, 2) 
        ELSE 0.00 
      END AS pre_cpc,
      CASE
        WHEN cur.cost > 0 
        THEN ROUND(cur.revenue / cur.cost, 2) 
        ELSE 0.00 
      END AS cur_roas,
      CASE
        WHEN pre.cost > 0 
        THEN ROUND(pre.revenue / pre.cost, 2) 
        ELSE 0.00 
      END AS pre_roas 
    FROM
      (SELECT 
        1 AS curr,
        SUM(`impressions`) AS `impressions`,
        SUM(`cost`) AS cost,
        SUM(`revenue`) AS revenue,
        SUM(`clicks`) AS `clicks` 
      FROM
        `replica_adtec_bi`.`prst_tbl_ams_campaign` 
      WHERE `batchid` >= LAST_DAY(CURRENT_DATE) + INTERVAL 1 DAY - INTERVAL 1 MONTH 
        AND `batchid` < CURRENT_DATE 
        AND profile_id = pro_id 
        AND campaign_id = campaignid) cur 
      INNER JOIN 
        (SELECT 
          1 AS pr,
          SUM(`impressions`) AS `impressions`,
          SUM(`cost`) AS cost,
          SUM(`revenue`) AS revenue,
          SUM(`clicks`) AS `clicks` 
        FROM
          `replica_adtec_bi`.`prst_tbl_ams_campaign` 
        WHERE `batchid` >= LAST_DAY(CURRENT_DATE - 30) + INTERVAL 1 DAY - INTERVAL 1 MONTH 
          AND `batchid` < CURRENT_DATE - 30 
          AND `campaign_id` = campaignid 
          AND `profile_id` = pro_id) pre 
        ON (pr = curr)) t ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateCampaignPresentationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateCampaignPresentationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateCampaignPresentationTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO `prst_tbl_ams_campaign`
SELECT
  ee.`Client_ID`,
  ee.`Client_Name`,
  dd.`Account_ID`,
  dd.`Account_Name`,
  pp.profile_id,
  pp.profile_Name,
  
  `date_key`,
  bb.campaign_id,
   bb.`campaign_name`,
   cc.`camp_type`,
  `campaign_budget`,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
 
CASE WHEN revenue > 0 THEN  ROUND((Cost/Revenue),2) ELSE 0 END AS acos_,
CASE WHEN clicks > 0 THEN   ROUND((Cost/ clicks),2) ELSE 0 END AS CPC,
CASE WHEN `impressions` > 0 THEN  ROUND((Clicks/`impressions`),2) ELSE 0 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN ROUND((Cost/`order_conversion`),2) ELSE 0 END 	AS CPA,
CASE WHEN Cost > 0 THEN   ROUND((Revenue/Cost),2) ELSE 0 END  AS ROAS ,
aa.batchid,
aa.capture_date,
CURRENT_DATE AS loaddate  
FROM `replica_adtec_bi`.`fact_ams_campaign`  aa
LEFT JOIN `replica_adtec_bi`.`dim_campaign`         bb  ON (aa.`camp_key` = bb.`camp_key`)
LEFT JOIN `replica_adtec_bi`.`map_ams_profile`      pp  ON (pp.`profile_key` = bb.profile_key)
LEFT JOIN `replica_adtec_bi`.`map_ams_report_type`  cc  ON (bb.`camp_type_key` = cc.`camp_type_key`)
LEFT JOIN `replica_adtec_bi`.`dim_account`          dd  ON (dd.`Account_Key` = aa.`account_key` AND dd.flag = 1)
LEFT JOIN `replica_adtec_bi`.`dim_brand`            ee  ON (ee.`Client_Key` = aa.`client_key`)
WHERE aa.batchid = max_date;
 
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateCampaignPresentationTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateCampaignPresentationTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spUpNewRowForChangingProductCategory` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUpNewRowForChangingProductCategory` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUpNewRowForChangingProductCategory`()
BEGIN
    
    INSERT INTO dim_product_category_master
SELECT DISTINCT
  NULL,
 
  b.fk_account_id,
  b.ASIN,
  b.category_id,
  b.category_name,
  b.subcategory_id,
  b.subcategory_name,
  
             
  CURRENT_DATE,
  '9999-12-31',
  1,
  CURRENT_DATE
FROM
  dim_product_category_master a,
  stage_product_catalog b 
  
  WHERE a.fk_account_id  = b.fk_account_id AND a.`ASIN` = b.`ASIN`
  AND (
    a.`category_id` <> b.`category_id`  
 OR a.category_name <> b.category_name
 OR a.`subcategory_id` <> b.`subcategory_id`
 OR a.`subcategory_name` <> b.`subcategory_name`
  ) 
  
  
  
  AND EXISTS 
  (
  SELECT 
	 pm_cat_id,
	 fk_account_id,
	 ASIN,
	 category_id,
	 category_name,
	 subcategory_id,
	 subcategory_name,
	 effective_date,
	 expiry_date,
	 flag,
	 load_date
  FROM
    dim_product_category_master xx
  WHERE b.fk_account_id  = xx.fk_account_id AND b.`ASIN` = xx.`ASIN`
    AND a.expiry_date = SUBDATE(CURRENT_DATE, 0)
   
   
    AND NOT EXISTS 
    (SELECT 
         pm_cat_id,
	 fk_account_id,
	 ASIN,
	 category_id,
	 category_name,
	 subcategory_id,
	 subcategory_name,
	 effective_date,
	 expiry_date,
	 flag,
	 load_date 
    FROM
      dim_product_category_master yy
    WHERE b.fk_account_id  = yy.fk_account_id AND b.`ASIN` = yy.`ASIN`
      AND yy.expiry_date = '9999-12-31') );
      
      
      
      
    END */$$
DELIMITER ;

/* Procedure structure for procedure `test` */

/*!50003 DROP PROCEDURE IF EXISTS  `test` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `test`(IN col VARCHAR(20))
BEGIN
  SET @sql = CONCAT('SELECT ', col, ' FROM prst_vew_product_table');
  PREPARE stmt FROM @sql;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateDailyCampaignSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateDailyCampaignSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateDailyCampaignSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype varchar(50),
  IN numofdays INT
)
BEGIN
SELECT
  `brand_id`,
  `brand_name`,
  `accouint_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
   DATE_FORMAT( date_key, "%b %d,%Y") AS date_key,
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `campaign_budget`,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
  `acos`,
  `cpc`,
  `ctr`,
  `cpa`,
  `roas`
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE `profile_id` = pro_id
       -- AND campaign_type = campaigntype 
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
       ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateDailyKeywordSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateDailyKeywordSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateDailyKeywordSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ============================================================
  SELECT 
    `brand_id`,
    `brand_name`,
    `accouint_id`,
    `account_name`,
    `profile_id`,
    `profile_name`,
    DATE_FORMAT( date_key, "%b %d,%Y") AS date_key,
    `campaign_id`,
    `campaign_name`,
    `campaign_type`,
    `adGroupId`,
    `adGroupName`,
    `keywordId`,
    `keywordText`,
    `matchType`,
    `impressions`,
    `clicks`,
    `cost`,
    `revenue`,
    `order_conversion`,
    `acos`,
    `cpc`,
    `ctr`,
    `cpa`,
    `roas` 
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_keyword` 
 
WHERE `profile_id` = pro_id
       -- AND campaign_type = campaigntype 
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
       
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateWeeklyCampaignSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateWeeklyCampaignSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateWeeklyCampaignSchedulingReport`(  
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
  )
BEGIN
  
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `accouint_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
   year_,
   start_date,
   end_date,
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `campaign_budget`,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
   CASE WHEN revenue > 0 THEN  (cost/revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
FROM
(SELECT
	`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	campaign_name,
	`campaign_id`,
	`campaign_type`,
	YEAR(`date_key`) AS Year_,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y")
AS start_Date, 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y")
AS end_date,
	MAX(`campaign_budget`) AS campaign_budget,
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays MONTH)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	 DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y"), 
         DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y"),
	  YEAR(`date_key`),
	  `campaign_type`
	  
	  
	  )t;
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateWeeklyKeywordSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateWeeklyKeywordSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateWeeklyKeywordSchedulingReport`(  
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
  )
BEGIN
  
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `accouint_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
  start_date,
  end_Date,
   year_,
   
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
  `keywordId`,
  `keywordText`,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
   CASE WHEN revenue > 0 THEN  (cost/revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
FROM
(SELECT
	`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	campaign_name,
	`campaign_id`,
	`campaign_type`,
	`adGroupId`,
    `adGroupName`,
	`keywordId`,
	`keywordText`,
	YEAR(`date_key`) AS Year_,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y")
AS start_Date, 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y")
AS end_date,
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_keyword`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays MONTH)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y"), 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y"),
	  YEAR(`date_key`),
	  `campaign_type`,
	  `adGroupId`,
    `adGroupName`,
	    `keywordId`,
	    `keywordText`
	  
	  )t;
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateMonthlyCampaignSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateMonthlyCampaignSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateMonthlyCampaignSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `accouint_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
   year_,
   start_date,
   end_date,
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `campaign_budget`,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
   CASE WHEN revenue > 0 THEN  (cost/revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
FROM
(SELECT
	`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	campaign_name,
	`campaign_id`,
	`campaign_type`,
	YEAR(`date_key`) AS Year_,
  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") AS start_date, 
  DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") AS end_Date,
	MAX(`campaign_budget`) AS campaign_budget,
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays MONTH)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y"), 
          DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") ,
	  YEAR(`date_key`),
	  `campaign_type`
	  
	  
	  )t;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationTop20Keywords` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationTop20Keywords` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationTop20Keywords`(
  IN pro_id BIGINT,
  IN campaign_id BIGINT
)
BEGIN
  -- ===============================================================================================
  
  
SELECT 
  keywordText,
  revenue 
FROM
  (SELECT 
    keywordText,
    revenue,
    DENSE_RANK () OVER ( ORDER BY revenue DESC) `rank` 
  FROM
    (SELECT 
      keywordText,
      SUM(`revenue`) AS revenue 
    FROM
      `replica_adtec_bi`.`prst_tbl_ams_keyword` 
    WHERE profile_id = pro_id 
      AND campaign_id = campaign_id 
      AND DATE(`batchid`) >= LAST_DAY(CURRENT_DATE) + INTERVAL 1 DAY - INTERVAL 1 MONTH 
      AND DATE(`batchid`) < CURRENT_DATE 
    GROUP BY keywordText) t) g 
WHERE `rank` <= 20 ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAsinLevelShippedUnites` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAsinLevelShippedUnites` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAsinLevelShippedUnites`()
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
/* Delete same date data */
/* Insert difference in fact & stage date                                       */
INSERT INTO tbl_calculate_asins_level_shippedunits(
	shipped_units,
	asin,
	product_title,
	fullfillment_channel
	
)
SELECT 
	SUM(shipped_units) AS shipped_units, 
	ASIN, 
	product_title, 
	fullfillment_channel 
	FROM `prst_vew_product_table` 
	GROUP BY `ASIN`,
	product_title,
	fullfillment_channel;
  
/* end of script   */
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spCalculateAsinLevelShippedUnites',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spCalculateAsinLevelShippedUnites',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
     COMMIT ;
  END IF ;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateDailyAdGroupSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateDailyAdGroupSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateDailyAdGroupSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ============================================================
  SELECT 
    `brand_id`,
    `brand_name`,
    `accouint_id`,
    `account_name`,
    `profile_id`,
    `profile_name`,
    DATE_FORMAT( date_key, "%b %d,%Y") AS date_key, 
    `campaign_id`,
    `campaign_name`,
    `campaign_type`,
    `adGroupId`,
    `adGroupName`,
    `impressions`,
    `clicks`,
    `cost`,
    `revenue`,
    `order_conversion`,
    `acos`,
    `cpc`,
    `ctr`,
    `cpa`,
    `roas` 
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_adgroup`
 
WHERE `profile_id` = pro_id
       -- AND campaign_type = campaigntype 
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
       
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateMonthlyAdGroupSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateMonthlyAdGroupSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateMonthlyAdGroupSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ===============================================================================================
SELECT 
brand_id,
brand_name,
accouint_id,
account_name,
profile_id,
profile_name,
year_,
start_date,
end_Date,
campaign_id,
campaign_name,
campaign_type,
adGroupId,
adGroupName,
impressions,
clicks,
cost,
revenue,
order_conversion,
CASE WHEN revenue>0 THEN (cost/revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks>0 THEN (cost/clicks) ELSE 0.00 END AS CPC,
CASE WHEN impressions>0 THEN (clicks/impressions) ELSE 0.00 END AS CTR,
CASE WHEN order_conversion>0 THEN (cost/order_conversion) ELSE 0.00 END AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
FROM
(
SELECT
brand_id,
brand_name,
accouint_id,
account_name,
profile_id,
profile_name,
campaign_name,
`campaign_id`,
campaign_type,
adGroupId,
adGroupName,
YEAR(`date_key`) AS Year_,
  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") AS start_date, 
  DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") AS end_Date,
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_adgroup`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays MONTH)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") , 
          DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") ,
	  YEAR(`date_key`),
	  `campaign_type`,
	  `adGroupId`,
	  `adGroupName`
	  
	  )t;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateWeeklyAdGroupSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateWeeklyAdGroupSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateWeeklyAdGroupSchedulingReport`(  
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
  )
BEGIN
  
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `accouint_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
  start_date,
  end_Date,
   year_,
   
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
   CASE WHEN revenue > 0 THEN  (cost/revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
FROM
(SELECT
	`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	campaign_name,
	`campaign_id`,
	`campaign_type`,
	`adGroupId`,
    `adGroupName`,
	YEAR(`date_key`) AS Year_,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y")
AS start_Date, 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y")
AS end_date,
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_adgroup`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays MONTH)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y"), 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y"),
	  YEAR(`date_key`),
	  `campaign_type`,
	  `adGroupId`,
    `adGroupName`
	  )t;
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateCampaignTrendsVisual` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateCampaignTrendsVisual` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateCampaignTrendsVisual`(IN startdate DATE
,IN enddate DATE
,IN pro_id BIGINT
,IN campaignid BIGINT
,IN acc_id varchar(20)
,IN camp_type varchar(20))
BEGIN
SELECT
   DATE_FORMAT(`date_key`,"%Y-%m-%d") AS date_key
 , `account_id`
 , `campaign_type`
 , `impressions`
 , `clicks`
 , `cost`
 , `acos`
 , `revenue`
 , `CTR`
 , `order_conversion`
 , `order_conversion`/`clicks` AS conversion_rate
FROM
   `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE
   profile_id      = pro_id
   AND campaign_id = campaignid
   AND batchid    >= startdate
   AND batchid    <= enddate
   AND FIND_IN_SET(account_id,acc_id)
   AND FIND_IN_SET(campaign_type,camp_type)
;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAdgroupPresentationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAdgroupPresentationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAdgroupPresentationTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO `prst_tbl_ams_adgroup`
SELECT
  ee.`Client_ID`,
  ee.`Client_Name`,
  dd.`Account_ID`,
  dd.`Account_Name`,
  pp.profile_id,
  pp.profile_Name,
  
  `date_key`,
   bb.campaign_id,
   bb.`campaign_name`,
   cc.`camp_type`,
     
   bb.adgroup_id,
   bb.adgroup_name,
  
   
 
  
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
 
CASE WHEN revenue > 0 THEN  ROUND((Cost/Revenue),2) ELSE 0 END AS acos_,
CASE WHEN clicks > 0 THEN   ROUND((Cost/ clicks),2) ELSE 0 END AS CPC,
CASE WHEN `impressions` > 0 THEN  ROUND((Clicks/`impressions`),2) ELSE 0 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN ROUND((Cost/`order_conversion`),2) ELSE 0 END 	AS CPA,
CASE WHEN Cost > 0 THEN   ROUND((Revenue/Cost),2) ELSE 0 END  AS ROAS ,
aa.batchid,
aa.capture_date,
CURRENT_DATE AS loaddate  
FROM `replica_adtec_bi`.`fact_ams_adgroup`  aa
LEFT JOIN `replica_adtec_bi`.`dim_adgroup`         bb  ON (aa.`adgroup_key` = bb.`adgroup_key`)
LEFT JOIN `replica_adtec_bi`.`map_ams_profile`      pp  ON (pp.`profile_key` = bb.profile_key)
LEFT JOIN `replica_adtec_bi`.`map_ams_report_type`  cc  ON (bb.`camp_type_key` = cc.`camp_type_key`)
LEFT JOIN `replica_adtec_bi`.`dim_account`          dd  ON (dd.`Account_Key` = aa.`account_key` AND dd.flag = 1)
LEFT JOIN `replica_adtec_bi`.`dim_brand`            ee  ON (ee.`Client_Key` = aa.`client_key`)
WHERE aa.batchid = max_date;  
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAdgroupPresentationTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAdgroupPresentationTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelKeywordValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelKeywordValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelKeywordValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
    
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
INSERT INTO vald_ams_date_keyword
   ( fact_impressions
    , stage_impressions
    , diff_impressions
    , fact_clicks
    , stage_clicks
    , diff_clicks
    , fact_cost
    , stage_cost
    , diff_cost
    , fact_order_conversion
    , stage_order_conversion
    , diff_order_conversion
    , fact_revenue
    , stage_revenue
    , diff_revenue
    , batchid
   )
SELECT
   a.impressions
 , b.impressions
 , a.impressions - b.impressions
 , a.clicks
 , b.clicks
 , a.clicks - b.clicks
 , a.cost
 , b.cost
 , a.cost - b.cost
 , a.order_conversion
 , b.attributedunitsordered
 , a.order_conversion - b.attributedunitsordered
 , a.revenue
 , b.attributedsales
 , a.revenue - b.attributedsales
 , b.fk_batch_id
FROM
   (
      SELECT
         SUM(impressions)      AS impressions
       , SUM(clicks)           AS clicks
       , SUM(cost)             AS cost
       , SUM(order_conversion) AS order_conversion
       , SUM(revenue)          AS revenue
       , batchid
      FROM
         `fact_ams_keyword` aa
      WHERE
         batchid = max_date
      GROUP BY
         batchid
   )
   a
   INNER JOIN
      (
         SELECT
            SUM(impressions)            AS impressions
          , SUM(clicks)                 AS clicks
          , SUM(cost)                   AS cost
          , SUM(attributedunitsordered) AS attributedunitsordered
          , SUM(attributedsales)        AS attributedsales
          , reportDate                  as fk_batch_id
         FROM
            `stage_keyword`
         GROUP BY
            reportDate
      )
      b
      ON
         (
            a.batchid = b.fk_batch_id
         )
;  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelKeywordValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelKeywordValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelAdGroupValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelAdGroupValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelAdGroupValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
INSERT INTO vald_ams_acc_adgroup
   ( account_id
    , fact_impressions
    , stage_impressions
    , diff_impressions
    , fact_clicks
    , stage_clicks
    , diff_clicks
    , fact_cost
    , stage_cost
    , diff_cost
    , fact_order_conversion
    , stage_order_conversion
    , diff_order_conversion
    , fact_revenue
    , stage_revenue
    , diff_revenue
    , batchid
   )
SELECT
   a.Account_ID
 , a.impressions
 , b.impressions
 , a.impressions - b.impressions
 , a.clicks
 , b.clicks
 , a.clicks - b.clicks
 , a.cost
 , b.cost
 , a.cost - b.cost
 , a.order_conversion
 , b.attributedunitsordered
 , a.order_conversion - b.attributedunitsordered
 , a.revenue
 , b.attributedsales
 , a.revenue - b.attributedsales
 , a.batchid
FROM
   (
      SELECT
         bb.`Account_ID`
       , SUM(impressions)      AS impressions
       , SUM(clicks)           AS clicks
       , SUM(cost)             AS cost
       , SUM(order_conversion) AS order_conversion
       , SUM(revenue)          AS revenue
       , batchid
      FROM
         `fact_ams_adgroup` aa
         LEFT JOIN
            `dim_account` bb
            ON
               (
                  aa.`account_key` = bb.`Account_Key`
               )
      WHERE
         batchid = max_date
      GROUP BY
         bb.`Account_ID`
       , batchid
   )
   a
   INNER JOIN
      (
         SELECT
            fk_account_id               AS Account_ID
          , SUM(impressions)            AS impressions
          , SUM(clicks)                 AS clicks
          , SUM(cost)                   AS cost
          , SUM(unit_ordered)           AS attributedunitsordered
          , SUM(sales)                  AS attributedsales
          , report_date                  AS fk_batch_id
         FROM
            `stage_adgroup`
         GROUP BY
            fk_account_id
          , report_date
      )
      b
      ON
         (
            a.batchid        = b.fk_batch_id
            AND a.Account_ID = b.Account_ID
         )
;  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateAccountLevelAdGroupValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateAccountLevelAdGroupValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelCampaignValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelCampaignValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelCampaignValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
/* Insert difference in fact & stage date                                       */
INSERT INTO vald_ams_acc_campaign 
(
   account_id
  ,fact_impressions
  ,stage_impressions
  ,diff_impressions
  ,fact_clicks
  ,stage_clicks
  ,diff_clicks
  ,fact_cost
  ,stage_cost
  ,diff_cost
  ,fact_camp_budget
  ,stage_camp_budget
  ,diff_camp_budget
  ,fact_order_conversion
  ,stage_order_conversion
  ,diff_order_conversion
  ,fact_revenue
  ,stage_revenue
  ,diff_revenue
  ,batchid
 
  )
  
  
  
SELECT
    a.Account_ID
  , a.impressions
  , b.impressions
  , a.impressions - b.impressions
  , a.clicks
  , b.clicks
  , a.clicks - b.clicks
  , a.cost
  , b.cost
  , a.cost - b.cost
  , a.campaign_budget
  , b.campaign_budget
  , a.campaign_budget - b.campaign_budget
  , a.order_conversion
  , b.attributedunitsordered
  , a.order_conversion - b.attributedunitsordered
  , a.revenue
  , b.attributedsales
  , a.revenue - b.attributedsales
  , b.fk_batch_id
FROM
	(
		SELECT
			bb.`Account_ID`
		  , SUM(impressions)      AS impressions
		  , SUM(clicks)           AS clicks
		  , SUM(cost)             AS cost
		  , SUM(campaign_budget)  AS campaign_budget
		  , SUM(order_conversion) AS order_conversion
		  , SUM(revenue)          AS revenue
		  , batchid
		FROM
			`fact_ams_campaign` aa
			LEFT JOIN
				`dim_account` bb
				ON
					(
						aa.`account_key` = bb.`Account_Key`
					)
		WHERE
			batchid = max_date
		GROUP BY
			bb.`Account_ID`
		  , batchid
	)
	a
	INNER JOIN
		(
			SELECT
				fk_account_id                    AS Account_ID
			  , SUM(impressions)                 AS impressions
			  , SUM(clicks)                      AS clicks
			  , SUM(cost)                        AS cost
			  , SUM(campaign_budget)             AS campaign_budget
			  , SUM(attributedunitsordered) AS attributedunitsordered
			  , SUM(attributedsales)         AS attributedsales
			  , left(fk_batch_id,8) as fk_batch_id
			FROM
				`stage_campaign`
			GROUP BY
				fk_account_id
			  , LEFT(fk_batch_id,8)
		)b  ON    (a.batchid    = b.fk_batch_id AND a.Account_ID = b.Account_ID )
		
		;  
/* end of script   */
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAccountLevelCampaignValidationTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAccountLevelCampaignValidationTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
     COMMIT ;
  END IF ;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelKeywordValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelKeywordValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelKeywordValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
INSERT INTO vald_ams_acc_keyword
   ( account_id
    , fact_impressions
    , stage_impressions
    , diff_impressions
    , fact_clicks
    , stage_clicks
    , diff_clicks
    , fact_cost
    , stage_cost
    , diff_cost
    , fact_order_conversion
    , stage_order_conversion
    , diff_order_conversion
    , fact_revenue
    , stage_revenue
    , diff_revenue
    , batchid
   )
SELECT
   a.Account_ID
 , a.impressions
 , b.impressions
 , a.impressions - b.impressions
 , a.clicks
 , b.clicks
 , a.clicks - b.clicks
 , a.cost
 , b.cost
 , a.cost - b.cost
 , a.order_conversion
 , b.attributedunitsordered
 , a.order_conversion - b.attributedunitsordered
 , a.revenue
 , b.attributedsales
 , a.revenue - b.attributedsales
 , b.fk_batch_id
FROM
   (
      SELECT
         bb.`Account_ID`
       , SUM(impressions)      AS impressions
       , SUM(clicks)           AS clicks
       , SUM(cost)             AS cost
       , SUM(order_conversion) AS order_conversion
       , SUM(revenue)          AS revenue
       , batchid
      FROM
         `fact_ams_keyword` aa
         LEFT JOIN
            `dim_account` bb
            ON
               (
                  aa.`account_key` = bb.`Account_Key`
               )
      WHERE
         batchid = max_date
      GROUP BY
         bb.`Account_ID`
       , batchid
   )
   a
   INNER JOIN
      (
         SELECT
            fkAccountId               AS Account_ID
          , SUM(impressions)            AS impressions
          , SUM(clicks)                 AS clicks
          , SUM(cost)                   AS cost
          , SUM(attributedunitsordered) AS attributedunitsordered
          , SUM(attributedsales)        AS attributedsales
          , reportDate        AS fk_batch_id
         FROM
            `stage_keyword`
         GROUP BY
            fkAccountId
          , reportDate
      )
      b
      ON
         (
            a.batchid        = b.fk_batch_id
            AND a.Account_ID = b.Account_ID
         )
;  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateAccountLevelKeywordValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateAccountLevelKeywordValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelAdGroupValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelAdGroupValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelAdGroupValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
    
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
INSERT INTO vald_ams_date_adgroup
   ( fact_impressions
    , stage_impressions
    , diff_impressions
    , fact_clicks
    , stage_clicks
    , diff_clicks
    , fact_cost
    , stage_cost
    , diff_cost
    , fact_order_conversion
    , stage_order_conversion
    , diff_order_conversion
    , fact_revenue
    , stage_revenue
    , diff_revenue
    , batchid
   )
SELECT
   a.impressions
 , b.impressions
 , a.impressions - b.impressions
 , a.clicks
 , b.clicks
 , a.clicks - b.clicks
 , a.cost
 , b.cost
 , a.cost - b.cost
 , a.order_conversion
 , b.attributedunitsordered
 , a.order_conversion - b.attributedunitsordered
 , a.revenue
 , b.attributedsales
 , a.revenue - b.attributedsales
 , a.batchid
FROM
   (
      SELECT
         SUM(impressions)      AS impressions
       , SUM(clicks)           AS clicks
       , SUM(cost)             AS cost
       , SUM(order_conversion) AS order_conversion
       , SUM(revenue)          AS revenue
       , batchid
      FROM
         `fact_ams_adgroup` aa
      WHERE
         batchid = max_date
      GROUP BY
         batchid
   )
   a
   INNER JOIN
      (
         SELECT
            SUM(impressions)            AS impressions
          , SUM(clicks)                 AS clicks
          , SUM(cost)                   AS cost
          , SUM(unit_ordered) AS attributedunitsordered
          , SUM(sales)        AS attributedsales
          , report_date                  as fk_batch_id
         FROM
            `stage_adgroup`
         GROUP BY
            report_date
      )
      b
      ON
         (
            a.batchid = b.fk_batch_id
         )
;  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelAdGroupValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelAdGroupValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelCampaignValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelCampaignValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelCampaignValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
/* Insert difference in fact & stage date                                       */
INSERT INTO vald_ams_campaign(
	
	fact_impressions
	,stage_impressions
	,diff_impressions
	,fact_clicks
	,stage_clicks
	,diff_clicks
	,fact_cost
	,stage_cost
	,diff_cost
	,fact_camp_budget
	,stage_camp_budget
	,diff_camp_budget
	,fact_order_conversion
	,stage_order_conversion
	,diff_order_conversion
	,fact_revenue
	,stage_revenue
	,diff_revenue
	,batchid
	
)
(SELECT
   a.impressions
   ,b.impressions
   ,a.impressions - b.impressions
   ,a.clicks
   ,b.clicks   
   ,a.clicks - b.clicks
   ,a.cost
   ,b.cost   
   ,a.cost - b.cost
   ,a.campaign_budget
   ,b.campaign_budget   
   ,a.campaign_budget - b.campaign_budget
   ,a.order_conversion
   ,b.attributedunitsordered 
   ,a.order_conversion - b.attributedunitsordered
   ,a.revenue
   ,b.attributedsales  
   ,a.revenue - b.attributedsales
   ,b.fk_batch_id 
 
 FROM (SELECT 
	SUM(impressions) AS impressions
	,SUM(clicks) AS clicks
	,SUM(cost) AS cost
	,SUM(campaign_budget) AS campaign_budget
	,SUM(order_conversion) AS order_conversion
	,SUM(revenue)  AS revenue
	,batchid 
 FROM `fact_ams_campaign`  
 WHERE
    batchid  = max_date
 GROUP BY 
batchid   )a
 INNER JOIN 
 (SELECT 
	SUM(impressions) AS impressions
	,SUM(clicks) AS clicks
	,SUM(cost) AS cost
	,SUM(campaign_budget) AS campaign_budget
	,SUM(attributedunitsordered) AS attributedunitsordered
	,SUM(attributedsales) AS attributedsales
	,left(fk_batch_id,8) as fk_batch_id 
 FROM `stage_campaign` 
 GROUP BY 
LEFT(fk_batch_id,8) 
 )b
 ON  
 a.batchid  = b.fk_batch_id 
 
 
 
 );
  
/* end of script   */
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateDateLevelCampaignValidationTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateDateLevelCampaignValidationTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
     COMMIT ;
  END IF ;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAsinLevelDailyTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAsinLevelDailyTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAsinLevelDailyTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    /*	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;*/
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
		
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
	
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	
INSERT INTO replica_adtec_bi.prst_vew_product_table
SELECT
  aa.batchid AS DATE,
    bb.`Account_ID`,
    cc.`ASIN`,
    COALESCE (ff.`tag`, 'N/A') AS tag,
    COALESCE (cc.`category_id`,-1) AS category_id,
    COALESCE (cc.`category_name`, 'Other') AS category_name ,
    COALESCE (cc.`subcategory_id`,-1) AS subcategory_id,
    COALESCE (cc.`subcategory_name`, 'Other') AS subcategory_name,
     dd.`product_title`,
     ee.`fulfillment_channel`,
  
  SUM(aa.`shipped_cogs`) AS shipped_cogs,
  SUM(aa.`shipped_units`) AS shipped_units,
  SUM(aa.`shipped_cogs_last_year`) AS shipped_cogs_last_year,
  SUM(aa.`shipped_units_last_year`) AS shipped_units_last_year,
  ROUND(AVG(aa.`price`),2) AS price,
  ROUND(AVG(aa.`salesrank`),0) AS salesrank,
  
  aa.`batchid`,
  aa.`capture_date`,
  aa.`LoadDate`
  
FROM `replica_adtec_bi`.`fact_sales_master` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb ON (bb.`Account_Key` = aa.`Account_Key` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_product_master` ee ON (ee.`pm_key` = aa.`pm_key` )
LEFT JOIN replica_adtec_bi.`dim_product_category_master` cc ON (cc.`pm_cat_id` = aa.`pm_cat_id`  AND cc.`flag` = 1)
LEFT JOIN replica_adtec_bi.`stage_product_catalog` dd ON (cc.`fk_account_id` = dd.`fk_account_id` AND cc.`ASIN` = dd.`ASIN` AND ee.`fulfillment_channel` = dd.`fulfillment_channel`)
LEFT JOIN replica_adtec_bi.`stage_asin_tags` ff ON (cc.`fk_account_id` = ff.`fk_account_id` AND cc.`ASIN` = ff.`ASIN` AND ee.`fulfillment_channel` = ff.`fullFillmentChannel`)
 
 
 WHERE aa.batchid = `max_date`
GROUP BY 
  aa.batchid,
    bb.`Account_ID`,
   cc.`ASIN`,
   COALESCE (ff.`tag`, 'N/A'),
    dd.`product_title` ,
    ee.`fulfillment_channel`,
    COALESCE (cc.`category_id`,-1),
    COALESCE (cc.`category_name`, 'Other') ,
    COALESCE (cc.`subcategory_id`,-1),
    COALESCE (cc.`subcategory_name`, 'Other'),
  aa.`capture_date`,
  aa.`LoadDate`
;
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAsinLevelDailyTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAsinLevelDailyTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAsinLevelMonthlyTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAsinLevelMonthlyTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAsinLevelMonthlyTable`()
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	DECLARE EXIT HANDLER FOR SQLWARNING
	BEGIN
		-- WARNING
		SELECT "Warning by DB";
		SET `_rollback` = 1 ;
		ROLLBACK;
	END;
	
	START TRANSACTION;
  
	SET autocommit = 0;
INSERT INTO  replica_adtec_bi.prst_tbl_sales_asin_monthly
SELECT
 
  YEAR(batchid) AS year_,
  MONTH(batchid) AS Month_,
   `fk_account_id`,
  DATE_ADD(DATE_ADD(LAST_DAY(batchid),INTERVAL 1 DAY),INTERVAL -1 MONTH) AS FirstDayOfMonth, 
  LAST_DAY(batchid) AS lastDayOfMonth,
  
  `ASIN`,
  COALESCE (`category_id`,-1) AS category_id,
  COALESCE (`category_name`, 'Other') AS category_name ,
  COALESCE (`subcategory_id`,-1) AS subcategory_id,
  COALESCE (`subcategory_name`, 'Other') AS subcategory_name,
 
  
  
  SUM(`shipped_cogs`) AS shipped_cogs,
  SUM(`shipped_units`) AS shipped_units,
  SUM(`shipped_cogs_last_year`) AS shipped_cogs_last_year,
  SUM(`shipped_units_last_year`) AS shipped_units_last_year,
  ROUND(AVG(`price`),2) AS price,
  ROUND(AVG(`salesrank`),0) AS salesrank
  
  
  
FROM `replica_adtec_bi`. `prst_vew_product_table`  aa
WHERE salesrank != -1
GROUP BY 
  YEAR(batchid) ,
  MONTH(batchid),
  `fk_account_id`,
  DATE_ADD(DATE_ADD(LAST_DAY(batchid),INTERVAL 1 DAY),INTERVAL -1 MONTH), 
  LAST_DAY(batchid),
  `ASIN`,
  COALESCE (`category_id`,-1),
  COALESCE (`category_name`, 'Other') ,
  COALESCE (`subcategory_id`,-1),
  COALESCE (`subcategory_name`, 'Other')
 
  ORDER BY YEAR(batchid),MONTH(batchid) ;
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAsinLevelMonthlyTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAsinLevelMonthlyTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAsinLevelWeeklyTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAsinLevelWeeklyTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAsinLevelWeeklyTable`()
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	DECLARE EXIT HANDLER FOR SQLWARNING
	BEGIN
		-- WARNING
		SELECT "Warning by DB";
		SET `_rollback` = 1 ;
		ROLLBACK;
	END;
	
	START TRANSACTION;
  
	SET autocommit = 0;
INSERT INTO prst_tbl_sales_asin_weekly
SELECT
  
  YEAR(batchid) AS year_,
  WEEK(batchid, 0) AS week_,
   `fk_account_id`,
  
  
 
   CASE WHEN  WEEK(batchid, 0) = 0
  THEN '2020-01-01'
  ELSE 
  DATE_ADD( DATE_FORMAT(batchid, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(batchid, "%Y-%m-%d"))+1 DAY) END AS FirstDayOfWeek, 
    CASE WHEN  WEEK(batchid, 0) = 52
  THEN '2019-12-31'
  ELSE
  DATE_ADD(DATE_ADD( DATE_FORMAT(batchid, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(batchid, "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY) END AS LastDayOfWeek,
    
  
  `ASIN`,
  COALESCE (`category_id`,-1) AS category_id,
  COALESCE (`category_name`, 'Other') AS category_name ,
  COALESCE (`subcategory_id`,-1) AS subcategory_id,
  COALESCE (`subcategory_name`, 'Other') AS subcategory_name,
  
  
  SUM(`shipped_cogs`) AS shipped_cogs,
  SUM(`shipped_units`) AS shipped_units,
  SUM(`shipped_cogs_last_year`) AS shipped_cogs_last_year,
  SUM(`shipped_units_last_year`) AS shipped_units_last_year,
  ROUND(AVG(`price`),2) AS price,
  ROUND(AVG(`salesrank`),0) AS salesrank
  
  
  
FROM `replica_adtec_bi`. `prst_vew_product_table`  aa
WHERE salesrank != -1
GROUP BY 
 
  YEAR(batchid),
  WEEK(batchid, 0),
  `fk_account_id`,
  
 
   CASE WHEN  WEEK(batchid, 0) = 0
  THEN '2020-01-01'
  ELSE 
  DATE_ADD( DATE_FORMAT(batchid, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(batchid, "%Y-%m-%d"))+1 DAY) END , 
    CASE WHEN  WEEK(batchid, 0) = 52
  THEN '2019-12-31'
  ELSE
  DATE_ADD(DATE_ADD( DATE_FORMAT(batchid, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(batchid, "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY) END ,
    
  
  
  
  `ASIN`,
  COALESCE (`category_id`,-1),
  COALESCE (`category_name`, 'Other') ,
  COALESCE (`subcategory_id`,-1),
  COALESCE (`subcategory_name`, 'Other')
  
  
  ORDER BY YEAR(batchid),WEEK(batchid, 0);
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAsinLevelWeeklyTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAsinLevelWeeklyTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationDailyCompCardTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationDailyCompCardTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationDailyCompCardTable`(IN max_date VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;		
		ROLLBACK ;
	END;
		-- WARNING
  START TRANSACTION ;
	SET autocommit = 0;
	
	
INSERT INTO `replica_adtec_bi`.`prst_vew_daily_comp_cards`
   ( 
      `account_id`
    , `asin`
    , `category_id`
    , `subcategory_id`
    , daily_Pre_Paid
    , `daily_post_paid`
    , `record_date`
    , `creation_date`
   )
   (
      SELECT
        
         bb.`account_id`
       , bb.ASIN
       , bb.category_id
       , bb.subcategory_id
       , COALESCE(daily_Pre_Paid,-1) as daily_Pre_Paid
       , COALESCE(daily_Post_Paid,-1) AS daily_Post_Paid
       , max_date
       , NOW() AS creation_date
      FROM
         (
            SELECT
               1 AS pre_sr
             , fk_account_id as `account_id`
             , ASIN
             , category_id
             , subcategory_id
             , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Pre_Paid
            FROM
               `prst_vew_product_table`
            WHERE
               DATE_FORMAT(`DATE`, '%Y-%m-%d')     >= DATE_SUB(DATE_FORMAT( max_date,'%Y-%m-%d'), INTERVAL 5 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT( max_date, '%Y-%m-%d'), INTERVAL 1 DAY)
               AND
               (
                  YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                  OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
               )
               AND COALESCE(salesrank,-1) != -1
            GROUP BY
               ASIN
             , `account_id`
             , category_id
             , subcategory_id
         )
         aa
         right JOIN
            (
               SELECT
                  1 AS post_sr
                , ASIN
		, fk_account_id as `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Post_Paid
               FROM
                  `prst_vew_product_table`
               WHERE
                  DATE_FORMAT(`DATE`, '%Y-%m-%d')     >= DATE_SUB(DATE_FORMAT( max_date,'%Y-%m-%d'), INTERVAL 0 DAY)
                  AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT( max_date, '%Y-%m-%d'), INTERVAL -4 DAY)
                  AND
                  (
                     YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                     OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
                  )
                  AND COALESCE(salesrank,-1) != -1
               GROUP BY
                  ASIN
                , account_id
                , category_id
                , subcategory_id
            )
            bb
            ON
               (
                  aa.asin              =bb.asin
                  AND aa.account_id    =bb.account_id
                  AND aa.category_id   =bb.category_id
                  AND aa.subcategory_id=bb.subcategory_id
               )
   )
;
  
IF `_rollback` THEN
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulatePresentationDailyCompCardTable'
    ,'RollBack'
    , CURRENT_TIMESTAMP()
   )
;
ROLLBACK;
ELSE
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulatePresentationDailyCompCardTable'
    ,'Commit'
    , CURRENT_TIMESTAMP()
   )
;
COMMIT;
END
IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationMonthlyCompCardTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationMonthlyCompCardTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationMonthlyCompCardTable`(IN max_date VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
	DECLARE  start_date DATE; 
	DECLARE  end_date   DATE;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;		
		ROLLBACK ;
	END;
		-- WARNING
        SET start_date =  DATE_ADD( DATE_FORMAT(max_date , "%Y-%m-%d"), INTERVAL  -DAYOFmonth( DATE_FORMAT(max_date , "%Y-%m-%d"))+1 DAY);
        SET end_date   =  last_day(max_date);
  START TRANSACTION ;
	SET autocommit = 0;
	
	
    
INSERT INTO `replica_adtec_bi`.`prst_vew_monthly_comp_cards`
   ( 
     `account_id`
    , `asin`
    , `category_id`
    , `subcategory_id`
    , monthly_pre_paid
    , `monthly_post_paid`
    , `record_date`
    , `creation_date`
   )
     (
      SELECT
     
	 bb.`account_id`
       , bb.`ASIN`
       , bb.category_id
       , bb.subcategory_id
       , COALESCE(daily_Pre_Paid,-1) daily_Pre_Paid
       , COALESCE(daily_Post_Paid,-1) AS daily_Post_Paid
       , max_date AS record_date
       , NOW() AS creation_date
      FROM
         (
                  SELECT
                  1 AS pre_sr  
                , ASIN
		, `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(daily_Pre_Paid),0),-1) AS daily_Pre_Paid
                
                FROM
           (           
           
            SELECT
               1 AS pre_sr
              ,MONTH (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
             , fk_account_id AS `account_id`
             , ASIN
             , category_id
             , subcategory_id
             , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Pre_Paid
            FROM
               `prst_vew_product_table`
            WHERE
                DATE_FORMAT(`DATE`, '%Y-%m-%d')     >= DATE_SUB(DATE_FORMAT(start_date,'%Y-%m-%d'), INTERVAL 120 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT(start_date, '%Y-%m-%d'), INTERVAL 1 DAY)
               AND
               (
                  YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                  OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
               )
               AND COALESCE(salesrank,-1) != -1
            GROUP BY
               ASIN
             ,MONTH(DATE_FORMAT(`DATE`, '%Y-%m-%d'))
             , `account_id`
             , category_id
             , subcategory_id
             
             )t
             
               GROUP BY
               ASIN
            
             , `account_id`
             , category_id
             , subcategory_id
         )
         aa
         RIGHT JOIN
            (
                         
              SELECT
                  1 AS post_sr
                , ASIN
		, `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(daily_Post_Paid),0),-1) AS daily_Post_Paid
                
                FROM
           (
           SELECT
                  1 AS post_sr
                , MONTH (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
                , ASIN
		, fk_account_id AS `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Post_Paid
               FROM
                  `prst_vew_product_table`
               WHERE
                  DATE_FORMAT(`DATE`, '%Y-%m-%d')     >= DATE_SUB(DATE_FORMAT(start_date,'%Y-%m-%d'), INTERVAL 0 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT(start_date, '%Y-%m-%d'), INTERVAL -120 DAY)
                  AND
                  (
                     YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                     OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
                  )
                  AND COALESCE(salesrank,-1) != -1
                  
               GROUP BY
                  ASIN
                  ,MONTH (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
                , account_id
                , category_id
                , subcategory_id
                
                )t
                
                    GROUP BY
                  ASIN
             
                , account_id
                , category_id
                , subcategory_id            
            )
            bb
            ON
               (
                  aa.asin              =bb.asin
                  AND aa.account_id    =bb.account_id
                  AND aa.category_id   =bb.category_id
                  AND aa.subcategory_id=bb.subcategory_id
               )
   
   )
;
  
IF `_rollback` THEN
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulatePresentationMonthlyCompCardTable'
    ,'RollBack'
    , CURRENT_TIMESTAMP()
   )
;
ROLLBACK;
ELSE
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulatePresentationMonthlyCompCardTable'
    ,'Commit'
    , CURRENT_TIMESTAMP()
   )
;
COMMIT;
END
IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationWeeklyCompCardTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationWeeklyCompCardTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationWeeklyCompCardTable`(IN max_date VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
	
	DECLARE  start_date DATE; 
	DECLARE  end_date   DATE;
		-- WARNING
        SET start_date =  DATE_ADD( DATE_FORMAT(max_date , "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(max_date , "%Y-%m-%d"))+1 DAY);
        SET end_date   =  DATE_ADD(DATE_ADD( DATE_FORMAT(max_date, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(max_date, "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY);
  START TRANSACTION ;
	SET autocommit = 0;
	
	
    
INSERT INTO `replica_adtec_bi`.`prst_vew_weekly_comp_cards`
   ( 
     `account_id`
    , `asin`
    , `category_id`
    , `subcategory_id`
    ,  weekly_pre_paid
    , `weekly_post_paid`
    , `record_date`
    , `creation_date`
   )
   (
      SELECT
     
	 bb.`account_id`
       , bb.`ASIN`
       , bb.category_id
       , bb.subcategory_id
       , COALESCE(daily_Pre_Paid,-1) daily_Pre_Paid
       , COALESCE(daily_Post_Paid,-1) AS daily_Post_Paid
       , max_date AS record_date
       , NOW() AS creation_date
      FROM
         (
                  SELECT
                  1 AS pre_sr  
                , ASIN
		, `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(daily_Pre_Paid),0),-1) AS daily_Pre_Paid
                
                FROM
           (           
           
            SELECT
               1 AS pre_sr
              , WEEK (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
             , fk_account_id AS `account_id`
             , ASIN
             , category_id
             , subcategory_id
             , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Pre_Paid
            FROM
               `prst_vew_product_table`
            WHERE
               DATE_FORMAT(`DATE`, '%Y-%m-%d')     > DATE_SUB(DATE_FORMAT(start_date,'%Y-%m-%d'), INTERVAL 36 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT(start_date, '%Y-%m-%d'), INTERVAL 1 DAY)
               AND
               (
                  YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                  OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
               )
               AND COALESCE(salesrank,-1) != -1
            GROUP BY
               ASIN
             , WEEK (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
             , `account_id`
             , category_id
             , subcategory_id
             
             )t
             
               GROUP BY
               ASIN
            
             , `account_id`
             , category_id
             , subcategory_id
         )
         aa
         RIGHT JOIN
            (
                         
              SELECT
                  1 AS post_sr
                , ASIN
		, `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(daily_Post_Paid),0),-1) AS daily_Post_Paid
                
                FROM
           (
           SELECT
                  1 AS post_sr
                , WEEK (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
                , ASIN
		, fk_account_id AS `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Post_Paid
               FROM
                  `prst_vew_product_table`
               WHERE
                   DATE_FORMAT(`DATE`, '%Y-%m-%d')     > DATE_SUB(DATE_FORMAT(start_date,'%Y-%m-%d'), INTERVAL 1 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d')     <= DATE_SUB(DATE_FORMAT(start_date, '%Y-%m-%d'), INTERVAL -34 DAY)
                  AND
                  (
                     YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                     OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
                  )
                  AND COALESCE(salesrank,-1) != -1
                  
               GROUP BY
                  ASIN
                  ,WEEK (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
                , account_id
                , category_id
                , subcategory_id
                
                )t
                
                    GROUP BY
                  ASIN
             
                , account_id
                , category_id
                , subcategory_id            
            )
            bb
            ON
               (
                  aa.asin              =bb.asin
                  AND aa.account_id    =bb.account_id
                  AND aa.category_id   =bb.category_id
                  AND aa.subcategory_id=bb.subcategory_id
               )
   
   )
;
  
IF `_rollback` THEN
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulatePresentationWeeklyCompCardTable'
    ,'RollBack'
    , CURRENT_TIMESTAMP()
   )
;
ROLLBACK;
ELSE
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulatePresentationWeeklyCompCardTable'
    ,'Commit'
    , CURRENT_TIMESTAMP()
   )
;
COMMIT;
END
IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelProductValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelProductValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelProductValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
DELETE FROM vald_ams_acc_product WHERE  batchid = max_date;
INSERT INTO vald_ams_acc_product
   ( account_id
    , fact_impressions
    , stage_impressions
    , diff_impressions
    , fact_clicks
    , stage_clicks
    , diff_clicks
    , fact_cost
    , stage_cost
    , diff_cost
    , fact_order_conversion
    , stage_order_conversion
    , diff_order_conversion
    , fact_revenue
    , stage_revenue
    , diff_revenue
    , batchid
   )
SELECT
   a.Account_ID
 , a.impressions
 , b.impressions
 , a.impressions - b.impressions
 , a.clicks
 , b.clicks
 , a.clicks - b.clicks
 , a.cost
 , b.cost
 , a.cost - b.cost
 , a.order_conversion
 , b.attributedunitsordered
 , a.order_conversion - b.attributedunitsordered
 , a.revenue
 , b.attributedsales
 , a.revenue - b.attributedsales
 , b.fk_batch_id
FROM
   (
      SELECT
         bb.`Account_ID`
       , SUM(impressions)      AS impressions
       , SUM(clicks)           AS clicks
       , SUM(cost)             AS cost
       , SUM(order_conversion) AS order_conversion
       , SUM(revenue)          AS revenue
       , batchid
      FROM
         `fact_ams_product` aa
         LEFT JOIN
            `dim_account` bb
            ON
               (
                  aa.`account_key` = bb.`Account_Key`
               )
      WHERE
         batchid = max_date
      GROUP BY
         bb.`Account_ID`
       , batchid
   )
   a
   INNER JOIN
      (
         SELECT
            fk_account_id               AS Account_ID
          , SUM(impressions)            AS impressions
          , SUM(clicks)                 AS clicks
          , SUM(cost)                   AS cost
          , SUM(`unit_ordered`) AS attributedunitsordered
          , SUM(`sales`)        AS attributedsales
          , report_date                 AS fk_batch_id
         FROM
            `stage_product_ads`
         GROUP BY
            fk_account_id
          , report_date
      )
      b
      ON
         (
            a.batchid        = b.fk_batch_id
            AND a.Account_ID = b.Account_ID
         )
;  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateAccountLevelProductValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateAccountLevelProductValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelProductValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelProductValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelProductValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
    
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
DELETE
FROM
   vald_ams_date_product
WHERE
   batchid = max_date
;
INSERT INTO vald_ams_date_product
   ( fact_impressions
    , stage_impressions
    , diff_impressions
    , fact_clicks
    , stage_clicks
    , diff_clicks
    , fact_cost
    , stage_cost
    , diff_cost
    , fact_order_conversion
    , stage_order_conversion
    , diff_order_conversion
    , fact_revenue
    , stage_revenue
    , diff_revenue
    , batchid
   )
SELECT
   a.impressions
 , b.impressions
 , a.impressions - b.impressions
 , a.clicks
 , b.clicks
 , a.clicks - b.clicks
 , a.cost
 , b.cost
 , a.cost - b.cost
 , a.order_conversion
 , b.attributedunitsordered
 , a.order_conversion - b.attributedunitsordered
 , a.revenue
 , b.attributedsales
 , a.revenue - b.attributedsales
 , a.batchid
FROM
   (
      SELECT
         SUM(impressions)      AS impressions
       , SUM(clicks)           AS clicks
       , SUM(cost)             AS cost
       , SUM(order_conversion) AS order_conversion
       , SUM(revenue)          AS revenue
       , batchid
      FROM
         `fact_ams_product` aa
      WHERE
         batchid = max_date
      GROUP BY
         batchid
   )
   a
   INNER JOIN
      (
         SELECT
            SUM(impressions)            AS impressions
          , SUM(clicks)                 AS clicks
          , SUM(cost)                   AS cost
          , SUM(unit_ordered) AS attributedunitsordered
          , SUM(sales)        AS attributedsales
          , report_date                  as fk_batch_id
         FROM
            `stage_product_ads`
         GROUP BY
            report_date
      )
      b
      ON
         (
            a.batchid = b.fk_batch_id
         )
;  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelProductValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelProductValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateMonthlyKeywordSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateMonthlyKeywordSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateMonthlyKeywordSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `accouint_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
   year_,
   start_date,
   end_Date,
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
  `keywordId`,
  `keywordText`,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
   CASE WHEN revenue > 0 THEN  (cost/revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
FROM
(SELECT
	`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	campaign_name,
	`campaign_id`,
	`campaign_type`,
	`adGroupId`,
    `adGroupName`,
	`keywordId`,
	`keywordText`,
	YEAR(`date_key`) AS Year_,
  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") AS start_date, 
  DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") AS end_Date,
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_keyword`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays MONTH)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `accouint_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") , 
          DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") ,
	  YEAR(`date_key`),
	  `campaign_type`,
	  `adGroupId`,
    `adGroupName`,
	    `keywordId`,
	    `keywordText`
	  
	  )t;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateMonthlyProductAdsSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateMonthlyProductAdsSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateMonthlyProductAdsSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `account_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
   year_,
   start_date,
   end_Date,
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
   `adGroupName`,
   `ad_id`,
   `asin` as asin_,
   sku,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
   CASE WHEN revenue > 0 THEN  (cost/revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
FROM
(SELECT
	`brand_id`,
	  `brand_name`,
	  `account_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	campaign_name,
	`campaign_id`,
	`campaign_type`,
	`adGroupId`,
    `adGroupName`,
    `ad_id`,
    `asin`,
    sku,
	YEAR(`date_key`) AS Year_,
  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") AS start_date, 
  DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") AS end_Date,
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_product`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays MONTH)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `account_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") , 
          DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") ,
	  YEAR(`date_key`),
	  `campaign_type`,
	  `adGroupId`,
    `adGroupName`,
	  `ad_id`,
	  `asin`,
	  sku
	  
	  )t;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateWeeklyProductAdsSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateWeeklyProductAdsSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateWeeklyProductAdsSchedulingReport`(  
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
  )
BEGIN
  
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `account_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
  start_date,
  end_Date,
   year_,
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
    `ad_id`,
    `asin` as asin_,
    `sku`,
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
   CASE WHEN revenue > 0 THEN  (cost/revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
FROM
(SELECT
	`brand_id`,
	  `brand_name`,
	  `account_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	campaign_name,
	`campaign_id`,
	`campaign_type`,
	`adGroupId`,
	`adGroupName`,
	`ad_id`,
	`asin`,
	`sku`,
	YEAR(`date_key`) AS Year_,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y")
AS start_Date, 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y")
AS end_date,
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_product`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays week)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `account_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y"), 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y"),
	  YEAR(`date_key`),
	 `campaign_type`,
	 `adGroupId`,
	`adGroupName`,
	`ad_id`,
	`asin`,
	`sku`
	  
	  )t;
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateDailyProductAdsSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateDailyProductAdsSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateDailyProductAdsSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ============================================================
SELECT 
brand_id , 
brand_name ,
account_id ,
account_name,
profile_id ,
profile_name ,
DATE_FORMAT( date_key, "%b %d,%Y") AS date_key,
campaign_id ,
campaign_name ,
campaign_type,
adGroupId ,
adGroupName,
ad_id,
ASIN as asin_,
`sku`,
impressions,
clicks,
cost,
revenue,
order_conversion,
`acos`,
cpc,
ctr,
cpa,
roas
FROM `prst_tbl_ams_product`
WHERE `profile_id` = pro_id
AND  FIND_IN_SET(campaign_type,campaigntype)
AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
       
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateDailyAsinsSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateDailyAsinsSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateDailyAsinsSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ============================================================
  SELECT 
    `brand_id`,
   `brand_name`,
    `account_id`,
    `account_name`,
   `profile_id`,
    `profile_name`,
    DATE_FORMAT( `date_key`, "%b %d,%Y") AS date_key, 
    `campaign_id`,
    `campaign_name`,
    `campaign_type`,
    `adGroupId`,
    `adGroupName`,
    `keywordId`,
    `keywordText`,
    `asin` AS asin_,
    `other_asin`,
   `sku`,
   `currency`,
    `match_type`,
    `attributedunitsordered`,
    `sales_other_sku`,
    `units_ordered_other_sku`
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_asins`
 
WHERE `profile_id` = pro_id
       -- AND campaign_type = campaigntype 
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays DAY)
       
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateWeeklyAsinsSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateWeeklyAsinsSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateWeeklyAsinsSchedulingReport`(  
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
  )
BEGIN
  
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `account_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
  start_date,
  end_Date,
   year_,
   
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
    `KeywordId`,
    `KeywordText`,  
  `asin` ,
    `other_asin`,
   `sku`,
   `currency`,
    `match_type`,
    `attributed_units_ordered`,
    `sales_other_sku`,
    `units_ordered_other_sku`
FROM
(SELECT
	
	`brand_id`,
  `brand_name`,
  `account_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
	YEAR(`date_key`) AS Year_,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y")
AS start_Date, 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y")
AS end_date,
`campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
    `KeywordId`,
    `KeywordText`,
    `asin` ,  
    `other_asin`,
   `sku`,
   `currency`,
    `match_type`,
   COALESCE(SUM(`attributedunitsordered`),0) AS `attributed_units_ordered`,
   COALESCE(SUM(`sales_other_sku`),0) AS `sales_other_sku`,
   COALESCE(SUM(`units_ordered_other_sku`),0) AS `units_ordered_other_sku`
FROM 
`replica_adtec_bi`.`prst_tbl_ams_asins`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaign_type)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays WEEK)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `account_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	DATE_FORMAT(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), "%b %d,%Y"), 
DATE_FORMAT(DATE_ADD(DATE_ADD( DATE_FORMAT(date_key, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(LEFT(date_key,8), "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY), "%b %d,%Y"),
	  YEAR(`date_key`),
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
    `KeywordId`,
    `KeywordText`,  
     `asin`,
    `other_asin`,
   `sku`,
   `currency`,
    `match_type`
	  )t;
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateMonthlyAsinsSchedulingReport` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateMonthlyAsinsSchedulingReport` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateMonthlyAsinsSchedulingReport`(
  IN pro_id BIGINT,
  IN campaigntype VARCHAR(50),
  IN numofdays INT
)
BEGIN
  -- ===============================================================================================
SELECT 
  `brand_id`,
  `brand_name`,
  `account_id`,
  `account_name`,
  `profile_id`,
  `profile_name`,
  start_date,
  end_Date,
   year_,
   
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
    `KeywordId`,
    `KeywordText`,  
  `asin` ,
    `other_asin`,
   `sku`,
   `currency`,
    `match_type`,
    `attributed_units_ordered`,
    `sales_other_sku`,
    `units_ordered_other_sku`
FROM
(SELECT
	`brand_id`,
	  `brand_name`,
	  `account_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	
		YEAR(`date_key`) AS Year_,
  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") AS start_date, 
  DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") AS end_Date,
  `campaign_id`,
  `campaign_name`,
  `campaign_type`,
  `adGroupId`,
    `adGroupName`,
    `KeywordId`,
    `KeywordText`,
    `asin` ,  
    `other_asin`,
   `sku`,
   `currency`,
    `match_type`,
   COALESCE(SUM(`attributedunitsordered`),0) AS `attributed_units_ordered`,
   COALESCE(SUM(`sales_other_sku`),0) AS `sales_other_sku`,
   COALESCE(SUM(`units_ordered_other_sku`),0) AS `units_ordered_other_sku`
   
FROM 
`replica_adtec_bi`.`prst_tbl_ams_asins`
WHERE `profile_id` = pro_id
      
       AND  FIND_IN_SET(campaign_type,campaigntype)
       AND batchid >=  DATE_SUB(CURRENT_DATE, INTERVAL numofdays MONTH)
       GROUP BY campaign_name,`campaign_id`,`brand_id`,
	  `brand_name`,
	  `account_id`,
	  `account_name`,
	  `profile_id`,
	  `profile_name`,
	  DATE_FORMAT(DATE_ADD(DATE_ADD(LAST_DAY(date_key),INTERVAL 1 DAY),INTERVAL -1 MONTH), "%b %d,%Y") , 
          DATE_FORMAT( LAST_DAY(date_key), "%b %d,%Y") ,
	  YEAR(`date_key`),
	    `campaign_type`,
  `adGroupId`,
    `adGroupName`,
    `KeywordId`,
    `KeywordText`,  
     `asin`,
    `other_asin`,
   `sku`,
   `currency`,
    `match_type`
	  
	  )t;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelASINValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelASINValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelASINValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
    
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
DELETE
FROM
   vald_ams_date_asin
WHERE
   batchid = max_date
;
INSERT INTO vald_ams_date_asin
   (    
   fact_unit_ordered              
  ,stage_unit_ordered             
  ,diff_unit_ordered              
  ,fact_sales_other_sku			  
  ,stage_sales_other_sku  		  
  ,diff_sales_other_sku			  
  ,fact_unit_ordered_other_sku    
  ,stage_unit_ordered_other_sku   
  ,diff_unit_ordered_other_sku    
  ,batchid		
   )
SELECT
   a.unit_ordered
 , b.unit_ordered
 , a.unit_ordered - b.unit_ordered
 , a.sales_other_sku
 , b.sales_other_sku
 , a.sales_other_sku - b.sales_other_sku
 , a.unit_ordered_other_sku
 , b.unit_ordered_other_sku
 , a.unit_ordered_other_sku - b.unit_ordered_other_sku
 , a.batchid
FROM
   (
      SELECT
         SUM(`attributedunitsordered`)              AS unit_ordered
       , SUM(`sales_other_sku`)                     AS sales_other_sku
       , SUM(`units_ordered_other_sku`)             AS unit_ordered_other_sku
       , batchid
      FROM
         `fact_ams_asins` aa
      WHERE
         batchid = max_date
      GROUP BY
         batchid
   )
   a
   INNER JOIN
      (
         SELECT
            SUM(`attributedUnitsOrdered`)                    AS unit_ordered
          , SUM(`sales_other_sku`)                           AS sales_other_sku
          , SUM(`units_ordered_other_sku`)                   AS unit_ordered_other_sku
          , reportDate                                       AS fk_batch_id
         FROM
            `stage_ams_asin`
         GROUP BY
            reportDate
      )
      b
      ON
         (
            a.batchid = b.fk_batch_id
         )
;  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelASINValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelASINValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spUpdateDimAsins` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUpdateDimAsins` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUpdateDimAsins`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
UPDATE 
   `replica_adtec_bi`.`dim_asins` AS l 
  INNER JOIN `map_ams_report_type` AS m 
    ON (
      l.`camp_type_key` = m.`camp_type_key`
    ) 
  INNER JOIN `replica_adtec_bi`.`stage_ams_asin`  AS r 
    ON (
      
     l.`campaign_id` = r.`campaignId`
 AND l.`adgroup_id` = r.`adGroupId`
 AND l.`keyword_id` = r.`keywordId`
 AND l.`asin` = r.`asin`
 AND l.`other_asin` = r.`other_asin`
 AND l.`sku` = r.`sku`
 AND l.`currency` = r.`currency`
    ) 
    
    SET l.`match_type` = r.`matchType`,
        l.`Load_Date` = CURRENT_DATE
        
WHERE l.`match_type` != r.`matchType`
;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spUpdateDimAsins',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spUpdateDimAsins',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAsinsPresentationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAsinsPresentationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAsinsPresentationTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO `prst_tbl_ams_asins`
SELECT
  ee.`Client_ID`,
  ee.`Client_Name`,
  dd.`Account_ID`,
  dd.`Account_Name`,
  pp.profile_id,
  pp.profile_Name,
  
  `date_key`,
   bb.campaign_id,
   bb.`campaign_name`,
   cc.`camp_type`,
     
   bb.adgroup_id,
   bb.adgroup_name,
   bb.keyword_id,
   bb.keyword_name,
   bb.asin,
   bb.other_asin,
   bb.sku,
   bb.currency,
   bb.match_type,
  `attributedunitsordered`,
  `sales_other_sku`,
  `units_ordered_other_sku`,
   aa.batchid,
   aa.capture_date,
   CURRENT_DATE AS loaddate  
FROM `replica_adtec_bi`.`fact_ams_asins`  aa
LEFT JOIN `replica_adtec_bi`.`dim_asins`            bb  ON (aa.`asins_key` = bb.`asins_key`)
LEFT JOIN `replica_adtec_bi`.`map_ams_profile`      pp  ON (pp.`profile_key` = bb.profile_key)
LEFT JOIN `replica_adtec_bi`.`map_ams_report_type`  cc  ON (bb.`camp_type_key` = cc.`camp_type_key`)
LEFT JOIN `replica_adtec_bi`.`dim_account`          dd  ON (dd.`Account_Key` = aa.`account_key` AND dd.flag = 1)
LEFT JOIN `replica_adtec_bi`.`dim_brand`            ee  ON (ee.`Client_Key` = aa.`client_key`)
WHERE aa.batchid = max_date;
  
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAsinsPresentationTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAsinsPresentationTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spShowPresentationDailyCompCardTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spShowPresentationDailyCompCardTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spShowPresentationDailyCompCardTable`(IN `asin_`  VARCHAR(20)
,IN cat_id BIGINT
,IN sub_cat_id BIGINT
,IN max_date VARCHAR(20)
,in acc_id varchar(1000))
BEGIN
  SELECT
        
         bb.`account_id`
       , bb.ASIN
       , bb.category_id
       , bb.subcategory_id
       , COALESCE(daily_Pre_Paid,-1) AS pre
       , COALESCE(daily_Post_Paid,-1) AS post
       , max_date
       , NOW() AS creation_date
      FROM
         (
            SELECT
               1 AS pre_sr
             , fk_account_id AS `account_id`
             , ASIN
             , category_id
             , subcategory_id
             , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Pre_Paid
            FROM
               `prst_vew_product_table`
            WHERE
               DATE_FORMAT(`DATE`, '%Y-%m-%d')     >= DATE_SUB(DATE_FORMAT( max_date,'%Y-%m-%d'), INTERVAL 5 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT( max_date, '%Y-%m-%d'), INTERVAL 1 DAY)
               AND
               (
                  YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                  OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
               )
               AND COALESCE(salesrank,-1) != -1
               AND  ASIN =`asin_`
	       AND `category_id`   =cat_id
               AND `subcategory_id`=sub_cat_id
               AND FIND_IN_SET(fk_account_id ,acc_id)
               
            GROUP BY
               ASIN
             , `account_id`
             , category_id
             , subcategory_id
         )
         aa
         RIGHT JOIN
            (
               SELECT
                  1 AS post_sr
                , ASIN
		, fk_account_id AS `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Post_Paid
               FROM
                  `prst_vew_product_table`
               WHERE
                  DATE_FORMAT(`DATE`, '%Y-%m-%d')     >= DATE_SUB(DATE_FORMAT( max_date,'%Y-%m-%d'), INTERVAL 0 DAY)
                  AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT( max_date, '%Y-%m-%d'), INTERVAL -4 DAY)
                  AND
                  (
                     YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                     OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
                  )
                  AND COALESCE(salesrank,-1) != -1
                  AND  ASIN =`asin_`
	          AND `category_id`   =cat_id
                  AND `subcategory_id`=sub_cat_id
                  AND FIND_IN_SET(fk_account_id ,acc_id)
               
               GROUP BY
                  ASIN
                , account_id
                , category_id
                , subcategory_id
            )
            bb
            ON
               (
                  aa.asin              =bb.asin
                  AND aa.account_id    =bb.account_id
                  AND aa.category_id   =bb.category_id
                  AND aa.subcategory_id=bb.subcategory_id
               )
   
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spShowPresentationMonthlyCompCardTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spShowPresentationMonthlyCompCardTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spShowPresentationMonthlyCompCardTable`(IN `asin_`  VARCHAR(20)
,IN cat_id BIGINT
,IN sub_cat_id BIGINT
,IN max_date VARCHAR(20)
,IN acc_id VARCHAR(1000))
BEGIN
        DECLARE  start_date DATE; 
	DECLARE  end_date   DATE;
        SET start_date =  DATE_ADD( DATE_FORMAT(max_date , "%Y-%m-%d"), INTERVAL  -DAYOFMONTH( DATE_FORMAT(max_date , "%Y-%m-%d"))+1 DAY);
        SET end_date   =  LAST_DAY(max_date);
 
      SELECT
     
	 bb.`account_id`
       , bb.`ASIN`
       , bb.category_id
       , bb.subcategory_id
       , COALESCE(daily_Pre_Paid,-1) as pre
       , COALESCE(daily_Post_Paid,-1) AS post
       , max_date AS record_date
       , NOW() AS creation_date
      FROM
         (
                  SELECT
                  1 AS pre_sr  
                , ASIN
		, `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(daily_Pre_Paid),0),-1) AS daily_Pre_Paid
                
                FROM
           (           
           
            SELECT
               1 AS pre_sr
              ,MONTH (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
             , fk_account_id AS `account_id`
             , ASIN
             , category_id
             , subcategory_id
             , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Pre_Paid
            FROM
               `prst_vew_product_table`
            WHERE
                DATE_FORMAT(`DATE`, '%Y-%m-%d')     >= DATE_SUB(DATE_FORMAT(start_date,'%Y-%m-%d'), INTERVAL 120 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT(start_date, '%Y-%m-%d'), INTERVAL 1 DAY)
               AND
               (
                  YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                  OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
               )
               AND COALESCE(salesrank,-1) != -1
               AND ASIN =`asin_`
               AND `category_id`    = cat_id
               AND `subcategory_id` = sub_cat_id
               AND FIND_IN_SET(fk_account_id,acc_id)
            GROUP BY
               ASIN
             ,MONTH(DATE_FORMAT(`DATE`, '%Y-%m-%d'))
             , `account_id`
             , category_id
             , subcategory_id
             
             )t
             
               GROUP BY
               ASIN
            
             , `account_id`
             , category_id
             , subcategory_id
         )
         aa
         RIGHT JOIN
            (
                         
              SELECT
                  1 AS post_sr
                , ASIN
		, `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(daily_Post_Paid),0),-1) AS daily_Post_Paid
                
                FROM
           (
           SELECT
                  1 AS post_sr
                , MONTH (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
                , ASIN
		, fk_account_id AS `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Post_Paid
               FROM
                  `prst_vew_product_table`
               WHERE
                  DATE_FORMAT(`DATE`, '%Y-%m-%d')     >= DATE_SUB(DATE_FORMAT(start_date,'%Y-%m-%d'), INTERVAL 0 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT(start_date, '%Y-%m-%d'), INTERVAL -120 DAY)
                  AND
                  (
                     YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                     OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
                  )
                  AND COALESCE(salesrank,-1) != -1
                  AND ASIN =`asin_`
                  AND `category_id`    = cat_id
                  AND `subcategory_id` = sub_cat_id
                  AND FIND_IN_SET(fk_account_id,acc_id)
                  
               GROUP BY
                  ASIN
                  ,MONTH (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
                , account_id
                , category_id
                , subcategory_id
                
                )t
                
                    GROUP BY
                  ASIN
             
                , account_id
                , category_id
                , subcategory_id            
            )
            bb
            ON
               (
                  aa.asin              =bb.asin
                  AND aa.account_id    =bb.account_id
                  AND aa.category_id   =bb.category_id
                  AND aa.subcategory_id=bb.subcategory_id
               )
   
   
   
   
   
   
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spShowPresentationWeeklyCompCardTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spShowPresentationWeeklyCompCardTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spShowPresentationWeeklyCompCardTable`(IN `asin_`  VARCHAR(20)
,IN cat_id BIGINT
,IN sub_cat_id BIGINT
,IN max_date VARCHAR(20)
,IN acc_id VARCHAR(1000))
BEGIN
        DECLARE  start_date DATE; 
	DECLARE  end_date   DATE;
		-- WARNING
        SET start_date =  DATE_ADD( DATE_FORMAT(max_date , "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(max_date , "%Y-%m-%d"))+1 DAY);
        SET end_date   =  DATE_ADD(DATE_ADD( DATE_FORMAT(max_date, "%Y-%m-%d"), INTERVAL  -DAYOFWEEK( DATE_FORMAT(max_date, "%Y-%m-%d"))+1 DAY), INTERVAL 6 DAY);
	
      SELECT
     
	 bb.`account_id`
       , bb.`ASIN`
       , bb.category_id
       , bb.subcategory_id
       , COALESCE(daily_Pre_Paid,-1) as pre
       , COALESCE(daily_Post_Paid,-1) AS post
       , max_date AS record_date
       , NOW() AS creation_date
      FROM
         (
                SELECT
                  1 AS pre_sr  
                , ASIN
		, `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(daily_Pre_Paid),0),-1) AS daily_Pre_Paid
                
                FROM
           (           
           
            SELECT
               1 AS pre_sr
              , WEEK (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
             , fk_account_id AS `account_id`
             , ASIN
             , category_id
             , subcategory_id
             , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Pre_Paid
            FROM
               `prst_vew_product_table`
            WHERE
               DATE_FORMAT(`DATE`, '%Y-%m-%d')     > DATE_SUB(DATE_FORMAT(start_date,'%Y-%m-%d'), INTERVAL 36 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d') <= DATE_SUB(DATE_FORMAT(start_date, '%Y-%m-%d'), INTERVAL 1 DAY)
               AND
               (
                  YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                  OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
               )
               AND COALESCE(salesrank,-1) != -1
               AND ASIN =`asin_`
               AND `category_id`    = cat_id
               AND `subcategory_id` = sub_cat_id
               AND FIND_IN_SET(fk_account_id,acc_id)
            
            GROUP BY
               ASIN
             , WEEK (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
             , `account_id`
             , category_id
             , subcategory_id
             
             )t
             
               GROUP BY
               ASIN
            
             , `account_id`
             , category_id
             , subcategory_id
         )
         aa
         RIGHT JOIN
            (
                         
              SELECT
                  1 AS post_sr
                , ASIN
		, `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(daily_Post_Paid),0),-1) AS daily_Post_Paid
                
                FROM
           (
           SELECT
                  1 AS post_sr
                , WEEK (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
                , ASIN
		, fk_account_id AS `account_id`
                , category_id
                , subcategory_id
                , COALESCE(ROUND(AVG(salesrank),0),-1) AS daily_Post_Paid
               FROM
                  `prst_vew_product_table`
               WHERE
                   DATE_FORMAT(`DATE`, '%Y-%m-%d')     > DATE_SUB(DATE_FORMAT(start_date,'%Y-%m-%d'), INTERVAL 1 DAY)
               AND DATE_FORMAT(`DATE`, '%Y-%m-%d')     <= DATE_SUB(DATE_FORMAT(start_date, '%Y-%m-%d'), INTERVAL -34 DAY)
                  AND
                  (
                     YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d'))    = 2019
                     OR YEAR(DATE_FORMAT(`DATE`, '%Y-%m-%d')) = 2020
                  )
                  AND COALESCE(salesrank,-1) != -1
                  AND ASIN =`asin_`
                  AND `category_id`    = cat_id
                  AND `subcategory_id` = sub_cat_id
                  AND FIND_IN_SET(fk_account_id,acc_id)
                  
               GROUP BY
                  ASIN
                  ,WEEK (DATE_FORMAT(`DATE`, '%Y-%m-%d'))
                , account_id
                , category_id
                , subcategory_id
                
                )t
                
                    GROUP BY
                  ASIN
             
                , account_id
                , category_id
                , subcategory_id            
            )
            bb
            ON
               (
                  aa.asin              =bb.asin
                  AND aa.account_id    =bb.account_id
                  AND aa.category_id   =bb.category_id
                  AND aa.subcategory_id=bb.subcategory_id
               )
   
     
   
   
   
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spDataValidationLayerTruncate` */

/*!50003 DROP PROCEDURE IF EXISTS  `spDataValidationLayerTruncate` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spDataValidationLayerTruncate`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	START TRANSACTION;
	SET autocommit = 0;
DELETE FROM replica_adtec_bi.`vald_sales_date`                 WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_sales_account`              WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_inventory_date`             WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_inventory_account`          WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_inventory_date`             WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_campaign`               WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_acc_campaign`           WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_date_adgroup`           WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_acc_adgroup`            WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_date_keyword`           WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_acc_keyword`            WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_date_product`           WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_acc_product`            WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_date_asin`              WHERE batchid = `max_date` ;
DELETE FROM replica_adtec_bi.`vald_ams_acc_asin`               WHERE batchid = `max_date` ;
  
IF `_rollback` THEN
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spDataValidationLayerTruncate'
    ,'RollBack'
    , CURRENT_TIMESTAMP()
   )
;
ROLLBACK;
ELSE
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spDataValidationLayerTruncate'
    ,'Commit'
    , CURRENT_TIMESTAMP()
   )
;
COMMIT;
END
IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPerformancePre30DayGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPerformancePre30DayGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPerformancePre30DayGrandTotal`(IN pro_id BIGINT)
BEGIN
SELECT 
"Grand total" as grand_total,
COALESCE(ROUND(cost,2),0.00)  AS cost,
COALESCE(ROUND(revenue,2),0.00) AS revenue,
COALESCE(ROUND(acos_,2),0.00) AS acos_
  FROM `replica_adtec_bi`.`prst_vew_performance_pre30dayTable_grand_total`
  WHERE profile_id = pro_id  ;    
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spViewYTDGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spViewYTDGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spViewYTDGrandTotal`(IN pro_id BIGINT)
BEGIN
  -- ========================================================================
  SELECT 
    "Grand Total" as Grand_total,
 --   cost,
 --   acos_,
 --   revenue 
    
COALESCE(ROUND(cost,2),0.00)  AS cost,
COALESCE(ROUND(acos_,2),0.00) AS acos_,
COALESCE(ROUND(revenue,2),0.00) AS revenue
  FROM
    `tbl_prst_vew_peformance_ytd_grand_total`
    WHERE profile_id = pro_id  ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountOverrideTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountOverrideTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountOverrideTable`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.`tbl_map_account_override`
SELECT DISTINCT 
  fk_account_id,
  accountName,
  'N/A' 
FROM
  `replica_adtec_bi`.`prst_tbl_asins_detail` 
WHERE fk_account_id NOT IN 
  (SELECT DISTINCT 
    fk_account_id 
  FROM
     `replica_adtec_bi`.tbl_map_account_override)
;
 
 
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spPopulateAccountOverrideTable'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spPopulateAccountOverrideTable'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateSubcategoryOverrideTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateSubcategoryOverrideTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateSubcategoryOverrideTable`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO `tbl_map_subcategory_override`
SELECT DISTINCT 
`subcategory_id`, 
`subcategory_name`, 'N/A'
 FROM `prst_tbl_asins_detail`
WHERE `subcategory_id` NOT IN ( SELECT DISTINCT `subcategory_id`FROM `tbl_map_subcategory_override`);
 
 
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spPopulateSubcategoryOverrideTable'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spPopulateSubcategoryOverrideTable'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateMappingOverrideCategoryNameTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateMappingOverrideCategoryNameTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateMappingOverrideCategoryNameTable`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
   
   
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO  map_category_override
SELECT DISTINCT category_id, category_name , 'N/A' FROM `prst_tbl_asins_detail`
WHERE category_id NOT IN ( SELECT DISTINCT category_id FROM  map_category_override);	
  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateMappingOverrideCategoryNameTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateMappingOverrideCategoryNameTsble'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateProductOverrideTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateProductOverrideTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateProductOverrideTable`()
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
	
INSERT INTO `replica_adtec_bi`.`map_product_override`
SELECT DISTINCT 
  asin,
  product_title,
  'N/A' 
FROM
  `replica_adtec_bi`.`prst_tbl_asins_detail` 
WHERE fk_account_id NOT IN 
  (SELECT DISTINCT 
    asin
  FROM
     `replica_adtec_bi`.map_product_override)
;
 
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateProductOverrideTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateProductOverrideTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateMapCampTagingDailyTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateMapCampTagingDailyTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateMapCampTagingDailyTable`()
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;		
		ROLLBACK ;
	END;
		-- WARNING
  START TRANSACTION ;
	SET autocommit = 0;
	
	
truncate table map_ams_campaign_taging;
INSERT INTO map_ams_campaign_taging
   ( campaign_id
    , account_id
    , tag_id
    , tag
    , tag_type
    , unique_column
    , creation_date
    , updation_date
    , load_date
   )
   (
      SELECT
         campaignId
       , fkAccountId
       , fkTagId
       , tag
       , `type`
       , `uniqueColumn`
       , `createdAt`
       , `updatedAt`
       , CURRENT_DATE AS load_date
      FROM
         `adtec`.`tbl_campaign_tags_assigned`
   )
;
  
IF `_rollback` THEN
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulateMapCampTagingDailyTable'
    ,'RollBack'
    , CURRENT_TIMESTAMP()
   )
;
ROLLBACK;
ELSE
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulateMapCampTagingDailyTable'
    ,'Commit'
    , CURRENT_TIMESTAMP()
   )
;
COMMIT;
END
IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateInventoryPresentationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateInventoryPresentationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateInventoryPresentationTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    /*	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;*/
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
		
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
	
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	
INSERT INTO replica_adtec_bi.prst_vew_inventory_table
SELECT
  aa.batchid AS DATE,
    bb.`Account_ID`,
    cc.`ASIN`,
    COALESCE (ff.`tag`, 'N/A') AS tag,
    COALESCE (cc.`category_id`,-1) AS category_id,
    COALESCE (cc.`category_name`, 'Other') AS category_name ,
    COALESCE (cc.`subcategory_id`,-1) AS subcategory_id,
    COALESCE (cc.`subcategory_name`, 'Other') AS subcategory_name,
     dd.`product_title`,
     ee.`fulfillment_channel`,
  
  SUM(aa.`sellable_inv_units`) AS sellable_inv_units,
  SUM(aa.`unsellable_inv_units`) AS unsellable_inv_units,
  ROUND(AVG(aa.`price`),2) AS price,
  ROUND(AVG(aa.`salesrank`),0) AS salesrank,
  
  aa.`batchid`,
  aa.`capture_date`,
  aa.`LoadDate`
  
FROM `replica_adtec_bi`.`fact_inventory_master` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb ON (bb.`Account_Key` = aa.`Account_Key` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_product_master` ee ON (ee.`pm_key` = aa.`pm_key` )
LEFT JOIN replica_adtec_bi.`dim_product_category_master` cc ON (cc.`pm_cat_id` = aa.`pm_cat_id`  AND cc.`flag` = 1)
LEFT JOIN replica_adtec_bi.`stage_product_catalog` dd ON (cc.`fk_account_id` = dd.`fk_account_id` AND cc.`ASIN` = dd.`ASIN` AND ee.`fulfillment_channel` = dd.`fulfillment_channel`)
LEFT JOIN replica_adtec_bi.`stage_asin_tags` ff ON (cc.`fk_account_id` = ff.`fk_account_id` AND cc.`ASIN` = ff.`ASIN` AND ee.`fulfillment_channel` = ff.`fullFillmentChannel`)
 
 
 WHERE aa.batchid = `max_date`
GROUP BY 
  aa.batchid,
    bb.`Account_ID`,
   cc.`ASIN`,
   COALESCE (ff.`tag`, 'N/A'),
    dd.`product_title` ,
    ee.`fulfillment_channel`,
    COALESCE (cc.`category_id`,-1),
    COALESCE (cc.`category_name`, 'Other') ,
    COALESCE (cc.`subcategory_id`,-1),
    COALESCE (cc.`subcategory_name`, 'Other'),
  aa.`capture_date`,
  aa.`LoadDate`
;
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateInventoryPresentationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateInventoryPresentationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateInvKPI` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateInvKPI` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateInvKPI`(IN `start_date` VARCHAR(20)
,IN `end_date` VARCHAR(20)
,IN `acc_id` VARCHAR(255))
BEGIN
SELECT 
     fk_account_id AS account_id
   , dacc.`Account_Name` AS account_name
   , pvinv.`asin` AS `asin`
   , SUM(pvinv.`sellable_inv_units`) AS units_on_hand
FROM
   `prst_vew_inventory_table` pvinv
LEFT JOIN
   `dim_account` dacc
ON
   pvinv.`fk_account_id` = dacc.`Account_ID` AND dacc.`flag`=1
WHERE
   DATE_FORMAT(pvinv.`batchid` , '%Y-%m-%d') >= DATE_FORMAT(`start_date` , '%Y-%m-%d')
AND
   DATE_FORMAT(pvinv.`batchid` , '%Y-%m-%d') <= DATE_FORMAT(`end_date` , '%Y-%m-%d')
AND
   FIND_IN_SET(fk_account_id,`acc_id`)
GROUP BY 
     fk_account_id
   , `Account_Name`
   , `asin`
;  
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAllAsinDetailsTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAllAsinDetailsTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAllAsinDetailsTable`()
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	DECLARE EXIT HANDLER FOR SQLWARNING
	BEGIN
		-- WARNING
		SELECT "Warning by DB";
		SET `_rollback` = 1 ;
		ROLLBACK;
	END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
INSERT INTO `replica_adtec_bi`.`prst_tbl_asins_detail`
            (
            
           
             `client_id`,
             `client_name`,
             `fk_account_id`,
             `accountName`,
             `ASIN`,
             `product_title`,
             `category_id`,
             `category_name`,
             `subcategory_id`,
             `subcategory_name`
          
             )
(
SELECT
DISTINCT
  b.`client_id`,
  b.`client_name`,
  a.`fk_account_id`,
  b.`accountName`,
  a.`ASIN`,
  a.`product_title`,
  COALESCE(a.`category_id`,-1) AS `category_id`  ,
  COALESCE(a.`category_name`,'Other')   AS `category_name`,
  COALESCE(a.`subcategory_id`,-1)  AS subcategory_id ,
  COALESCE(a.`subcategory_name`,'Other') AS subcategory_name
  
FROM `replica_adtec_bi`.`stage_product_catalog` a 
INNER JOIN `replica_adtec_bi`.`stage_account_client` b ON a.`fk_account_id` = b.`account_id`
WHERE (a.`fk_account_id` ,a.`ASIN`, a.category_id, a.subcategory_id ) 
NOT IN (
	SELECT DISTINCT  `fk_account_id`,`ASIN`, category_id, subcategory_id 
	FROM  `replica_adtec_bi`.`prst_tbl_asins_detail`
	)
);
	-- Commit if no warning and error else roolback and put them into ETL Logs
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAllAsinDetailsTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAllAsinDetailsTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateOverrideAllTables` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateOverrideAllTables` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateOverrideAllTables`()
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
INSERT INTO `tbl_inventory_brands_override` (fkAccountId)
(SELECT DISTINCT fk_account_id FROM `tbl_inventory_all_details` WHERE fk_account_id NOT IN (SELECT DISTINCT fkAccountId FROM `tbl_inventory_brands_override`
)
);
commit;   
                                     
INSERT INTO `tbl_inventory_category_override` (fkCategoryId)
(SELECT distinct category_id FROM `tbl_inventory_all_details` WHERE category_id > 0 and category_id not in (select distinct fkCategoryId from `tbl_inventory_category_override`
)
);
COMMIT;
INSERT INTO `tbl_inventory_sub_category_override` (fkSubCategoryId)
(SELECT DISTINCT subcategory_id FROM `tbl_inventory_all_details` WHERE subcategory_id > 0 
AND subcategory_id NOT IN  ( SELECT DISTINCT fkSubCategoryId FROM `tbl_inventory_sub_category_override`
)
);
COMMIT;
INSERT INTO `tbl_inventory_products_override` (ASIN)
(SELECT distinct ASIN FROM `tbl_inventory_all_details` where ASIN is not null AND ASIN != '-1' and asin not in ( SELECT DISTINCT asin FROM `tbl_inventory_products_override`
)
);
COMMIT;
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateOverrideAllTables',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateOverrideAllTables',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
     COMMIT ;
  END IF ;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateOverrideAllDetailsTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateOverrideAllDetailsTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateOverrideAllDetailsTable`()
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
                                     
INSERT INTO `tbl_inventory_all_details`(
  `client_id`,
  `client_name`,
  `fk_account_id`,
  `accountName`,
  `ASIN`,
  `product_title`,
  `category_id`  ,
   `category_name`,
   subcategory_id ,
   subcategory_name
	
)
(
SELECT
  b.`client_id`,
  b.`client_name`,
  a.`account_id`,
  a.`account_name`,
  COALESCE(t.`ASIN`,'N/A') AS `ASIN`,
  COALESCE(t.`product_title`,'N/A') AS `product_title`,
  COALESCE(t.`category_id`,-1) AS `category_id`  ,
  COALESCE(t.`category_name`,'N/A')   AS `category_name`,
  COALESCE(t.`subcategory_id`,-1)  AS subcategory_id ,
  COALESCE(t.`subcategory_name`,'N/A') AS subcategory_name
FROM
(
SELECT
DISTINCT
  b.`client_id`,
  b.`client_name`,
  a.`fk_account_id`,
  b.`accountName`,
  a.`ASIN`,
  a.`product_title`,
  COALESCE(a.`category_id`,-1) AS `category_id`  ,
  COALESCE(a.`category_name`,'Other')   AS `category_name`,
  COALESCE(a.`subcategory_id`,-1)  AS subcategory_id ,
  COALESCE(a.`subcategory_name`,'Other') AS subcategory_name
  
FROM `replica_adtec_bi`.`stage_product_catalog` a 
INNER JOIN `replica_adtec_bi`.`stage_account_client` b ON a.`fk_account_id` = b.`account_id`
)t
RIGHT JOIN `dim_account` a ON t.fk_account_id = a.Account_ID
LEFT JOIN `dim_brand` b ON b.client_key = a.client_id
 WHERE (a.`Account_ID` ,COALESCE(t.`ASIN`,'N/A'),  COALESCE(t.`category_id`,-1),   COALESCE(t.`subcategory_id`,-1) ) NOT IN (SELECT DISTINCT  `fk_account_id`,`ASIN`, category_id, subcategory_id FROM  `replica_adtec_bi`.`tbl_inventory_all_details`)
);
/* end of script   */
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateOverrideAllDetailsTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateOverrideAllDetailsTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
     COMMIT ;
  END IF ;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAdvertisingMetrics` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAdvertisingMetrics` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAdvertisingMetrics`(IN `start_date` VARCHAR(20)
,IN `end_date` VARCHAR(20)
,IN `pro_id`   bigint
,IN `camp_id`  bigint)
BEGIN
 SELECT
    sp.profile_id
  , sp.campaign_id
  , COALESCE(spunits,0)+COALESCE(sbunits,0)+COALESCE(sdunits,0)                         AS paid_units_master
  , ROUND(COALESCE(spcost,0.00)   +COALESCE(sbcost,0.00)+COALESCE(sdcost,0.00),2)       AS paid_spend_master
  , ROUND(COALESCE(sprevenue,0.00)+COALESCE(sbrevenue,0.00)+COALESCE(sdrevenue,0.00),2) AS paid_sales_master
  , CASE
       WHEN COALESCE(ROUND(sprevenue,2),0.00)+COALESCE(ROUND(sbrevenue,2),0.00)+COALESCE(ROUND(sdrevenue,2),0.00) > 0
          THEN ROUND(((ROUND(COALESCE(spcost,0.00)+COALESCE(sbcost,0.00)+COALESCE(sdcost,0.00),2) ) / (ROUND(COALESCE(sprevenue,0.00)+COALESCE(sbrevenue,0.00)+COALESCE(sdrevenue,0.00),2))*100),2)
          ELSE 0.00
    END AS paid_acos
 FROM
    (
       SELECT
          profile_id
        , campaign_id
        , COALESCE(SUM(order_conversion),0)    AS spunits
        , COALESCE(ROUND(SUM(cost),2),0.00)    AS spcost
        , COALESCE(ROUND(SUM(revenue),2),0.00) AS sprevenue
       FROM
          prst_tbl_ams_campaign
       WHERE
          campaign_type                        = 'SP'
          AND DATE_FORMAT(batchid,'%Y-%m-%d') >= DATE_FORMAT(`start_date`,'%Y-%m-%d')
          AND DATE_FORMAT(batchid,'%Y-%m-%d') <= DATE_FORMAT(`end_date`,'%Y-%m-%d')
          AND campaign_id                      = `camp_id`
		  AND profile_id                       = `pro_id`
       GROUP BY
          profile_id
        , campaign_id
    )
    sp
    LEFT JOIN
       (
          SELECT
             profile_id
           , campaign_id
           , COALESCE(SUM(order_conversion),0)    AS sbunits
           , COALESCE(ROUND(SUM(cost),2),0.00)    AS sbcost
           , COALESCE(ROUND(SUM(revenue),2),0.00) AS sbrevenue
          FROM
             prst_tbl_ams_campaign
          WHERE
             campaign_type                        = 'SB'
             AND DATE_FORMAT(batchid,'%Y-%m-%d') >= DATE_FORMAT(`start_date`,'%Y-%m-%d')
             AND DATE_FORMAT(batchid,'%Y-%m-%d') <= DATE_FORMAT(`end_date`,'%Y-%m-%d')
             AND campaign_id                      = `camp_id`
			 AND profile_id                       = `pro_id`
          GROUP BY
             profile_id
           , campaign_id
       )
       sb
       ON
          sp.profile_id      = sb.profile_id
          AND sp.campaign_id = sb.campaign_id
    LEFT JOIN
       (
          SELECT
             profile_id
           , campaign_id
           , COALESCE(SUM(order_conversion),0)    AS sdunits
           , COALESCE(ROUND(SUM(cost),2),0.00)    AS sdcost
           , COALESCE(ROUND(SUM(revenue),2),0.00) AS sdrevenue
          FROM
             prst_tbl_ams_campaign
          WHERE
             campaign_type                        = 'SD'
             AND DATE_FORMAT(batchid,'%Y-%m-%d') >= DATE_FORMAT(`start_date`,'%Y-%m-%d')
             AND DATE_FORMAT(batchid,'%Y-%m-%d') <= DATE_FORMAT(`end_date`,'%Y-%m-%d')
             AND campaign_id                      = `camp_id`
			 AND profile_id                       = `pro_id`
          GROUP BY
             profile_id
           , campaign_id
       )
       sd
       ON
          sp.profile_id      = sd.profile_id
          AND sp.campaign_id = sd.campaign_id
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateCustomCampTagingVisual` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateCustomCampTagingVisual` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateCustomCampTagingVisual`(
IN start_date VARCHAR(20),
IN end_date VARCHAR(20),
IN pro_id BIGINT
)
BEGIN
	
	
SELECT 
tag 
/*
 CASE WHEN SUM(revenue) > 0 THEN ROUND(SUM(cost)/SUM(revenue),2)ELSE 0.00
   END AS `ACOS`,
   CASE WHEN SUM(impressions) > 0 THEN ROUND(SUM(clicks)/SUM(impressions),2) ELSE 0.00 End AS `CTR`,
SUM(impressions) AS impressions,
SUM(revenue) AS revenue,
SUM(cost) AS Cost
*/
  , COALESCE(SUM(impressions),0) AS imp
 , COALESCE(ROUND(SUM(revenue),2),0.00)       as rev
 , COALESCE(CASE
      WHEN SUM(revenue) > 0
         THEN ROUND((SUM(cost)/SUM(revenue)*100),2)
         ELSE 0.00
   END,0.00) AS `acos`
 , COALESCE(CASE
      WHEN SUM(impressions) > 0
         THEN ROUND((SUM(clicks)/SUM(impressions)*100),2)
         ELSE 0.00
   END,0.00)       AS `ctr`
 , COALESCE(ROUND(SUM(cost),2),0.00) AS cost
 FROM `prst_tbl_ams_campaign` AS cam
 INNER JOIN
 -- `map_ams_campaign_taging` bb
 tbl_campaign_tags_assigned bb
      ON
         (
            cam.accouint_id       = bb.fkAccountId
            AND cam.campaign_id = bb.campaignId
         )
         WHERE
   
   cam.profile_id  = pro_id
  AND  DATE_FORMAT(cam.`batchid`,'%Y-%m-%d')     >= DATE_FORMAT(start_date,'%Y-%m-%d')
   AND  DATE_FORMAT(cam.`batchid`,'%Y-%m-%d')     <= DATE_FORMAT(end_date,'%Y-%m-%d')  
   AND bb.type    = 3
GROUP BY
   tag
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateCustomCampTagingVisualGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateCustomCampTagingVisualGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateCustomCampTagingVisualGrandTotal`(
IN start_date VARCHAR(20),
IN end_date VARCHAR(20),
IN pro_id BIGINT
)
BEGIN
	
	
SELECT
   'Grand Total' AS total
   /*
 SUM(impressions) AS impressions,
SUM(revenue)        revenue,
 CASE WHEN SUM(revenue) > 0 THEN ROUND(SUM(cost)/SUM(revenue),2)ELSE 0.00 END AS `ACOS`,
 CASE WHEN SUM(impressions) > 0 THEN ROUND(SUM(clicks)/SUM(impressions),2) ELSE 0.00 END AS `CTR`, 
 SUM(cost) AS Cost
 */
   , COALESCE(SUM(impressions),0) AS imp
 , COALESCE(ROUND(SUM(revenue),2),0.00)      as  rev
 , COALESCE(CASE
      WHEN SUM(revenue) > 0
         THEN ROUND((SUM(cost)/SUM(revenue)*100),2)
         ELSE 0.00
   END,0.00) AS `acos`
 , COALESCE(CASE
      WHEN SUM(impressions) > 0
         THEN ROUND((SUM(clicks)/SUM(impressions)*100),2)
         ELSE 0.00
   END,0.00)       AS `ctr`
 , COALESCE(ROUND(SUM(cost),2),0.00) AS cost
 
FROM
   `prst_tbl_ams_campaign` cam
   INNER JOIN
 --     `map_ams_campaign_taging` bb
 tbl_campaign_tags_assigned bb
      ON
         (
            cam.accouint_id       = bb.fkAccountId
            AND cam.campaign_id = bb.campaignId
         )
WHERE
   
   cam.profile_id  = pro_id
  AND  DATE_FORMAT(cam.`batchid`,'%Y-%m-%d')     >= DATE_FORMAT(start_date,'%Y-%m-%d')
   AND  DATE_FORMAT(cam.`batchid`,'%Y-%m-%d')     <= DATE_FORMAT(end_date,'%Y-%m-%d')  
   AND bb.type    = 3
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateProdTypeCampTagingVisual` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateProdTypeCampTagingVisual` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateProdTypeCampTagingVisual`(
IN start_date VARCHAR(20),
IN end_date VARCHAR(20),
IN pro_id BIGINT
)
BEGIN
	
	
SELECT
   tag
   /*
 , SUM(impressions) AS Imp
 , SUM(revenue)        Rev
 , CASE
      WHEN SUM(revenue) > 0
         THEN ROUND(SUM(cost)/SUM(revenue),2)
         ELSE 0.00
   END AS `ACOS`
 , CASE
      WHEN SUM(impressions) > 0
         THEN ROUND(SUM(clicks)/SUM(impressions),2)
         ELSE 0.00
   END       AS `CTR`
 , SUM(cost) AS Cost
 */
 
   , COALESCE(SUM(impressions),0) AS imp
 , COALESCE(ROUND(SUM(revenue),2),0.00)       as rev
 , COALESCE(CASE
      WHEN SUM(revenue) > 0
         THEN ROUND((SUM(cost)/SUM(revenue)*100),2)
         ELSE 0.00
   END,0.00) AS `acos`
 , COALESCE(CASE
      WHEN SUM(impressions) > 0
         THEN ROUND((SUM(clicks)/SUM(impressions)*100),2)
         ELSE 0.00
   END,0.00)       AS `ctr`
 , COALESCE(ROUND(SUM(cost),2),0.00) AS cost
 
 
FROM
   `prst_tbl_ams_campaign` aa
   INNER JOIN
  --    `map_ams_campaign_taging` bb
 tbl_campaign_tags_assigned bb
      ON
         (
            aa.accouint_id       = bb.fkAccountId
            AND aa.campaign_id = bb.campaignId
         )
where
   
   aa.profile_id  = pro_id
  -- and aa.batchid    >= start_date
  -- and aa.batchid     <= end_date
   
   AND  DATE_FORMAT(aa.`batchid`,'%Y-%m-%d')     >= DATE_FORMAT(start_date,'%Y-%m-%d')
   AND  DATE_FORMAT(aa.`batchid`,'%Y-%m-%d')     <= DATE_FORMAT(end_date,'%Y-%m-%d')  
   
   and bb.type    = 1
GROUP BY
   tag
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateProdTypeCampTagingVisualGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateProdTypeCampTagingVisualGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateProdTypeCampTagingVisualGrandTotal`(
IN start_date VARCHAR(20),
IN end_date VARCHAR(20),
IN pro_id BIGINT
)
BEGIN
	
	
SELECT
   'Grand Total' as total
   /*
 , SUM(impressions) AS Imp
 , SUM(revenue)        Rev
 , CASE
      WHEN SUM(revenue) > 0
         THEN ROUND(SUM(cost)/SUM(revenue),2)
         ELSE 0.00
   END AS `ACOS`
 , CASE
      WHEN SUM(impressions) > 0
         THEN ROUND(SUM(clicks)/SUM(impressions),2)
         ELSE 0.00
   END       AS `CTR`
 , SUM(cost) AS Cost
 
 */
 
  , COALESCE(SUM(impressions),0) AS imp
 , COALESCE(ROUND(SUM(revenue),2),0.00)       rev
 , COALESCE(CASE
      WHEN SUM(revenue) > 0
         THEN ROUND((SUM(cost)/SUM(revenue)*100),2)
         ELSE 0.00
   END,0.00) AS `acos`
 , COALESCE(CASE
      WHEN SUM(impressions) > 0
         THEN ROUND((SUM(clicks)/SUM(impressions)*100),2)
         ELSE 0.00
   END,0.00)       AS `ctr`
 , COALESCE(ROUND(SUM(cost),2),0.00) AS cost
 
 
FROM
   `prst_tbl_ams_campaign` aa
   INNER JOIN
 tbl_campaign_tags_assigned bb
      ON
         (
            aa.accouint_id       = bb.fkAccountId
            AND aa.campaign_id = bb.campaignId
         )
WHERE
   
   aa.profile_id  = pro_id
   AND  DATE_FORMAT(aa.`batchid`,'%Y-%m-%d')     >= DATE_FORMAT(start_date,'%Y-%m-%d')
   AND  DATE_FORMAT(aa.`batchid`,'%Y-%m-%d')     <= DATE_FORMAT(end_date,'%Y-%m-%d')  
   AND bb.type    = 1
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateStragTypeCampTagingVisual` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateStragTypeCampTagingVisual` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateStragTypeCampTagingVisual`(
IN start_date VARCHAR(20),
IN end_date VARCHAR(20),
IN pro_id BIGINT
)
BEGIN
	
	
SELECT 
  tag 
  /*
  SUM(impressions) AS Imp,
  SUM(revenue) AS Rev,
  CASE
    WHEN SUM(revenue) > 0 
    THEN ROUND(SUM(cost) / SUM(revenue), 2) 
    ELSE 0.00 
  END AS `ACOS`,
  CASE
    WHEN SUM(impressions) > 0 
    THEN ROUND(SUM(clicks) / SUM(impressions), 2) 
    ELSE 0.00 
  END AS `CTR`,
  SUM(cost) AS Cost 
  */
  
    , COALESCE(SUM(impressions),0) AS imp
 , COALESCE(ROUND(SUM(revenue),2),0.00)     as  rev
 , COALESCE(CASE
      WHEN SUM(revenue) > 0
         THEN ROUND((SUM(cost)/SUM(revenue)*100),2)
         ELSE 0.00
   END,0.00) AS `acos`
 , COALESCE(CASE
      WHEN SUM(impressions) > 0
         THEN ROUND((SUM(clicks)/SUM(impressions)*100),2)
         ELSE 0.00
   END,0.00)       AS `ctr`
 , COALESCE(ROUND(SUM(cost),2),0.00) AS cost
 
 
FROM
  `prst_tbl_ams_campaign` aa 
 inner JOIN 
 tbl_campaign_tags_assigned bb
      ON
         (
            aa.accouint_id       = bb.fkAccountId
            AND aa.campaign_id = bb.campaignId
         )
 
  WHERE aa.profile_id = pro_id  
   AND  DATE_FORMAT(aa.`batchid`,'%Y-%m-%d')     >= DATE_FORMAT(start_date,'%Y-%m-%d')
   AND  DATE_FORMAT(aa.`batchid`,'%Y-%m-%d')     <= DATE_FORMAT(end_date,'%Y-%m-%d')  
  AND bb.type = 2 
GROUP BY tag
  
  ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateStragTypeCampTagingVisualGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateStragTypeCampTagingVisualGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateStragTypeCampTagingVisualGrandTotal`(
IN start_date VARCHAR(20),
IN end_date VARCHAR(20),
IN pro_id BIGINT
)
BEGIN
  SELECT 
    'Grand Total' as total
    /*
    SUM(impressions) AS Imp,
    SUM(revenue) AS Rev,
    CASE
      WHEN SUM(revenue) > 0 
      THEN ROUND(SUM(cost) / SUM(revenue), 2) 
      ELSE 0.00 
    END AS `ACOS`,
    CASE
      WHEN SUM(impressions) > 0 
      THEN ROUND(SUM(clicks) / SUM(impressions), 2) 
      ELSE 0.00 
    END AS `CTR`,
    SUM(cost) AS Cost 
    */
    
      , COALESCE(SUM(impressions),0) AS imp
 , COALESCE(ROUND(SUM(revenue),2),0.00)       rev
 , COALESCE(CASE
      WHEN SUM(revenue) > 0
         THEN ROUND((SUM(cost)/SUM(revenue)*100),2)
         ELSE 0.00
   END,0.00) AS `acos`
 , COALESCE(CASE
      WHEN SUM(impressions) > 0
         THEN ROUND((SUM(clicks)/SUM(impressions)*100),2)
         ELSE 0.00
   END,0.00)       AS `ctr`
 , COALESCE(ROUND(SUM(cost),2),0.00) AS cost
 
 
  FROM
    `prst_tbl_ams_campaign` aa 
    inner JOIN 
 tbl_campaign_tags_assigned bb
      ON
         (
            aa.accouint_id       = bb.fkAccountId
            AND aa.campaign_id = bb.campaignId
         )
  WHERE aa.profile_id = pro_id 
   AND  DATE_FORMAT(aa.`batchid`,'%Y-%m-%d')     >= DATE_FORMAT(start_date,'%Y-%m-%d')
   AND  DATE_FORMAT(aa.`batchid`,'%Y-%m-%d')     <= DATE_FORMAT(end_date,'%Y-%m-%d')  
    AND bb.type = 2 ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationTopCampiagnTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationTopCampiagnTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationTopCampiagnTable`(IN startdate DATE,IN enddate DATE,IN pro_id BIGINT, IN rnk BIGINT)
BEGIN
  
  
SELECT
  `campaign_name`,
   COALESCE(ROUND(spend,2),0.00) AS spend ,
   COALESCE(ROUND(revenue,2),0.00) AS revenue,
   CASE WHEN revenue > 0 THEN  COALESCE(ROUND((spend/Revenue)*100,2),0.00) ELSE 0.00 END AS acos_,
   COALESCE(Rank_,0) AS Rank_
  FROM
(
SELECT
  `campaign_name`,
   spend,
   revenue,
   ROW_NUMBER() OVER (ORDER BY revenue DESC) AS RANK_
  FROM
(
SELECT
  `campaign_name`,
  SUM(`cost`) AS spend,
  SUM(`revenue`) AS revenue
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE
profile_id = pro_id 
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d")
GROUP BY `campaign_name`
)t
)t WHERE (RANK_ <= rnk);
 
 
 -- -------------------------------------------------------------------------
  
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPerformanceytd` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPerformanceytd` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPerformanceytd`(IN pro_id BIGINT)
BEGIN
SELECT 
profile_id,
profile_name,
account_id,
CASE WHEN 
b.overrideLabel <> 'N/A' AND b.overrideLabel IS NOT NULL
THEN 
b.overrideLabel
ELSE
account_name
END
AS account_name,
COALESCE(ROUND(cost,2),0.00)  AS cost,
COALESCE(ROUND(revenue,2),0.00) AS revenue,
COALESCE(ROUND(ACOS,2),0.00) AS ACOS
FROM `prst_vew_peformance_ytd` a
LEFT JOIN `tbl_inventory_brands_override` b
ON 
account_id = fkaccountid
 WHERE profile_id = pro_id
 
 ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPerformancePre30Day` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPerformancePre30Day` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPerformancePre30Day`(IN pro_id BIGINT)
BEGIN
SELECT 
profile_id,
profile_name,
account_id,
CASE WHEN 
b.overrideLabel <> 'N/A' AND b.overrideLabel IS NOT NULL
THEN 
b.overrideLabel
ELSE
account_name
END
AS account_name,
 
COALESCE(ROUND(cost,2),0.00)  AS cost,
COALESCE(ROUND(revenue,2),0.00) AS revenue,
COALESCE(ROUND(acos_,2),0.00) AS acos_
 
 FROM `replica_adtec_bi`.`prst_vew_performance_pre30dayTable` a
 left join `replica_adtec_bi`.`tbl_inventory_brands_override` b
 on 
 account_id = fkaccountid
 WHERE profile_id = pro_id  
 ;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationPre30DayTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationPre30DayTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationPre30DayTable`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
INSERT INTO `replica_adtec_bi`.`prst_vew_performance_pre30dayTable`
SELECT
 profile_id ,
  Profile_name,
  `accouint_id`,
`account_name`,
cost,
revenue,
CASE WHEN revenue > 0 THEN  ROUND((( `cost`/Revenue)*100),2) ELSE 0 END AS acos_
 
 FROM
(
SELECT
  profile_id ,
  Profile_name,
  `accouint_id`,
  `account_name`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue
 , DATE_SUB(CURRENT_DATE, INTERVAL 32 DAY)
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
DATE_FORMAT(batchid,"%Y-%m-%d") >=   DATE_SUB(CURRENT_DATE,INTERVAL 32 DAY) -- 32 change for data purpose 
AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_SUB(CURRENT_DATE,INTERVAL 2 DAY)
GROUP BY `account_name`,profile_id ,Profile_name,`accouint_id`
)t;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulatePresentationPre30DayTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulatePresentationPre30DayTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationAdType` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationAdType` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationAdType`(
  IN startdate DATE,
  IN enddate DATE,
  IN pro_id BIGINT
)
BEGIN
  --  ===================================================================================   
  SELECT 
    `campaign_type`,
     COALESCE(`impressions`,0) as `impressions`,
      COALESCE(round(`revenue`,2),0.00) as `revenue`,
    COALESCE(CASE
      WHEN revenue > 0 
      THEN round(((Cost / Revenue)*100),2) 
      ELSE 0.00 
    END,0.00) AS acos_,
    COALESCE(CASE
      WHEN `impressions` > 0 
      THEN ROUND(((Clicks / `impressions`)*100),2) 
      ELSE 0.00 
    END,0.00) AS CTR,
    COALESCE(ROUND(`cost`,2),0.00) as `cost`
  FROM
    (SELECT 
      `campaign_type`,
      COALESCE(SUM(`impressions`), 0) AS `impressions`,
      COALESCE(SUM(`cost`), 0) AS cost,
      COALESCE(SUM(`revenue`), 0) AS revenue,
      COALESCE(SUM(`clicks`), 0) AS `clicks`,
      COALESCE(SUM(`order_conversion`), 0) AS `order_conversion` 
    FROM
      `replica_adtec_bi`.`prst_tbl_ams_campaign` 
    WHERE DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d") 
      AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(enddate,"%Y-%m-%d")
      AND profile_id = pro_id 
    GROUP BY `campaign_type`) t ;
  --  -----------------------------------------------------------------------------------
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationAdTypeGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationAdTypeGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationAdTypeGrandTotal`(
  IN startdate DATE,
  IN enddate DATE,
  IN pro_id BIGINT
)
BEGIN
  -- =========================================================================================
  -- show data adtype on runtime date ranges
  SELECT 
    'Grand Total' AS Grand_tot,
    COALESCE(ROUND(SUM(`cost`), 2), 0.00) cost,
    COALESCE(CASE
      WHEN SUM(`revenue`) > 0 
      THEN ROUND(((SUM(`cost`) / SUM(`revenue`))*100), 2) 
      ELSE 0 
    END,0.00) AS acos_,
    COALESCE(ROUND(SUM(`revenue`), 2), 0.00) revenue,
    COALESCE(CASE
      WHEN SUM(`impressions`) > 0 
      THEN ROUND(((SUM(`Clicks`) / SUM(`impressions`))*100), 2) 
      ELSE 0 
    END,0.00) AS CTR,
    COALESCE(SUM(`impressions`), 0) AS `impressions` 
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_campaign` 
  WHERE DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d") 
    AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(enddate,"%Y-%m-%d")
    AND profile_id = pro_id ;
  -- -----------------------------------------------------------
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationPre30DayTableGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationPre30DayTableGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationPre30DayTableGrandTotal`()
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	 DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END; 
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
		
	--	ROLLBACK;
	-- END; 
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	-- show grand total performance of a campaign for last 30 days 
INSERT INTO `replica_adtec_bi`.`prst_vew_performance_pre30dayTable_grand_total`
SELECT
  
 'Grand Total' AS Grand_tot,
 profile_id,
 COALESCE(SUM( `cost`),0) cost,
 COALESCE(SUM(`revenue`),0) revenue,
 CASE WHEN SUM(`revenue`) > 0 THEN  ROUND(((SUM( `cost`)/SUM(`revenue`))*100),2) ELSE 0 END AS acos_
 
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
DATE_FORMAT(batchid,"%Y-%m-%d") >=   DATE_SUB(CURRENT_DATE,INTERVAL 32 DAY)
AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_SUB(CURRENT_DATE,INTERVAL 2 DAY)
GROUP BY profile_id
;
	-- Commit if no warning and error else roolback and put them into ETL Logs
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulatePresentationPre30DayTableGrandTotal'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulatePresentationPre30DayTableGrandTotal'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationTop5KeywordsCurrentMTDGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationTop5KeywordsCurrentMTDGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationTop5KeywordsCurrentMTDGrandTotal`(  
 IN pro_id BIGINT,
  IN campaignid BIGINT
  )
BEGIN
  
  -- ===============================================================================================
 SELECT 
    'Grand Total' AS Grand_tot,
     COALESCE(SUM(`impressions`), 0) AS `impressions` ,
     CASE WHEN SUM(`revenue`) > 0 THEN ROUND(((SUM(`cost`) / SUM(`revenue`))*100), 2) ELSE 0 END AS acos_,
    COALESCE(ROUND(SUM(`revenue`), 2), 0) revenue,
    COALESCE(ROUND(SUM(`cost`), 2), 0) cost
     
   
   
FROM `replica_adtec_bi`.`prst_tbl_ams_keyword`
      
    WHERE profile_id = pro_id 
      AND campaign_id = campaignid 
AND DATE(`batchid`) >= LAST_DAY(CURRENT_DATE) + INTERVAL 1 DAY - INTERVAL 1 MONTH 
AND DATE(`batchid`) < CURRENT_DATE 
;
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationTop5KeywordsMTD` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationTop5KeywordsMTD` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationTop5KeywordsMTD`(  
 IN pro_id BIGINT,
  IN campaignid BIGINT
  )
BEGIN
  
  -- ===============================================================================================
SELECT    
`keywordText`,
`impressions`,
`cost`,
`revenue`,
CASE WHEN revenue > 0 THEN coalesce(round(((cost/revenue)*100),2),0.00) ELSE 0.00 END AS `acos`
FROM (
SELECT
`keywordText`,
`impressions`,
`cost`,
`revenue`,
ROW_NUMBER() OVER (ORDER BY `revenue` DESC) AS RANK_
FROM
(
SELECT
keywordText,
SUM(impressions) AS impressions,
SUM(cost) AS cost,
SUM(`revenue`) AS revenue
FROM `prst_tbl_ams_keyword`
      
    WHERE profile_id = pro_id 
      AND campaign_id = campaignid 
AND DATE(`batchid`) >= LAST_DAY(CURRENT_DATE) + INTERVAL 1 DAY - INTERVAL 1 MONTH 
AND DATE(`batchid`) < CURRENT_DATE 
GROUP BY 
`keywordText`
)t
)t WHERE (RANK_ <= 5);
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationYTDGrandTotalTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationYTDGrandTotalTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationYTDGrandTotalTable`()
BEGIN
	
	DECLARE `_rollback` BOOL DEFAULT 0;
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	START TRANSACTION;
	
	SET autocommit = 0;
INSERT INTO tbl_prst_vew_peformance_ytd_grand_total		
 SELECT
	'Grand Total' AS Grand_total,
	profile_id,
	COALESCE(SUM( `cost`),0) cost,
	CASE 
	WHEN SUM(`revenue`) > 0 
	THEN  ROUND(((SUM( `cost`)/SUM(`revenue`))*100),2) 
	ELSE 0
	END AS acos_,
 COALESCE(SUM(`revenue`),0) revenue
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
DATE_FORMAT(batchid,"%Y-%m-%d")>=   DATE_FORMAT(CURRENT_DATE, '%Y-01-01') 
AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(CURRENT_DATE, "%Y-%m-%d")
GROUP BY profile_id
;
	
	
IF `_rollback` THEN
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulatePresentationYTDGrandTotalTable'
    ,'RollBack'
    , CURRENT_TIMESTAMP()
   )
;
ROLLBACK;
ELSE
INSERT INTO `replica_adtec_bi`.`etl_logs`
   ( `log_id`
    ,`Stored_Procedure_Name`
    ,`Execution_status`
    ,`LogDate`
   )
   VALUES
   ( NULL
    ,'spPopulatePresentationYTDGrandTotalTable'
    ,'Commit'
    , CURRENT_TIMESTAMP()
   )
;
COMMIT;
END
IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelASINValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelASINValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelASINValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
DELETE
FROM
   vald_ams_acc_asin
WHERE
   batchid = max_date
;
INSERT INTO vald_ams_acc_asin
   (
   account_id
  ,fact_unit_ordered              
  ,stage_unit_ordered             
  ,diff_unit_ordered              
  ,fact_sales_other_sku			  
  ,stage_sales_other_sku  		  
  ,diff_sales_other_sku			  
  ,fact_unit_ordered_other_sku    
  ,stage_unit_ordered_other_sku   
  ,diff_unit_ordered_other_sku    
  ,batchid		
   )
SELECT
   a.account_id
 , a.unit_ordered
 , b.unit_ordered
 , a.unit_ordered - b.unit_ordered
 , a.sales_other_sku
 , b.sales_other_sku
 , a.sales_other_sku - b.sales_other_sku
 , a.unit_ordered_other_sku
 , b.unit_ordered_other_sku
 , a.unit_ordered_other_sku - b.unit_ordered_other_sku
 , a.batchid
FROM
   (
      SELECT
         bb.`Account_ID`
       , SUM(`attributedunitsordered`)              AS unit_ordered
       , SUM(`sales_other_sku`)                     AS sales_other_sku
       , SUM(`units_ordered_other_sku`)             AS unit_ordered_other_sku
       , batchid
      FROM
         `fact_ams_asins` aa
         LEFT JOIN
            `dim_account` bb
            ON
               (
                  aa.`account_key` = bb.`Account_Key`
               )
      WHERE
         batchid = `max_date`
      GROUP BY
         bb.`Account_ID`
       , batchid
   )
   a
   INNER JOIN
      (
         SELECT
	    `fkAccountId`                                    AS Account_ID
          , SUM(`attributedUnitsOrdered`)                    AS unit_ordered
          , SUM(`sales_other_sku`)                           AS sales_other_sku
          , SUM(`units_ordered_other_sku`)                   AS unit_ordered_other_sku
          , reportDate                                       AS fk_batch_id
         FROM
            `stage_ams_asin`
         GROUP BY
	     `fkAccountId`
            ,reportDate
      )
      b
      ON
         (
            a.batchid        = b.fk_batch_id
            AND a.Account_ID = b.Account_ID
         )
;   
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateAccountLevelASINValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateAccountLevelASINValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAMSScoreCardsPercentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAMSScoreCardsPercentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAMSScoreCardsPercentages`(IN `start_date` VARCHAR(20)
,IN `end_date` VARCHAR(20)
,IN `pro_id`   bigint
,IN `camp_id`  bigint)
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
		
  SELECT
     COALESCE
        (
           CASE
              WHEN cur.impressions > 0
                 THEN ROUND( ( ( ( pre.impressions - cur.impressions ) / cur.impressions ) * 100 ), 2 )
                 ELSE 0.00
           END, 0.0
        )
     AS impressions_perc
   , COALESCE
        (
           CASE
              WHEN cur.clicks > 0
                 THEN ROUND( ( ( ( pre.clicks - cur.clicks ) / cur.clicks ) * 100 ), 2 )
                 ELSE 0.00
           END, 0.0
        )
     AS clicks_perc
   , COALESCE
        (
           CASE
              WHEN cur.cost > 0
                 THEN ROUND( (((pre.cost - cur.cost) / cur.cost) * 100), 2 )
                 ELSE 0.00
           END, 0.0
        )
     AS cost_perc
   , COALESCE
        (
           CASE
              WHEN cur.revenue > 0
                 THEN ROUND( ( ( (pre.revenue - cur.revenue) / cur.revenue ) * 100 ), 2 )
                 ELSE 0.00
           END, 0.00
        )
     AS revenue_perc
   , COALESCE
        (
           CASE
              WHEN cur.acos > 0
                 THEN ROUND( (((pre.acos - cur.acos) / cur.acos) * 100), 2 )
                 ELSE 0.00
           END, 0.00
        )
     AS acos_perc
   , COALESCE
        (
           CASE
              WHEN cur.cpc > 0
                 THEN ROUND((((pre.cpc - cur.cpc) / cur.cpc) * 100), 2)
                 ELSE 0.00
           END, 0.00
        )
     AS cpc_perc
  FROM
     (
        SELECT
           1                  AS curr
         , SUM(`impressions`) AS `impressions`
         , SUM(`cost`)        AS cost
         , SUM(`revenue`)     AS revenue
         , SUM(`clicks`)      AS `clicks`
         , CASE
              WHEN SUM(revenue) > 0
                 THEN ROUND(SUM(cost)/SUM(revenue),2)
                 ELSE 0.00
           END AS `acos`
         , CASE
              WHEN SUM(clicks) > 0
                 THEN ROUND(SUM(cost)/SUM(clicks),2)
                 ELSE 0.00
           END AS cpc
        FROM
           `replica_adtec_bi`.`prst_tbl_ams_campaign`
        WHERE
           `profile_id`      = `pro_id`
           AND `campaign_id`=`camp_id`
           AND `batchid`    >= `start_date`
           AND `batchid`    <= `end_date`
     )
     cur
     INNER JOIN
        (
           SELECT
              1                              AS pr
            , COALESCE(SUM(`impressions`),0) AS `impressions`
            , COALESCE(SUM(`cost`),0)        AS cost
            , COALESCE(SUM(`revenue`),0)     AS revenue
            , COALESCE(SUM(`clicks`),0)      AS `clicks`
            , CASE
                 WHEN SUM(revenue)          > 0
                    AND SUM(cost) IS NOT NULL
                    THEN ROUND(SUM(cost)/SUM(revenue),2)
                    ELSE 0.00
              END AS `acos`
            , CASE
                 WHEN SUM(clicks)           > 0
                    AND SUM(cost) IS NOT NULL
                    THEN ROUND(SUM(cost)/SUM(clicks),2)
                    ELSE 0.00
              END AS cpc
           FROM
              `replica_adtec_bi`.`prst_tbl_ams_campaign`
           WHERE
              `campaign_id`=`camp_id`
              AND `profile_id` = `pro_id`
              AND `batchid`   >= DATE_ADD(`start_date`,INTERVAL DATEDIFF(`start_date`,`end_date`) DAY)
              AND `batchid`    < `start_date`
        )
        pre
        ON
           (
              pr = curr
           )
  ;
  
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAMSScoreCardsAsinLevel` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAMSScoreCardsAsinLevel` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAMSScoreCardsAsinLevel`(IN `start_date` VARCHAR(20)
,IN `end_date` VARCHAR(20)
,IN `pro_id`   BIGINT
,in `camp_id`  varchar(2000)
,IN `prod`  varchar(50))
BEGIN
 
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
  
SELECT
   profile_id
 , profile_name
 , COALESCE(ROUND(SUM(revenue),2),0) AS Revenue
 , COALESCE(ROUND(SUM(cost),2),0)    AS Cost
 , CASE
      WHEN SUM(revenue) > 0
         THEN COALESCE(ROUND(SUM(cost)/SUM(revenue),2),0)
         ELSE 0.00
   END AS `ACOS`
 , CASE
      WHEN SUM(clicks) > 0
         THEN COALESCE(ROUND(SUM(cost)/SUM(clicks),2),0)
         ELSE 0.00
   END              AS CPC
 , COALESCE(ROUND(SUM(clicks),0),0)      AS Clicks
 , COALESCE(ROUND(SUM(impressions),0),0) AS Impressions
 , COALESCE(ROUND(SUM(order_conversion),0),0) AS order_conversion
 , CASE
     WHEN SUM(impressions) > 0
        THEN COALESCE(ROUND(SUM(clicks)/SUM(impressions),2),0)
        ELSE 0.00
    END              AS CTR
 , CASE
     WHEN SUM(order_conversion) > 0
        THEN COALESCE(ROUND(SUM(cost)/SUM(order_conversion),2),0)
        ELSE 0.00
    END              AS CPA
 , CASE
     WHEN SUM(cost) > 0
        THEN COALESCE(ROUND(SUM(revenue)/SUM(cost),2),0)
        ELSE 0.00
    END              AS ROAS
FROM
   `prst_tbl_ams_product`
WHERE
        DATE_FORMAT(`batchid`,'%Y-%m-%d')     >= DATE_FORMAT(`start_date`,'%Y-%m-%d')
   AND  DATE_FORMAT(`batchid`,'%Y-%m-%d')     <= DATE_FORMAT(`end_date`,'%Y-%m-%d')   
   AND  (`camp_id` = 'All' or find_in_set (`campaign_id`,`camp_id`))
   AND  (`profile_id`  = `pro_id`)
   and (`asin` = `prod` ) 
GROUP BY
   profile_id
 , profile_name
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAsinLevelEfficiencyPrecentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAsinLevelEfficiencyPrecentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAsinLevelEfficiencyPrecentages`(IN startdate DATE,
IN enddate DATE
,IN pro_id BIGINT
,IN camp_id varchar(2000)
,asin_ varchar(50))
BEGIN
SELECT
COALESCE ( 
CASE 
 WHEN cur_cpc > 0
 THEN     
 ROUND((( (pre_cpc - cur_cpc) / cur_cpc)*100 ),2) 
 ELSE 0.00 
 END, 0.00) AS prct_cpc,
 
COALESCE (  CASE 
WHEN cur_cpa > 0 
THEN    
 ROUND((( (pre_cpa - cur_cpa) / cur_cpa)*100 ),2) 
 ELSE 0.00 
 END, 0.00) AS prct_cpa,
 
COALESCE (  CASE 
WHEN cur_roas > 0 THEN
    ROUND((( (pre_roas - cur_roas) / cur_roas)*100 ),2)
     ELSE 0.00
      END , 0.00) AS prct_roas
FROM
(
SELECT 
CASE
 WHEN cur.clicks > 0
  THEN
   ROUND(cur.cost/cur.clicks,2)
    ELSE 0.00 
    END AS cur_cpc,
CASE 
WHEN pre.clicks > 0
 THEN ROUND(pre.cost/pre.clicks,2) 
 ELSE 0.00 
 END AS pre_cpc,
CASE 
WHEN cur.conversion> 0 
THEN 
ROUND(cur.cost/cur.conversion,2) 
 ELSE 0.00 
 END AS cur_cpa,
CASE 
WHEN pre.conversion > 0 
THEN 
ROUND(pre.cost/pre.conversion,2) 
ELSE 0.00 
END AS pre_cpa,
CASE 
WHEN cur.cost > 0 
THEN
 ROUND(cur.revenue/cur.cost,2)
  ELSE 0.00 
  END AS cur_roas,
CASE 
WHEN pre.cost > 0 
THEN 
ROUND(pre.revenue/pre.cost,2)
 ELSE 0.00 
 END AS pre_roas
FROM
(
SELECT
  1 AS curr,
  SUM(`clicks`) clicks,
  SUM(`impressions`) impressions,
  SUM(cost) AS cost,
  SUM(revenue) AS revenue,
  SUM(order_conversion) AS conversion
  
FROM `replica_adtec_bi`.`prst_tbl_ams_product`
WHERE 
(profile_id = pro_id)
AND (`asin` = asin_)
AND (campaign_id ='All' OR FIND_IN_SET (`campaign_id`,`camp_id`))
AND DATE_FORMAT(batchid,"%Y-%m-%d")    >= DATE_FORMAT(startdate, "%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")    <= DATE_FORMAT(enddate, "%Y-%m-%d")
)cur
LEFT JOIN 
(
SELECT
  1 AS pr,
  SUM(`clicks`) clicks,
  SUM(`impressions`) impressions,
  SUM(cost) AS cost,
  SUM(revenue) AS revenue,
  SUM(order_conversion) AS conversion
 
FROM `replica_adtec_bi`.`prst_tbl_ams_product`
WHERE 
(profile_id = pro_id)
AND (`asin` = asin_ )
AND (campaign_id ='All' OR FIND_IN_SET (`campaign_id`,`camp_id`))
AND DATE_FORMAT(batchid,"%Y-%m-%d")    >= DATE_FORMAT(DATE_SUB(enddate, INTERVAL ((DATEDIFF( enddate ,startdate) * 2)+1) DAY), "%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")    <= DATE_FORMAT(DATE_SUB(enddate, INTERVAL (DATEDIFF( enddate , startdate)+1) DAY), "%Y-%m-%d")
)pre ON (pr = curr)
)t
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAsinLevelEfficiencyGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAsinLevelEfficiencyGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAsinLevelEfficiencyGrandTotal`(
  IN startdate DATE,
  IN enddate DATE,
  IN pro_id BIGINT
  ,IN camp_id varchar(2000)
  ,IN asin_ Varchar(50)
)
BEGIN
  SELECT 
  
    CASE WHEN  SUM(`clicks`) > 0 THEN   COALESCE(ROUND (  SUM(`cost`) / SUM(`clicks`),2),0.00)
    ELSE 0.00 END AS cpc,
    
        CASE WHEN  SUM(`order_conversion`) > 0 THEN   COALESCE(ROUND (SUM(`cost`) / SUM(`order_conversion`),2),0.00)
    ELSE 0.00 END AS cpa,
    
        CASE WHEN  SUM(`cost`) > 0 THEN   COALESCE(ROUND (SUM(`revenue`) / SUM(`cost`),2),0.00)
    ELSE 0.00 END AS roas
      
  
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_product`
  WHERE 
       (profile_id = pro_id)
AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All')
AND (ASIN = Asin_)
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d") ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAsinLevelPerformanceGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAsinLevelPerformanceGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAsinLevelPerformanceGrandTotal`(
  IN startdate DATE,
  IN enddate DATE,
  IN pro_id BIGINT,
  IN camp_id VARCHAR(2000),
  IN asin_ VARCHAR(50)
)
BEGIN
  
  SELECT 
    COALESCE(ROUND(SUM(`cost`), 2),0.00) AS cost,
    COALESCE(ROUND(SUM(`revenue`), 2),0.00) AS revenue,
  --  ROUND(SUM(`acos`), 2) AS acos_
    CASE WHEN  SUM(`revenue`) > 0 THEN   COALESCE(ROUND (SUM(`cost`) / SUM(`revenue`),2),0.00)
    ELSE 0.00 END AS acos_
    
    
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_product` 
  WHERE (profile_id = pro_id)
AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All' )
AND (ASIN = asin_ )
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d") ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAMSAwarenessAsinLevelGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAMSAwarenessAsinLevelGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAMSAwarenessAsinLevelGrandTotal`(IN startdate DATE
									                                ,IN enddate DATE
									                                ,IN pro_id BIGINT
									                                ,IN camp_id VARCHAR(2000)
									                                ,IN asin_ VARCHAR(500))
BEGIN
  SELECT 
    COALESCE(SUM(`impressions`),0) AS impressions,
    COALESCE(SUM(`clicks`),0) AS clicks,
    
    CASE WHEN  SUM(`impressions`) > 0 THEN   COALESCE(ROUND (SUM(`clicks`) / SUM(`impressions`),2),0.00)
    ELSE 0.00 END AS ctr 
   -- ROUND(SUM(CTR), 2) AS ctr 
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_product` 
  WHERE (profile_id = pro_id )
AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All' )
AND (ASIN = asin_ )
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d") ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAMSAwarenessAsinLevelPercentage` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAMSAwarenessAsinLevelPercentage` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAMSAwarenessAsinLevelPercentage`(IN startdate DATE
									                                ,IN enddate DATE
									                                ,IN pro_id BIGINT
									                                ,IN camp_id VARCHAR(2000)
									                                ,IN asin_ VARCHAR(50))
BEGIN
SELECT
COALESCE(CASE
 WHEN cur_impressions > 0
  THEN
  ROUND((( (pre_impressions - cur_impressions) / cur_impressions)*100 ),2) ELSE 0.00 END,0.00) AS impressions_perc,
COALESCE(CASE 
WHEN cur_impressions > 0
THEN
 ROUND((( (pre_clicks - cur_clicks) / cur_clicks)*100 ),2)
  ELSE 0.00 END,0.00) AS clicks_perc,
CASE
 WHEN cur_ctr > 0 
 THEN 
    COALESCE(ROUND((( (pre_ctr - cur_ctr) / cur_ctr)*100 ),2),0.00) ELSE 0.00 END AS ctr_perc
FROM
(
SELECT cur.clicks AS cur_clicks, 
cur.impressions AS cur_impressions ,
pre.clicks AS pre_clicks, 
pre.impressions AS pre_impressions,
CASE 
WHEN cur.impressions > 0
 THEN
  ROUND(cur.clicks/cur.impressions,2)
   ELSE 0
    END AS cur_ctr,
CASE 
WHEN pre.impressions > 0 
THEN 
ROUND(pre.clicks/pre.impressions,2) 
ELSE 0 
END AS pre_ctr
FROM
(
SELECT
  1 AS curr,
  SUM(`clicks`) clicks,
  SUM(`impressions`) impressions
  
FROM `replica_adtec_bi`.`prst_tbl_ams_product`
WHERE 
(profile_id = pro_id)
AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All' )
AND (ASIN = asin_ )
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(enddate,"%Y-%m-%d")
)cur
LEFT JOIN 
(
SELECT
  1 AS pr,
  SUM(`clicks`) clicks,
  SUM(`impressions`) impressions
 
FROM `replica_adtec_bi`.`prst_tbl_ams_product`
WHERE 
(profile_id = pro_id )
AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All' )
AND (ASIN = asin_)
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(DATE_SUB(enddate, INTERVAL ((DATEDIFF(enddate, startdate) * 2)+1) DAY), "%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(DATE_SUB(enddate, INTERVAL (DATEDIFF( enddate , startdate)+1) DAY), "%Y-%m-%d")
)pre ON (pr = curr)
)t
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAsinLevelPreformancePrecentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAsinLevelPreformancePrecentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAsinLevelPreformancePrecentages`(IN startdate DATE,IN enddate DATE,IN pro_id BIGINT, IN camp_id VARCHAR(2000),IN asin_ VARCHAR(50))
BEGIN
SELECT
   COALESCE
      (
         CASE
            WHEN cur_revenue > 0
               THEN ROUND((( (pre_revenue - cur_revenue) / cur_revenue)*100 ),2)
               ELSE 0.00
         END,0.00
      )
   AS revenue_perc
 , COALESCE
      (
         CASE
            WHEN cur_revenue > 0
               THEN ROUND((( (pre_cost - cur_cost) / cur_cost)*100 ),2)
               ELSE 0.00
         END,0.00
      )
   AS cost_perc
 , COALESCE
      (CASE
      WHEN cur_acos > 0
         THEN ROUND((( (pre_acos - cur_acos) / cur_acos)*100 ),2)
         ELSE 0.00
   END,0.00)
    AS acos_perc
FROM
   (
      SELECT
         cur.cost    AS cur_cost
       , cur.revenue AS cur_revenue
       , pre.cost    AS pre_cost
       , pre.revenue AS pre_revenue
       , CASE
            WHEN cur.revenue > 0
               THEN ROUND(cur.cost/cur.revenue,2)
               ELSE 0
         END AS cur_acos
       , CASE
            WHEN pre.revenue > 0
               THEN ROUND(pre.cost/pre.revenue,2)
               ELSE 0
         END AS pre_acos
      FROM
         (
            SELECT
               1              AS curr
             , SUM(`cost`)       cost
             , SUM(`revenue`)    revenue
            FROM
               `replica_adtec_bi`.`prst_tbl_ams_product`
            WHERE
              ( profile_id      = pro_id )
               AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All')
		AND (ASIN = asin_) 
               AND DATE_FORMAT(batchid,"%Y-%m-%d")    >= DATE_FORMAT(startdate, "%Y-%m-%d")
               AND DATE_FORMAT(batchid,"%Y-%m-%d")    <= DATE_FORMAT(enddate, "%Y-%m-%d")
         )
         cur
         LEFT JOIN
            (
               SELECT
                  1              AS pr
                , SUM(`cost`)       cost
                , SUM(`revenue`)    revenue
               FROM
                  `replica_adtec_bi`.`prst_tbl_ams_product`
               WHERE
                  (profile_id   	= pro_id)
		  AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All')
		  AND (ASIN = asin_ )
                  AND DATE_FORMAT(batchid,"%Y-%m-%d")    >= DATE_FORMAT(DATE_SUB(enddate, INTERVAL ((DATEDIFF( enddate ,startdate) * 2)+1) DAY), "%Y-%m-%d")
                  AND DATE_FORMAT(batchid,"%Y-%m-%d")    <= DATE_FORMAT(DATE_SUB(enddate, INTERVAL (DATEDIFF( enddate , startdate)+1) DAY), "%Y-%m-%d")
            )
            pre
            ON
               (
                  pr = curr
               )
   )
   t
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAMSScoreCards` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAMSScoreCards` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAMSScoreCards`(IN `start_date` VARCHAR(20)
,IN `end_date` VARCHAR(20)
,IN `pro_id`   BIGINT
,IN `camp_id`  varchar(2000))
BEGIN
 
  
SELECT
   profile_id
 , profile_name
 , COALESCE(ROUND(SUM(revenue),2),0) AS Revenue
 , COALESCE(ROUND(SUM(cost),2),0)    AS Cost
 , CASE
      WHEN SUM(revenue) > 0
         THEN COALESCE(ROUND((SUM(cost)/SUM(revenue)*100),2),0)
         ELSE 0.00
   END AS `ACOS`
 , CASE
      WHEN SUM(clicks) > 0
         THEN COALESCE(ROUND(SUM(cost)/SUM(clicks),2),0)
         ELSE 0.00
   END              AS CPC
 , COALESCE(ROUND(SUM(clicks),0),0)      AS Clicks
 , COALESCE(ROUND(SUM(impressions),0),0) AS Impressions
 , COALESCE(ROUND(SUM(order_conversion),0),0) AS order_conversion
 , CASE
     WHEN SUM(impressions) > 0
        THEN COALESCE(ROUND((SUM(clicks)/SUM(impressions)*100),2),0)
        ELSE 0.00
    END              AS CTR
 , CASE
     WHEN SUM(order_conversion) > 0
        THEN COALESCE(ROUND(SUM(cost)/SUM(order_conversion),2),0)
        ELSE 0.00
    END              AS CPA
 , CASE
     WHEN SUM(cost) > 0
        THEN COALESCE(ROUND(SUM(revenue)/SUM(cost),2),0)
        ELSE 0.00
    END              AS ROAS
FROM
   `prst_tbl_ams_campaign`
WHERE
        DATE_FORMAT(`batchid`,'%Y-%m-%d')     >= DATE_FORMAT(`start_date`,'%Y-%m-%d')
   AND  DATE_FORMAT(`batchid`,'%Y-%m-%d')     <= DATE_FORMAT(`end_date`,'%Y-%m-%d')   
   AND (`camp_id`= 'All' or find_in_set(`campaign_id` , `camp_id`))
   AND `profile_id`  = `pro_id`
GROUP BY
   profile_id
 , profile_name
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateAwarenessPrecentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateAwarenessPrecentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateAwarenessPrecentages`(IN startdate DATE,IN enddate DATE,IN pro_id BIGINT,IN campaignid VARCHAR(2000))
BEGIN
SELECT
COALESCE(CASE
 WHEN cur_impressions > 0
  THEN
  ROUND((( (pre_impressions - cur_impressions) / cur_impressions)*100 ),2) ELSE 0.00 END,0.00) AS impressions_perc,
COALESCE(CASE 
WHEN cur_impressions > 0
THEN
 ROUND((( (pre_clicks - cur_clicks) / cur_clicks)*100 ),2)
  ELSE 0.00 END,0.00) AS clicks_perc,
CASE
 WHEN cur_ctr > 0 
 THEN 
    COALESCE(ROUND((( (pre_ctr - cur_ctr) / cur_ctr)*100 ),2),0.00) ELSE 0.00 END AS ctr_perc
FROM
(
SELECT cur.clicks AS cur_clicks, 
cur.impressions AS cur_impressions ,
pre.clicks AS pre_clicks, 
pre.impressions AS pre_impressions,
CASE 
WHEN cur.impressions > 0
 THEN
  ROUND(cur.clicks/cur.impressions,2)
   ELSE 0
    END AS cur_ctr,
CASE 
WHEN pre.impressions > 0 
THEN 
ROUND(pre.clicks/pre.impressions,2) 
ELSE 0 
END AS pre_ctr
FROM
(
SELECT
  1 AS curr,
  SUM(`clicks`) clicks,
  SUM(`impressions`) impressions
  
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
profile_id = pro_id
   AND (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(enddate,"%Y-%m-%d")
)cur
left JOIN 
(
SELECT
  1 AS pr,
  SUM(`clicks`) clicks,
  SUM(`impressions`) impressions
 
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
profile_id = pro_id
   AND (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(DATE_SUB(enddate, INTERVAL ((DATEDIFF(enddate, startdate) * 2)+1) DAY), "%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(DATE_SUB(enddate, INTERVAL (DATEDIFF( enddate , startdate)+1) DAY), "%Y-%m-%d")
)pre ON (pr = curr)
)t
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateCampaignAwarenessGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateCampaignAwarenessGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateCampaignAwarenessGrandTotal`(
  IN startdate DATE,
  IN enddate DATE,
  IN pro_id BIGINT,
  IN campaignid VARCHAR(2000)
)
BEGIN
  SELECT 
    COALESCE(SUM(`impressions`),0) AS impressions,
    COALESCE(SUM(`clicks`),0) AS clicks,
    
    case when  sum(`impressions`) > 0 THEN   COALESCE(round ((sum(`clicks`) / sum(`impressions`)*100),2),0.00)
    else 0.00 end as ctr 
   -- ROUND(SUM(CTR), 2) AS ctr 
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_campaign` 
  WHERE profile_id = pro_id 
    AND (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`) )
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d") ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateCampaignEfficiencyGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateCampaignEfficiencyGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateCampaignEfficiencyGrandTotal`(
  IN startdate DATE,
  IN enddate DATE,
  IN pro_id BIGINT,
IN campaignid VARCHAR(2000)
)
BEGIN
  SELECT 
  
    CASE WHEN  SUM(`clicks`) > 0 THEN   COALESCE(ROUND (  SUM(`cost`) / SUM(`clicks`),2),0.00)
    ELSE 0.00 END AS cpc,
    
        CASE WHEN  SUM(`order_conversion`) > 0 THEN   COALESCE(ROUND (SUM(`cost`) / SUM(`order_conversion`),2),0.00)
    ELSE 0.00 END AS cpa,
    
        CASE WHEN  SUM(`cost`) > 0 THEN   COALESCE(ROUND (SUM(`revenue`) / SUM(`cost`),2),0.00)
    ELSE 0.00 END AS roas
      
  
 --   round(sum(`cpc`), 2) as cpc,
 --   Round(sum(`cpa`), 2) as cpa,
 --   Round(sum(`roas`), 2) as roas 
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_campaign` 
  WHERE profile_id = pro_id 
    AND (campaignid =  'All' OR FIND_IN_SET(`campaign_id`,`campaignid`))
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d") ;
    
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateCampaignPerformanceGrandTotal` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateCampaignPerformanceGrandTotal` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateCampaignPerformanceGrandTotal`(
  IN `start_date` VARCHAR(20)
,IN `end_date` VARCHAR(20)
,IN `pro_id`   BIGINT
,IN `camp_id`  VARCHAR(2000))
BEGIN
  
  SELECT 
    COALESCE(ROUND(SUM(`cost`), 2),0.00) AS cost,
    COALESCE(ROUND(SUM(`revenue`), 2),0.00) AS revenue,
  --  ROUND(SUM(`acos`), 2) AS acos_
    CASE WHEN  SUM(`revenue`) > 0 THEN   COALESCE(ROUND ((SUM(`cost`) / SUM(`revenue`)*100),2),0.00)
    ELSE 0.00 END AS acos_
    
    
  FROM
    `replica_adtec_bi`.`prst_tbl_ams_campaign` 
  WHERE (`camp_id`= 'All'  OR FIND_IN_SET(`campaign_id` , `camp_id`))
   AND `profile_id`  = `pro_id`
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(start_date,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(end_date,"%Y-%m-%d") ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateDODPrecentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateDODPrecentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateDODPrecentages`(
  IN pro_id BIGINT,
  IN campaignid VARCHAR(2000)
)
BEGIN
  -- ===============================================================================================
  SELECT 
    COALESCE(
      CASE
        WHEN cur_impressions > 0 
        THEN ROUND(
          (
            (
              (
                pre_impressions - cur_impressions
              ) / cur_impressions
            ) * 100
          ),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS impressions_perc,
    COALESCE(
      CASE
        WHEN cur_revenue > 0 
        THEN ROUND(
          (((pre_cost - cur_cost) / cur_cost) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS cost_perc,
    COALESCE(
      CASE
        WHEN cur_revenue > 0 
        THEN ROUND(
          (
            (
              (pre_revenue - cur_revenue) / cur_revenue
            ) * 100
          ),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS revenue_perc,
    COALESCE(
      CASE
        WHEN cur_acos > 0 
        THEN ROUND(
          (((pre_acos - cur_acos) / cur_acos) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS acos_perc,
    COALESCE(
      CASE
        WHEN cur_cpc > 0 
        THEN ROUND((((pre_cpc - cur_cpc) / cur_cpc) * 100), 2) 
        ELSE 0.00 
      END,
      0.00
    ) AS cpc_perc,
    COALESCE(
      CASE
        WHEN cur_roas > 0 
        THEN ROUND(
          (((pre_roas - cur_roas) / cur_roas) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS roas_perc 
  FROM
    (SELECT 
      cur.clicks AS cur_clicks,
      cur.impressions AS cur_impressions,
      pre.clicks AS pre_clicks,
      pre.impressions AS pre_impressions,
      cur.cost AS cur_cost,
      cur.revenue AS cur_revenue,
      pre.cost AS pre_cost,
      pre.revenue AS pre_revenue,
      CASE
        WHEN cur.impressions > 0 
        THEN ROUND(cur.clicks / cur.impressions, 2) 
        ELSE 0 
      END AS cur_ctr,
      CASE
        WHEN pre.impressions > 0 
        THEN ROUND(pre.clicks / pre.impressions, 2) 
        ELSE 0 
      END AS pre_ctr,
      CASE
        WHEN cur.revenue > 0 
        THEN ROUND(cur.cost / cur.revenue, 2) 
        ELSE 0 
      END AS cur_acos,
      CASE
        WHEN pre.revenue > 0 
        THEN ROUND(pre.cost / pre.revenue, 2) 
        ELSE 0 
      END AS pre_acos,
      CASE
        WHEN cur.clicks > 0 
        THEN ROUND(cur.cost / cur.clicks, 2) 
        ELSE 0.00 
      END AS cur_cpc,
      CASE
        WHEN pre.clicks > 0 
        THEN ROUND(pre.cost / pre.clicks, 2) 
        ELSE 0.00 
      END AS pre_cpc,
      CASE
        WHEN cur.cost > 0 
        THEN ROUND(cur.revenue / cur.cost, 2) 
        ELSE 0.00 
      END AS cur_roas,
      CASE
        WHEN pre.cost > 0 
        THEN ROUND(pre.revenue / pre.cost, 2) 
        ELSE 0.00 
      END AS pre_roas 
    FROM
      (SELECT 
        1 AS curr,
        SUM(`impressions`) AS `impressions`,
        SUM(`cost`) AS cost,
        SUM(`revenue`) AS revenue,
        SUM(`clicks`) AS `clicks` 
      FROM
        `replica_adtec_bi`.`prst_tbl_ams_campaign` 
      WHERE profile_id = pro_id 
         AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
        AND DATE_FORMAT(`batchid`,'%Y-%m-%d') =  DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 2 DAY),'%Y-%m-%d')
        ) cur 
      LEFT JOIN 
        (SELECT 
          1 AS pr,
          SUM(`impressions`) AS `impressions`,
          SUM(`cost`) AS cost,
          SUM(`revenue`) AS revenue,
          SUM(`clicks`) AS `clicks` 
        FROM
          `replica_adtec_bi`.`prst_tbl_ams_campaign` 
        WHERE DATE_FORMAT(`batchid`,'%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 3 DAY),'%Y-%m-%d')
          AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
          AND `profile_id` = pro_id) pre 
        ON (pr = curr)
        
        ) t ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateEfficiencyPrecentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateEfficiencyPrecentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateEfficiencyPrecentages`(IN startdate DATE,IN enddate DATE,IN pro_id BIGINT,IN campaignid Varchar(2000))
BEGIN
SELECT
COALESCE ( 
CASE 
 WHEN cur_cpc > 0
 THEN     
 ROUND((( (pre_cpc - cur_cpc) / cur_cpc)*100 ),2) 
 ELSE 0.00 
 END, 0.00) AS prct_cpc,
 
COALESCE (  CASE 
WHEN cur_cpa > 0 
THEN    
 ROUND((( (pre_cpa - cur_cpa) / cur_cpa)*100 ),2) 
 ELSE 0.00 
 END, 0.00) AS prct_cpa,
 
COALESCE (  CASE 
WHEN cur_roas > 0 THEN
    ROUND((( (pre_roas - cur_roas) / cur_roas)*100 ),2)
     ELSE 0.00
      END , 0.00) AS prct_roas
FROM
(
SELECT 
CASE
 WHEN cur.clicks > 0
  THEN
   ROUND(cur.cost/cur.clicks,2)
    ELSE 0.00 
    END AS cur_cpc,
CASE 
WHEN pre.clicks > 0
 THEN ROUND(pre.cost/pre.clicks,2) 
 ELSE 0.00 
 END AS pre_cpc,
CASE 
WHEN cur.conversion> 0 
THEN 
ROUND(cur.cost/cur.conversion,2) 
 ELSE 0.00 
 END AS cur_cpa,
CASE 
WHEN pre.conversion > 0 
THEN 
ROUND(pre.cost/pre.conversion,2) 
ELSE 0.00 
END AS pre_cpa,
CASE 
WHEN cur.cost > 0 
THEN
 ROUND(cur.revenue/cur.cost,2)
  ELSE 0.00 
  END AS cur_roas,
CASE 
WHEN pre.cost > 0 
THEN 
ROUND(pre.revenue/pre.cost,2)
 ELSE 0.00 
 END AS pre_roas
FROM
(
SELECT
  1 AS curr,
  SUM(`clicks`) clicks,
  SUM(`impressions`) impressions,
  SUM(cost) AS cost,
  SUM(revenue) AS revenue,
  SUM(order_conversion) AS conversion
  
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
profile_id = pro_id
AND (campaignid =  'All' OR FIND_IN_SET(`campaign_id`,`campaignid`))
AND DATE_FORMAT(batchid,"%Y-%m-%d")    >= DATE_FORMAT(startdate, "%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")    <= DATE_FORMAT(enddate, "%Y-%m-%d")
)cur
Left JOIN 
(
SELECT
  1 AS pr,
  SUM(`clicks`) clicks,
  SUM(`impressions`) impressions,
  SUM(cost) AS cost,
  SUM(revenue) AS revenue,
  SUM(order_conversion) AS conversion
 
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
profile_id = pro_id
AND (campaignid =  'All' OR FIND_IN_SET(`campaign_id`,`campaignid`))
AND DATE_FORMAT(batchid,"%Y-%m-%d")    >= DATE_FORMAT(DATE_SUB(enddate, INTERVAL ((DATEDIFF( enddate ,startdate) * 2)+1) DAY), "%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")    <= DATE_FORMAT(DATE_SUB(enddate, INTERVAL (DATEDIFF( enddate , startdate)+1) DAY), "%Y-%m-%d")
)pre ON (pr = curr)
)t
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateMTDPercentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateMTDPercentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateMTDPercentages`(IN pro_id BIGINT, IN campaignid VARCHAR(2000))
BEGIN
  -- ===============================================================================================
  SELECT 
    COALESCE(
      CASE
        WHEN cur_impressions > 0 
        THEN ROUND(
          (
            (
              (
                pre_impressions - cur_impressions
              ) / cur_impressions
            ) * 100
          ),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS impressions_perc,
    COALESCE(
      CASE
        WHEN cur_revenue > 0 
        THEN ROUND(
          (((pre_cost - cur_cost) / cur_cost) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS cost_perc,
    COALESCE(
      CASE
        WHEN cur_revenue > 0 
        THEN ROUND(
          (
            (
              (pre_revenue - cur_revenue) / cur_revenue
            ) * 100
          ),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS revenue_perc,
    COALESCE(
      CASE
        WHEN cur_acos > 0 
        THEN ROUND(
          (((pre_acos - cur_acos) / cur_acos) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS acos_perc,
    COALESCE(
      CASE
        WHEN cur_cpc > 0 
        THEN ROUND((((pre_cpc - cur_cpc) / cur_cpc) * 100), 2) 
        ELSE 0.00 
      END,
      0.00
    ) AS cpc_perc,
    COALESCE(
      CASE
        WHEN cur_roas > 0 
        THEN ROUND(
          (((pre_roas - cur_roas) / cur_roas) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS roas_perc 
  FROM
    (SELECT 
      cur.clicks AS cur_clicks,
      cur.impressions AS cur_impressions,
      pre.clicks AS pre_clicks,
      pre.impressions AS pre_impressions,
      cur.cost AS cur_cost,
      cur.revenue AS cur_revenue,
      pre.cost AS pre_cost,
      pre.revenue AS pre_revenue,
      CASE
        WHEN cur.impressions > 0 
        THEN ROUND(cur.clicks / cur.impressions, 2) 
        ELSE 0 
      END AS cur_ctr,
      CASE
        WHEN pre.impressions > 0 
        THEN ROUND(pre.clicks / pre.impressions, 2) 
        ELSE 0 
      END AS pre_ctr,
      CASE
        WHEN cur.revenue > 0 
        THEN ROUND(cur.cost / cur.revenue, 2) 
        ELSE 0 
      END AS cur_acos,
      CASE
        WHEN pre.revenue > 0 
        THEN ROUND(pre.cost / pre.revenue, 2) 
        ELSE 0 
      END AS pre_acos,
      CASE
        WHEN cur.clicks > 0 
        THEN ROUND(cur.cost / cur.clicks, 2) 
        ELSE 0.00 
      END AS cur_cpc,
      CASE
        WHEN pre.clicks > 0 
        THEN ROUND(pre.cost / pre.clicks, 2) 
        ELSE 0.00 
      END AS pre_cpc,
      CASE
        WHEN cur.cost > 0 
        THEN ROUND(cur.revenue / cur.cost, 2) 
        ELSE 0.00 
      END AS cur_roas,
      CASE
        WHEN pre.cost > 0 
        THEN ROUND(pre.revenue / pre.cost, 2) 
        ELSE 0.00 
      END AS pre_roas 
    FROM
      (SELECT 
        1 AS curr,
        SUM(`impressions`) AS `impressions`,
        SUM(`cost`) AS cost,
        SUM(`revenue`) AS revenue,
        SUM(`clicks`) AS `clicks` 
      FROM
        `replica_adtec_bi`.`prst_tbl_ams_campaign` 
      WHERE `profile_id` = pro_id 
        AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
        AND DATE_FORMAT(`batchid`,'%Y-%m-%d') >= DATE_FORMAT(LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 1 MONTH ,'%Y-%m-%d')
        AND DATE_FORMAT(`batchid`,'%Y-%m-%d') <  DATE_FORMAT(current_date - 2,'%Y-%m-%d')
        
        ) cur 
      INNER JOIN 
        (SELECT 
          1 AS pr,
          SUM(`impressions`) AS `impressions`,
          SUM(`cost`) AS cost,
          SUM(`revenue`) AS revenue,
          SUM(`clicks`) AS `clicks` 
        FROM
          `replica_adtec_bi`.`prst_tbl_ams_campaign` 
        WHERE DATE_FORMAT(`batchid`,'%Y-%m-%d') >= DATE_FORMAT(LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 2 MONTH ,'%Y-%m-%d')
          AND DATE_FORMAT(`batchid`,'%Y-%m-%d') <  DATE_FORMAT(current_date - INTERVAL 1 MONTH ,'%Y-%m-%d')
          AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
          AND `profile_id` = pro_id) pre 
        ON (pr = curr)) t ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculatePreformancePrecentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculatePreformancePrecentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculatePreformancePrecentages`(
  IN `start_date` VARCHAR(20)
,IN `end_date` VARCHAR(20)
,IN `pro_id`   BIGINT
,IN `camp_id`  VARCHAR(2000))
BEGIN
SELECT
   COALESCE
      (
         CASE
            WHEN cur_revenue > 0
               THEN ROUND((( (pre_revenue - cur_revenue) / cur_revenue)*100 ),2)
               ELSE 0.00
         END,0.00
      )
   AS revenue_perc
 , COALESCE
      (
         CASE
            WHEN cur_revenue > 0
               THEN ROUND((( (pre_cost - cur_cost) / cur_cost)*100 ),2)
               ELSE 0.00
         END,0.00
      )
   AS cost_perc
 , COALESCE
      (CASE
      WHEN cur_acos > 0
         THEN ROUND((( (pre_acos - cur_acos) / cur_acos)*100 ),2)
         ELSE 0.00
   END,0.00)
    AS acos_perc
FROM
   (
      SELECT
         cur.cost    AS cur_cost
       , cur.revenue AS cur_revenue
       , pre.cost    AS pre_cost
       , pre.revenue AS pre_revenue
       , CASE
            WHEN cur.revenue > 0
               THEN ROUND(cur.cost/cur.revenue,2)
               ELSE 0
         END AS cur_acos
       , CASE
            WHEN pre.revenue > 0
               THEN ROUND(pre.cost/pre.revenue,2)
               ELSE 0
         END AS pre_acos
      FROM
         (
            SELECT
               1              AS curr
             , SUM(`cost`)       cost
             , SUM(`revenue`)    revenue
            FROM
               `replica_adtec_bi`.`prst_tbl_ams_campaign`
             WHERE
              (`camp_id`= 'All'  OR FIND_IN_SET(`campaign_id` , `camp_id`))
		AND `profile_id`  = `pro_id`
               AND DATE_FORMAT(batchid,"%Y-%m-%d")    >= DATE_FORMAT(start_date, "%Y-%m-%d")
               AND DATE_FORMAT(batchid,"%Y-%m-%d")    <= DATE_FORMAT(end_date, "%Y-%m-%d")
         )
         cur
         Left JOIN
            (
               SELECT
                  1              AS pr
                , SUM(`cost`)       cost
                , SUM(`revenue`)    revenue
               FROM
                  `replica_adtec_bi`.`prst_tbl_ams_campaign`
               WHERE
			(`camp_id`= 'All'  OR FIND_IN_SET(`campaign_id` , `camp_id`))
			AND `profile_id`  = `pro_id`
                  AND DATE_FORMAT(batchid,"%Y-%m-%d")    >= DATE_FORMAT(DATE_SUB(end_date, INTERVAL ((DATEDIFF( end_date ,start_date) * 2)+1) DAY), "%Y-%m-%d")
                  AND DATE_FORMAT(batchid,"%Y-%m-%d")    <= DATE_FORMAT(DATE_SUB(end_date, INTERVAL (DATEDIFF( end_date , start_date)+1) DAY), "%Y-%m-%d")
            )
            pre
            ON
               (
                  pr = curr
               )
   )
   t
;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateWowPercentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateWowPercentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateWowPercentages`(IN pro_id BIGINT,IN campaignid VARCHAR(2000))
BEGIN
  
  -- ===============================================================================================
SELECT
COALESCE( CASE WHEN cur_impressions > 0 THEN ROUND((((pre_impressions - cur_impressions) / cur_impressions) * 100),2) ELSE 0.00 END,0.0)AS impressions_perc,
COALESCE(CASE WHEN cur_revenue > 0 THEN ROUND((((pre_cost - cur_cost) / cur_cost) * 100),2) ELSE 0.00 END,0.00)AS cost_perc,
COALESCE(CASE WHEN cur_acos > 0 THEN ROUND((((pre_acos - cur_acos) / cur_acos) * 100),2) ELSE 0.00 END,0.00 )AS acos_perc,
COALESCE(CASE WHEN cur_cost > 0 THEN  ROUND(((pre_revenue - cur_revenue/cur_revenue)*100),2) ELSE 0.00 END,0.00 ) AS revenue_perc,
COALESCE(CASE WHEN cur_cpc > 0 THEN ROUND((((pre_cpc - cur_cpc) / cur_cpc) * 100), 2)  ELSE 0.00 END, 0.00 )AS cpc_perc,
COALESCE(CASE WHEN cur_roas > 0 THEN ROUND((((pre_roas - cur_roas) / cur_roas) * 100),2) ELSE 0.00 END,0.00) AS roas_perc 
FROM
  (SELECT 
    cur.clicks AS cur_clicks,
    cur.impressions AS cur_impressions,
    pre.clicks AS pre_clicks,
    pre.impressions AS pre_impressions,
    cur.cost AS cur_cost,
    cur.revenue AS cur_revenue,
    pre.cost AS pre_cost,
    pre.revenue AS pre_revenue,
    CASE
      WHEN cur.impressions > 0 
      THEN ROUND(cur.clicks / cur.impressions, 2) 
      ELSE 0 
    END AS cur_ctr,
    CASE
      WHEN pre.impressions > 0 
      THEN ROUND(pre.clicks / pre.impressions, 2) 
      ELSE 0 
    END AS pre_ctr,
    CASE
      WHEN cur.revenue > 0 
      THEN ROUND(cur.cost / cur.revenue, 2) 
      ELSE 0 
    END AS cur_acos,
    CASE
      WHEN pre.revenue > 0 
      THEN ROUND(pre.cost / pre.revenue, 2) 
      ELSE 0 
    END AS pre_acos,
    CASE
      WHEN cur.clicks > 0 
      THEN ROUND(cur.cost / cur.clicks, 2) 
      ELSE 0.00 
    END AS cur_cpc,
    CASE
      WHEN pre.clicks > 0 
      THEN ROUND(pre.cost / pre.clicks, 2) 
      ELSE 0.00 
    END AS pre_cpc,
    CASE
      WHEN cur.cost > 0 
      THEN ROUND(cur.revenue / cur.cost, 2) 
      ELSE 0.00 
    END AS cur_roas,
    CASE
      WHEN pre.cost > 0 
      THEN ROUND(pre.revenue / pre.cost, 2) 
      ELSE 0.00 
    END AS pre_roas 
FROM
    (SELECT 
      1 AS curr,
      SUM(`impressions`) AS `impressions`,
      SUM(`cost`) AS cost,
      SUM(`revenue`) AS revenue,
      SUM(`clicks`) AS `clicks` 
    FROM
      `replica_adtec_bi`.`prst_tbl_ams_campaign` 
    WHERE 
            DATE_FORMAT(`batchid`,'%Y-%m-%d')>=   DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 8 DAY),'%Y-%m-%d')
        AND DATE_FORMAT(`batchid`,'%Y-%m-%d')  <=   DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 2 DAY),'%Y-%m-%d')
    AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`) )
     AND `profile_id` = pro_id
     
      
      ) cur 
    INNER JOIN 
      (
      SELECT 
        1 AS pr,
        SUM(`impressions`) AS `impressions`,
        SUM(`cost`) AS cost,
        SUM(`revenue`) AS revenue,
        SUM(`clicks`) AS `clicks` 
      FROM
        `replica_adtec_bi`.`prst_tbl_ams_campaign` 
         WHERE DATE_FORMAT(`batchid`,'%Y-%m-%d') >=   DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 15 DAY),'%Y-%m-%d')
        AND    DATE_FORMAT(`batchid`,'%Y-%m-%d') <=   DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 9 DAY),'%Y-%m-%d')
	AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`)) 
	AND `profile_id` = pro_id
        ) pre 
      ON (pr = curr)) t ;
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateWTDPercentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateWTDPercentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateWTDPercentages`(IN pro_id BIGINT, IN campaignid VARCHAR(2000))
BEGIN
	
  SELECT
     COALESCE
        (
           CASE
              WHEN cur_impressions > 0
                 THEN ROUND( ( ( ( pre_impressions - cur_impressions ) / cur_impressions ) * 100 ), 2 )
                 ELSE 0.00
           END, 0.0
        )
     AS impressions_perc
   , COALESCE
        (
           CASE
              WHEN cur_revenue > 0
                 THEN ROUND( (((pre_cost - cur_cost) / cur_cost) * 100), 2 )
                 ELSE 0.00
           END, 0.0
        )
     AS cost_perc
   , COALESCE
        (
           CASE
              WHEN cur_revenue > 0
                 THEN ROUND( ( ( (pre_revenue - cur_revenue) / cur_revenue ) * 100 ), 2 )
                 ELSE 0.00
           END, 0.00
        )
     AS revenue_perc
   , COALESCE
        (
           CASE
              WHEN cur_acos > 0
                 THEN ROUND( (((pre_acos - cur_acos) / cur_acos) * 100), 2 )
                 ELSE 0.00
           END, 0.00
        )
     AS acos_perc
   , COALESCE
        (
           CASE
              WHEN cur_cpc > 0
                 THEN ROUND((((pre_cpc - cur_cpc) / cur_cpc) * 100), 2)
                 ELSE 0.00
           END, 0.00
        )
     AS cpc_perc
   , COALESCE
        (
           CASE
              WHEN cur_roas > 0
                 THEN ROUND( (((pre_roas - cur_roas) / cur_roas) * 100), 2 )
                 ELSE 0.00
           END, 0.00
        )
     AS roas_perc
  FROM
     (
        SELECT
           cur.clicks      AS cur_clicks
         , cur.impressions AS cur_impressions
         , pre.clicks      AS pre_clicks
         , pre.impressions AS pre_impressions
         , cur.cost        AS cur_cost
         , cur.revenue     AS cur_revenue
         , pre.cost        AS pre_cost
         , pre.revenue     AS pre_revenue
         , CASE
              WHEN cur.impressions > 0
                 THEN ROUND(cur.clicks / cur.impressions, 2)
                 ELSE 0
           END AS cur_ctr
         , CASE
              WHEN pre.impressions > 0
                 THEN ROUND(pre.clicks / pre.impressions, 2)
                 ELSE 0
           END AS pre_ctr
         , CASE
              WHEN cur.revenue > 0
                 THEN ROUND(cur.cost / cur.revenue, 2)
                 ELSE 0
           END AS cur_acos
         , CASE
              WHEN pre.revenue > 0
                 THEN ROUND(pre.cost / pre.revenue, 2)
                 ELSE 0
           END AS pre_acos
         , CASE
              WHEN cur.clicks > 0
                 THEN ROUND(cur.cost / cur.clicks, 2)
                 ELSE 0.00
           END AS cur_cpc
         , CASE
              WHEN pre.clicks > 0
                 THEN ROUND(pre.cost / pre.clicks, 2)
                 ELSE 0.00
           END AS pre_cpc
         , CASE
              WHEN cur.cost > 0
                 THEN ROUND(cur.revenue / cur.cost, 2)
                 ELSE 0.00
           END AS cur_roas
         , CASE
              WHEN pre.cost > 0
                 THEN ROUND(pre.revenue / pre.cost, 2)
                 ELSE 0.00
           END AS pre_roas
        FROM
           (
              SELECT
                 1                  AS curr
               , SUM(`impressions`) AS `impressions`
               , SUM(`cost`)        AS cost
               , SUM(`revenue`)     AS revenue
               , SUM(`clicks`)      AS `clicks`
              FROM
                 `replica_adtec_bi`.`prst_tbl_ams_campaign`
              WHERE
                 `profile_id`         = pro_id
                 AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
                 AND DATE_FORMAT(`batchid`,'%Y-%m-%d') >= DATE_FORMAT(LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 1 week,'%Y-%m-%d')
                 AND DATE_FORMAT(`batchid`,'%Y-%m-%d')  <= DATE_FORMAT(CURRENT_DATE - 2,'%Y-%m-%d') 
           )
           cur
           INNER JOIN
              (
                 SELECT
                    1                  AS pr
                  , SUM(`impressions`) AS `impressions`
                  , SUM(`cost`)        AS cost
                  , SUM(`revenue`)     AS revenue
                  , SUM(`clicks`)      AS `clicks`
                 FROM
                    `replica_adtec_bi`.`prst_tbl_ams_campaign`
                 WHERE
                        DATE_FORMAT(`batchid`,'%Y-%m-%d') >= DATE_FORMAT(LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 2 week,'%Y-%m-%d') 
                    AND DATE_FORMAT(`batchid`,'%Y-%m-%d')  < DATE_FORMAT(CURRENT_DATE    - INTERVAL 1 week,'%Y-%m-%d') 
                  AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
                    AND `profile_id`     = pro_id
              )
              pre
              ON
                 (
                    pr = curr
                 )
     )
     t
  ;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spCalculateYTDPercentages` */

/*!50003 DROP PROCEDURE IF EXISTS  `spCalculateYTDPercentages` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spCalculateYTDPercentages`(IN pro_id BIGINT, IN campaignid VARCHAR(2000))
BEGIN
  -- ==========================================================================================
  SELECT 
    COALESCE(
      CASE
        WHEN cur_impressions > 0 
        THEN ROUND(
          (
            (
              (
                pre_impressions - cur_impressions
              ) / cur_impressions
            ) * 100
          ),
          2
        ) 
        ELSE 0.00 
      END,
      0.0
    ) AS impressions_perc,
    COALESCE(
      CASE
        WHEN cur_revenue > 0 
        THEN ROUND(
          (((pre_cost - cur_cost) / cur_cost) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.0
    ) AS cost_perc,
    COALESCE(
      CASE
        WHEN cur_revenue > 0 
        THEN ROUND(
          (
            (
              (pre_revenue - cur_revenue) / cur_revenue
            ) * 100
          ),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS revenue_perc,
    COALESCE(
      CASE
        WHEN cur_acos > 0 
        THEN ROUND(
          (((pre_acos - cur_acos) / cur_acos) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS acos_perc,
    COALESCE(
      CASE
        WHEN cur_cpc > 0 
        THEN ROUND((((pre_cpc - cur_cpc) / cur_cpc) * 100), 2) 
        ELSE 0.00 
      END,
      0.00
    ) AS cpc_perc,
    COALESCE(
      CASE
        WHEN cur_roas > 0 
        THEN ROUND(
          (((pre_roas - cur_roas) / cur_roas) * 100),
          2
        ) 
        ELSE 0.00 
      END,
      0.00
    ) AS roas_perc 
  FROM
    (SELECT 
      cur.clicks AS cur_clicks,
      cur.impressions AS cur_impressions,
      pre.clicks AS pre_clicks,
      pre.impressions AS pre_impressions,
      cur.cost AS cur_cost,
      cur.revenue AS cur_revenue,
      pre.cost AS pre_cost,
      pre.revenue AS pre_revenue,
      CASE
        WHEN cur.impressions > 0 
        THEN ROUND(cur.clicks / cur.impressions, 2) 
        ELSE 0 
      END AS cur_ctr,
      CASE
        WHEN pre.impressions > 0 
        THEN ROUND(pre.clicks / pre.impressions, 2) 
        ELSE 0 
      END AS pre_ctr,
      CASE
        WHEN cur.revenue > 0 
        THEN ROUND(cur.cost / cur.revenue, 2) 
        ELSE 0 
      END AS cur_acos,
      CASE
        WHEN pre.revenue > 0 
        THEN ROUND(pre.cost / pre.revenue, 2) 
        ELSE 0 
      END AS pre_acos,
      CASE
        WHEN cur.clicks > 0 
        THEN ROUND(cur.cost / cur.clicks, 2) 
        ELSE 0.00 
      END AS cur_cpc,
      CASE
        WHEN pre.clicks > 0 
        THEN ROUND(pre.cost / pre.clicks, 2) 
        ELSE 0.00 
      END AS pre_cpc,
      CASE
        WHEN cur.cost > 0 
        THEN ROUND(cur.revenue / cur.cost, 2) 
        ELSE 0.00 
      END AS cur_roas,
      CASE
        WHEN pre.cost > 0 
        THEN ROUND(pre.revenue / pre.cost, 2) 
        ELSE 0.00 
      END AS pre_roas 
    FROM
      (SELECT 
        1 AS curr,
        SUM(`impressions`) AS `impressions`,
        SUM(`cost`) AS cost,
        SUM(`revenue`) AS revenue,
        SUM(`clicks`) AS `clicks` 
      FROM
        `replica_adtec_bi`.`prst_tbl_ams_campaign` 
      WHERE `profile_id` = pro_id 
      AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
        AND DATE_FORMAT(`batchid`,'%Y-%m-%d') >= DATE_FORMAT(CURRENT_DATE, '%Y-01-01') 
        AND DATE_FORMAT(`batchid`,'%Y-%m-%d')<= DATE_FORMAT(CURRENT_DATE,'%Y-%m-%d')
        ) cur 
      INNER JOIN 
        (SELECT 
          1 AS pr,
          SUM(`impressions`) AS `impressions`,
          SUM(`cost`) AS cost,
          SUM(`revenue`) AS revenue,
          SUM(`clicks`) AS `clicks` 
        FROM
          `replica_adtec_bi`.`prst_tbl_ams_campaign` 
        WHERE DATE_FORMAT(`batchid`,'%Y-%m-%d')>= DATE_FORMAT(CURRENT_DATE - interval 1 year,'%Y-01-01') 
          AND DATE_FORMAT(`batchid`,'%Y-%m-%d') <= DATE_FORMAT(CURRENT_DATE - interval 1 year,'%Y-%m-%d') 
        AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
          AND `profile_id` = pro_id) pre 
        ON (pr = curr)) t ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateCampaignMTD` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateCampaignMTD` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateCampaignMTD`(IN pro_id BIGINT,IN campaignid VARCHAR(2000))
BEGIN
/*  SELECT   
   `impressions`,
    `cost`,
    `revenue`,
    `clicks`,
CASE WHEN revenue > 0 THEN  (Cost/Revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (Cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (Clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
*/
SELECT   
   COALESCE(ROUND(`impressions`,0),0) AS impressions,
   COALESCE(ROUND( `cost`,2),0.00) AS cost,
   COALESCE(ROUND( `revenue`,2),0.00) AS revenue,
   COALESCE(ROUND( `clicks`,0),0) AS clicks,
CASE WHEN revenue > 0 THEN  COALESCE(ROUND((Cost/Revenue),2),0.00) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   COALESCE(ROUND((Cost/ clicks),2),0.00) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  COALESCE(ROUND((Clicks/`impressions`),2),0.00) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN COALESCE(ROUND((Cost/`order_conversion`),2),0.00) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   COALESCE(ROUND((Revenue/Cost),2),0.00) ELSE 0.00 END  AS ROAS
FROM
(
SELECT
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
	
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
      DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(LAST_DAY(CURRENT_DATE) + INTERVAL 1 DAY - INTERVAL 1 MONTH,"%Y-%m-%d")
  AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(CURRENT_DATE - 2,"%Y-%m-%d")
  AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
   AND `profile_id` = pro_id
  
  )t;
 
 -- -------------------------------------------------------------------------
 
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationCpgYTDTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationCpgYTDTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationCpgYTDTable`(IN pro_id BIGINT,IN campaignid VARCHAR(2000))
BEGIN
/* SELECT   
   `impressions`,
    `cost`,
    `revenue`,
    `clicks`,
CASE WHEN revenue > 0 THEN  (Cost/Revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (Cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (Clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
*/
SELECT   
   COALESCE(ROUND(`impressions`,0),0) AS impressions,
   COALESCE(ROUND( `cost`,2),0.00) AS cost,
   COALESCE(ROUND( `revenue`,0.00),0.00) AS revenue,
   COALESCE(ROUND( `clicks`,0),0) AS clicks,
CASE WHEN revenue > 0 THEN  COALESCE(ROUND(((Cost/Revenue)*100),2),0.00) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   COALESCE(ROUND((Cost/ clicks),2),0.00) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  COALESCE(ROUND(((Clicks/`impressions`)*100),2),0.00) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN COALESCE(ROUND((Cost/`order_conversion`),2),0.00) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   COALESCE(ROUND((Revenue/Cost),2),0.00) ELSE 0.00 END  AS ROAS
FROM
(
SELECT
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
  
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE DATE_FORMAT(batchid,"%Y-%m-%d") >=  DATE_FORMAT(CURRENT_DATE, "%Y-01-01") -- '%Y0101') 
 AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
AND `profile_id` = pro_id
  
)t;
 
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationDODTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationDODTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationDODTable`(IN pro_id BIGINT,IN campaignid VARCHAR(2000))
BEGIN
/*
SELECT   
   `impressions`,
    `cost`,
    `revenue`,
    `clicks`,
CASE WHEN revenue > 0 THEN  (Cost/Revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (Cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (Clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
*/
SELECT   
   COALESCE(ROUND(`impressions`,0),0) AS impressions,
   COALESCE(ROUND( `cost`,2),0.00) AS cost,
   COALESCE(ROUND( `revenue`,2),0.00) AS revenue,
   COALESCE(ROUND( `clicks`,0),0) AS clicks,
CASE WHEN revenue > 0 THEN  COALESCE(ROUND(((Cost/Revenue)*100),2),0.00) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   COALESCE(ROUND((Cost/ clicks),2),0.00) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  COALESCE(ROUND(((Clicks/`impressions`)*100),2),0.00) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN COALESCE(ROUND((Cost/`order_conversion`),2),0.00) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   COALESCE(ROUND((Revenue/Cost),2),0.00) ELSE 0.00 END  AS ROAS
FROM
(
SELECT
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
  
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE DATE_FORMAT(batchid,"%Y-%m-%d") = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 2 DAY),"%Y-%m-%d")
 AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
AND `profile_id` = pro_id
  
)t;
 
 -- -------------------------------------------------------------------------
 
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationWowTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationWowTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationWowTable`(IN pro_id BIGINT,IN campaignid VARCHAR(2000))
BEGIN
  
  -- ===============================================================================================
	
SELECT   
   COALESCE(ROUND(`impressions`,0),0) as impressions,
   COALESCE(ROUND( `cost`,2),0.00) as cost,
   COALESCE(ROUND( `revenue`,0.00),0.00) as revenue,
   COALESCE(ROUND( `clicks`,0),0) as clicks,
CASE WHEN revenue > 0 THEN  coalesce(round(((Cost/Revenue)*100),2),0.00) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   COALESCE(round((Cost/ clicks),2),0.00) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  COALESCE(round(((Clicks/`impressions`)*100),2),0.00) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN COALESCE(round((Cost/`order_conversion`),2),0.00) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   COALESCE(round((Revenue/Cost),2),0.00) ELSE 0.00 END  AS ROAS
FROM
(
SELECT
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
  
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE DATE_FORMAT(batchid,"%Y-%m-%d") >=   DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 9 DAY),"%Y-%m-%d")
AND   DATE_FORMAT(batchid,"%Y-%m-%d") <=   DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 2 DAY),"%Y-%m-%d")
AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`) )
AND `profile_id` = pro_id
 
)t;
  -- ===============================================================================================
 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationWTDTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationWTDTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationWTDTable`(IN pro_id BIGINT,IN campaignid VARCHAR(2000))
BEGIN 
/*
SELECT   
   `impressions`,
    `cost`,
    `revenue`,
    `clicks`,
CASE WHEN revenue > 0 THEN  (Cost/Revenue) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   (Cost/ clicks) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  (Clicks/`impressions`) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN (Cost/`order_conversion`) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   (Revenue/Cost) ELSE 0.00 END  AS ROAS
*/
SELECT   
   COALESCE(ROUND(`impressions`,0),0) AS impressions,
   COALESCE(ROUND( `cost`,2),0.00) AS cost,
   COALESCE(ROUND( `revenue`,0.00),0.00) AS revenue,
   COALESCE(ROUND( `clicks`,0),0) AS clicks,
CASE WHEN revenue > 0 THEN  COALESCE(ROUND(((Cost/Revenue)*100),2),0.00) ELSE 0.00 END AS acos_,
CASE WHEN clicks > 0 THEN   COALESCE(ROUND((Cost/ clicks),2),0.00) ELSE 0.00 END AS CPC,
CASE WHEN `impressions` > 0 THEN  COALESCE(ROUND(((Clicks/`impressions`)*100),2),0.00) ELSE 0.00 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN COALESCE(ROUND((Cost/`order_conversion`),2),0.00) ELSE 0.00 END 	AS CPA,
CASE WHEN Cost > 0 THEN   COALESCE(ROUND((Revenue/Cost),2),0.00) ELSE 0.00 END  AS ROAS
FROM
(
SELECT
   COALESCE(SUM(`impressions`),0) AS `impressions`,
   COALESCE(SUM(`cost`),0) AS cost ,
   COALESCE(SUM(`revenue`),0) AS revenue,
   COALESCE(SUM(`clicks`),0) AS `clicks`,
   COALESCE(SUM(`order_conversion`),0) AS `order_conversion`
  
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
  
WHERE DATE_FORMAT(batchid,"%Y-%m-%d")  >= DATE_FORMAT(DATE_ADD(now(), INTERVAL(1-DAYOFWEEK(now())) day),"%Y-%m-%d") -- sunday
 
  
  -- DATE_ADD(mydate, INTERVAL(-WEEKDAY(mydate)) DAY) Monday
  
AND  (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
  AND `profile_id` = pro_id
 )t ;
 
 
 -- -------------------------------------------------------------------------
 
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewManagerDim` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewManagerDim` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewManagerDim`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
 --    ERROR
 --   SELECT 
 --    "Syntax Error" ;
 --  SET `_rollback` = 1 ;
 --  ROLLBACK ;
 -- END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.`dim_manager`
SELECT DISTINCT
   NULL 
 , b.`Manager_id`
 , b.`Brand_id`
 , b.`Manager_name`
 , b.`created_at`
 , b.`updated_at`
 , b.`deleted_at`
 ,"1"
FROM
   (
      SELECT DISTINCT
	b.`Manager_id`,
	b.`Brand_id`,
	b.`Manager_name`,
	b.`created_at`,
	b.`updated_at`,
	b.`deleted_at`
      FROM
         replica_adtec_bi.`stage_manager` b
      WHERE
         Brand_id NOT IN
         (
            SELECT
               yy.Brand_id
            FROM
               `dim_manager`   xx
             , `stage_manager` yy
            WHERE
               xx.Brand_id = yy.Brand_id
         )
   )
   b
   LEFT JOIN
      `dim_manager` cl
      ON
         (
            b.Manager_id = cl.`Manager_id`
         )
;  
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewManagerDim'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewManagerDim'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewManagerUpdateDim` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewManagerUpdateDim` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewManagerUpdateDim`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
 --    ERROR
 --   SELECT 
 --    "Syntax Error" ;
 --  SET `_rollback` = 1 ;
 --  ROLLBACK ;
 -- END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
UPDATE 
  replica_adtec_bi.`dim_manager` a,
  replica_adtec_bi.`stage_manager` b 
SET
  `Flag` = 0
WHERE a.`Manager_id`= b.`Manager_id` 
  AND (
   
    a.`Brand_id` <> b.`Brand_id`
  ) 
  AND  `Flag` = 1;
  
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewManagerDim'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewManagerDim'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spShowProductMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spShowProductMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spShowProductMaster`()
BEGIN
select 
  account_id
  , `asin`
  , product_title
  , fullfillment_channel
  , cost
  , revenue
  , `acos`
  , order_conversion
  , order_units
  , shipped_units
  , `qtd_shipped_units`
  ,`ytd_shipped_units`
  , `mtd_shipped_units`
  , `wtd_shipped_units`
  , `last_week_shipped_units`
  , `price`
  , `price_diff_30d`
  , `salesrank`
  , `prsc_diff_salesrank_pre_30d`
  , `sellable_inv_units`
  , `unsellable_inv_units`
  , `po_units`
  , `review_score`
  , `review_score_30d`
  , `review_count`
  , `review_count_30d`
  , `ytd_po_units`
  , `mtd_po_units`
  , `qtd_po_units`
  , `wtd_po_units`
  , `last_week_po_units`
  , `batchid`
  from `replica_adtec_bi`.`prst_tbl_product_master`
;
  
  
 
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimPurchaseOrder` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimPurchaseOrder` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimPurchaseOrder`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
	
INSERT INTO `replica_adtec_bi`.`dim_purchaseorder`
SELECT 	
         NULL,
	b.`po`, 
	b.`hand_off_type`, 
	b.`ship_location`, 
	b.`model_number`, 
	b.`asins`, 
	b.`sku`, 
	b.`title`, 
	b.`po_status`, 
	b.`delivery_window_start`, 
	b.`delivery_window_end`, 
	b.`backorder`, 
	b.`expected_ship_date`, 
	b.`confirmed_ship_date`,
	 CURRENT_DATE AS `LoadDate`
	 
	FROM  
	`replica_adtec_bi`.`stage_purchaseorder_master`  b
	         LEFT OUTER JOIN
            `replica_adtec_bi`.dim_purchaseorder AS r
            ON
               (
              
                      b.asins                  = r.asins
                  AND b.po = r.po   
                  AND b.sku                   = r.sku
                  AND b.`model_number` = r.`model_number`
               )
      WHERE
         r.po IS NULL
      ;
      
     
	  
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewRecordDimPurchaseOrder'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spAddNewRecordDimPurchaseOrder'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  COMMIT;
  END
  IF;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateProductPresentationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateProductPresentationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateProductPresentationTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO `prst_tbl_ams_product`
SELECT
  ee.`Client_ID`,
  ee.`Client_Name`,
  dd.`Account_ID`,
  dd.`Account_Name`,
  pp.profile_id,
  pp.profile_Name,
  
  `date_key`,
   bb.campaign_id,
   bb.`campaign_name`,
   cc.`camp_type`,
     
   bb.adgroup_id,
   bb.adgroup_name,
   bb.ad_id,  
   bb.asin,
   bb.sku,
   
 
  
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_units`,
  `order_conversion`,
  
 
CASE WHEN revenue > 0 THEN  ROUND((Cost/Revenue),2) ELSE 0 END AS acos_,
CASE WHEN clicks > 0 THEN   ROUND((Cost/ clicks),2) ELSE 0 END AS CPC,
CASE WHEN `impressions` > 0 THEN  ROUND((Clicks/`impressions`),2) ELSE 0 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN ROUND((Cost/`order_conversion`),2) ELSE 0 END 	AS CPA,
CASE WHEN Cost > 0 THEN   ROUND((Revenue/Cost),2) ELSE 0 END  AS ROAS ,
aa.batchid,
aa.capture_date,
CURRENT_DATE AS loaddate  
FROM `replica_adtec_bi`.`fact_ams_product`  aa
LEFT JOIN `replica_adtec_bi`.`dim_product`         bb  ON (aa.`product_key` = bb.`product_key`)
LEFT JOIN `replica_adtec_bi`.`map_ams_profile`      pp  ON (pp.`profile_key` = bb.profile_key)
LEFT JOIN `replica_adtec_bi`.`map_ams_report_type`  cc  ON (bb.`camp_type_key` = cc.`camp_type_key`)
LEFT JOIN `replica_adtec_bi`.`dim_account`          dd  ON (dd.`Account_Key` = aa.`account_key` AND dd.flag = 1)
LEFT JOIN `replica_adtec_bi`.`dim_brand`            ee  ON (ee.`Client_Key` = aa.`client_key`)
WHERE aa.batchid = max_date;   
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateProductPresentationTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateProductPresentationTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimScraping` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimScraping` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimScraping`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.`dim_scraping`
SELECT 	
         NULL,
	b.`account_id`, 
	b.`asin`, 
	b.`capture_date`, 
	 CURRENT_DATE AS `LoadDate`
	 
	FROM  
	`replica_adtec_bi`.`stage_scraping`  b
	         LEFT OUTER JOIN
            `replica_adtec_bi`.`dim_scraping` AS r
            ON
               (
              
                      b.asin      = r.asin
                  AND b.account_id = r.account_id   
               )
      WHERE
         r.asin IS NULL
      ;
           
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimProduct'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimProduct'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateScrapingPresentationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateScrapingPresentationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateScrapingPresentationTable`(IN max_date VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	START TRANSACTION;
	
	SET autocommit = 0;
	 
delete from `replica_adtec_bi`.`prst_tbl_scraping` WHERE DATE_FORMAT(capture_date,'%Y%m%d') = DATE_FORMAT(`max_date`,'%Y%m%d');
insert into `replica_adtec_bi`.`prst_tbl_scraping`
SELECT
    cc.asin
  , dd.account_id
  , ee.client_id
  , aa.total_reviews
  , aa.reviews_count
  , aa.average_review
  , aa.capture_date
  , aa.load_date
  
 FROM
	`replica_adtec_bi`.`fact_scraping` aa
	LEFT JOIN `replica_adtec_bi`.`dim_account`          dd  ON (dd.`Account_Key` = aa.`account_key` AND dd.flag = 1)
        LEFT JOIN `replica_adtec_bi`.`dim_brand`            ee  ON (ee.`Client_Key` = aa.brand_key) 
	LEFT JOIN  replica_adtec_bi.`dim_scraping`           cc ON(cc.scrap_key = aa.scrap_key)
        where DATE_FORMAT(aa.capture_date,'%Y%m%d') = DATE_FORMAT(`max_date`,'%Y%m%d')
;
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateScrapingPresentationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateScrapingPresentationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePurchaseOrderPresentationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePurchaseOrderPresentationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePurchaseOrderPresentationTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    /*	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;*/
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
		
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
	
  
	-- use to control AutoCommit off
	SET autocommit = 0;
delete from replica_adtec_bi.`prst_tbl_purchase_order` WHERE batchid = `max_date`; 
INSERT INTO replica_adtec_bi.`prst_tbl_purchase_order`
SELECT 	
         bb.account_id,
         `po`,
          asins,
          sku,
         `po_status`,
         `title`,
	`case_size`, 
	`submitted_cases`, 
	`accepted_cases`, 
	`received_cases`, 
	`outstanding_cases`, 
	`str_case_cost`, 
	`str_total_cost`, 
	`case_cost`, 
	`total_cost`, 
	`accepted_case`, 
	`rejected_case`, 
	`total_po_cost`, 
	`batchid`, 
	`capture_date`, 
	`loaddate`
	 
	FROM 
	`replica_adtec_bi`.`fact_purchaseorder`  aa
	LEFT JOIN replica_adtec_bi.`dim_account` bb ON (bb.`Account_Key` = aa.`Account_Key` AND bb.`flag` = 1)
	LEFT JOIN replica_adtec_bi.`dim_purchaseorder` cc ON ( cc.po_key = aa.po_key)
	
	 WHERE aa.batchid = `max_date`
;
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulatePurchaseOrderPresentationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulatePurchaseOrderPresentationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelPurchaseOrderValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelPurchaseOrderValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelPurchaseOrderValidationTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	-- Insert Data in Account Validation Table To Validate Satge and Fact Has same data 
	-- (for a specific Account) By subtracting Fact and Stage 
delete from `replica_adtec_bi`.`vald_purchesorder_account`where batchid = `max_date`;
INSERT INTO `replica_adtec_bi`.`vald_purchesorder_account` (
SELECT 
stage_AccountKey,
stage_total_cost,
fact_total_cost,
fact_total_cost - stage_total_cost AS total_cost_diff,
stage_accepted_case,
fact_accepted_case,
fact_accepted_case - stage_accepted_case AS accepted_case_diff,
stage_rejected_case,
fact_rejected_case,
fact_rejected_case - stage_rejected_case AS rejected_case_diff,
stage_total_po_cost,
 fact_total_po_cost,
fact_total_po_cost - stage_total_po_cost AS total_po_cost_diff,
'fact_PO_data_account_level',
stage_batchid
FROM (
SELECT 
fk_account_id AS stage_AccountKey
,SUM(total_cost)AS stage_total_cost
,SUM(accepted_case)AS stage_accepted_case
,SUM(rejected_case)AS stage_rejected_case
,SUM(total_po_cost)AS stage_total_po_cost
,LEFT(batchid,8) AS stage_batchid
FROM `replica_adtec_bi`.`stage_purchaseorder_master` 
GROUP BY    
  fk_account_id,
LEFT(batchid,8)
)stage
 
	
	INNER JOIN (
SELECT 
cc.`Account_ID` AS fact_AccountKey 
,SUM(total_cost)AS fact_total_cost
,SUM(accepted_case)AS fact_accepted_case
,SUM(rejected_case)AS fact_rejected_case
,SUM(total_po_cost)AS fact_total_po_cost
,LEFT(batchid,8) AS fact_batchid
FROM `replica_adtec_bi`.`fact_purchaseorder` aa
 LEFT JOIN replica_adtec_bi.`dim_account` cc ON (cc.`Account_Key` = aa.`Account_Key` )
 WHERE 
 		batchid = `max_date`
 		 GROUP BY 
  		cc.`Account_Key`,
  		batchid
)fact
	ON (stage_AccountKey = fact_AccountKey)
);
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAccountLevelPurchaseOrderValidationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAccountLevelPurchaseOrderValidationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
);
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelScrapingValidation` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelScrapingValidation` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelScrapingValidation`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
   SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
    -- WARNING
  --  SELECT 
    --  "Warning by DB" ;
   -- SET `_rollback` = 1 ;
   -- ROLLBACK;
 -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
DELETE FROM `vald_scraping_date` WHERE  FactBatchID = DATE_FORMAT(max_date,'%Y-%m-%d');
INSERT INTO vald_scraping_date
(
`FactReviewCount`,
`StageReviewCount`,
`DiffReviewCount`,
`FactBatchID`,
`StageBatchID`
)
SELECT 
fact.ReviewCountFact AS FactReviewCount,
stage.ReviewCountStage AS StageReviewCount,
fact.ReviewCountFact-stage.ReviewCountStage AS DiffReviewCount,
fact.batchid AS FactBatchID,
stage.batchid AS StageBatchID
FROM
(
SELECT 	
SUM(`reviews_count`) AS ReviewCountFact,
capture_date AS batchid
FROM 
`replica_adtec_bi`.`fact_scraping`
where DATE_FORMAT(`capture_date`,'%Y-%m-%d')=DATE_FORMAT(max_date,'%Y-%m-%d')
GROUP BY 
`capture_date`
) fact
INNER JOIN
(
SELECT
SUM(`reviews_count`) AS ReviewCountStage,
capture_date AS batchid
FROM 
`replica_adtec_bi`.`stage_scraping`
WHERE capture_date = DATE_FORMAT(max_date,'%Y-%m-%d')
GROUP BY
`capture_date`
)
stage
ON
fact.batchid = stage.batchid;
        
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelScrapingValidation'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelScrapingValidation'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAccountLevelScrapingValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAccountLevelScrapingValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAccountLevelScrapingValidationTable`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	-- Insert Data in Account Validation Table To Validate Satge and Fact Has same data 
	-- (for a specific Account) By subtracting Fact and Stage 
	
DELETE FROM `replica_adtec_bi`.`vald_scraping_account` WHERE  fact_capture_date = DATE_FORMAT(max_date,'%Y-%m-%d');
INSERT INTO `replica_adtec_bi`.`vald_scraping_account`(
SELECT
stage_Accountkey,
stage_review_count,
fact_review_count,
fact_review_count - stage_review_count AS  review_cost_diff,
'fact_scraping_data_account_level',
 stage_capture_date,fact_capture_date
FROM 
(
SELECT `account_id` AS stage_Accountkey,
SUM(`reviews_count`)AS stage_review_count,
`capture_date` AS stage_capture_date
FROM `replica_adtec_bi`.`stage_scraping`
where `capture_date` = DATE_FORMAT(`max_date`,'%Y-%m-%d')
GROUP BY 
`account_id`,
`capture_date`
)stage
INNER JOIN
(
SELECT 
cc.`Account_ID` AS fact_AccountKey
,SUM(`reviews_count`)AS fact_review_count,
`capture_date`AS fact_capture_date
FROM `replica_adtec_bi`.`fact_scraping` aa
LEFT JOIN `replica_adtec_bi`.`dim_account` cc ON (cc.`Account_Key` = aa.`account_key` )
WHERE DATE_FORMAT(`date_key`,'%Y-%m-%d')=DATE_FORMAT(max_date,'%Y-%m-%d')
 		 GROUP BY 
  		cc.`Account_Key`,
  		`capture_date`
)fact
          ON (stage_Accountkey = fact_AccountKey)
          
);
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAccountLevelScrapingValidationTable'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateAccountLevelScrapingValidationTable'
			,'Commit'
			,CURRENT_TIMESTAMP()
);
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateProductMasterTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateProductMasterTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateProductMasterTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
  --  BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
   -- SET `_rollback` = 1 ;
   -- ROLLBACK;
 -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
 TRUNCATE TABLE replica_adtec_bi.`prst_tbl_product_master` ;
INSERT INTO replica_adtec_bi.`prst_tbl_product_master`
SELECT 
NULL
,account_id
,a.`asin`
,product_title
,fullfillment_channel
,cost
,revenue
,ROUND(`acos`,2) AS `acos`
,order_conversion
,order_units
,shipped_units
,COALESCE(quter_shipped_units,0) AS quter_shipped_units
,COALESCE(ytd_shipped_units,0) AS ytd_shipped_units
,COALESCE(mtd_shipped_units,0) AS mtd_shipped_units
,COALESCE(wtd_shipped_units,0) AS wtd_shipped_units
,COALESCE(last_week_shipped_units,0) AS last_week_shipped_units
,price
,COALESCE(price_diff_30d,0.00) AS price_diff_30d
,salesrank
,COALESCE(prsc_diff_salesrank_pre_30d,-1) AS prsc_diff_salesrank_pre_30d
,COALESCE(sellable_inv_units,0) AS sellable_inv_units
,COALESCE(unsellable_inv_units,0) AS unsellable_inv_units
,COALESCE(po_units,0) AS po_units
,COALESCE(review_score,0.00) AS review_score
,COALESCE(review_score_30d,0.00) AS review_score_30d
,COALESCE(review_count,0) AS  review_count
,COALESCE(review_count_30d,0) AS review_count_30d
,COALESCE(ytd_po_units,0) AS  ytd_po_units
,COALESCE(mtd_po_units,0) AS mtd_po_units
,COALESCE(wtd_po_units,0) AS wtd_po_units
,COALESCE(qtd_po_units,0) AS qtd_po_units
,COALESCE(last_week_po_units,0) AS last_week_po_units
, NOW() AS batchid
, NOW() AS load_date
 FROM
(
SELECT 
 account_id
,`asin`
,product_title
,fullfillment_channel
,SUM(cost) AS cost
,SUM(revenue) AS revenue
,CASE WHEN SUM(revenue) > 0.00 THEN (SUM(cost)/SUM(revenue))*100 ELSE 0.00 END AS `acos`
,MAX(price) AS price 
,CASE WHEN max(salesrank) > 0 THEN max(salesrank) ELSE -1 END AS salesrank
,SUM(sellable_inv_units) AS sellable_inv_units
,SUM(unsellable_inv_units) AS unsellable_inv_units
,SUM(po_units) AS po_units
,COALESCE( MAX(`reviews_score`),0.00) AS review_score
,COALESCE( MAX(reviews_count),0) AS review_count
,SUM(order_conversion) AS order_conversion
,SUM(order_units) AS order_units
,SUM(shipped_units) AS shipped_units
, NOW() AS load_date
 FROM `replica_adtec_bi`.prst_tbl_temp_product_master b
 GROUP BY 
 account_id
,`asin`
,product_title
,fullfillment_channel
)a LEFT JOIN 
( SELECT ASIN , SUM(shipped_units) AS quter_shipped_units FROM `replica_adtec_bi`.`prst_tbl_temp_product_master` a
 WHERE  DATE_FORMAT(a.batchid,'%Y-%m-%d') > MAKEDATE(YEAR(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY)), 1) + INTERVAL QUARTER(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY)) QUARTER 
                                       - INTERVAL    1 QUARTER 
 GROUP BY ASIN) b  ON (a.asin = b.asin)
 
LEFT JOIN (SELECT ASIN , SUM(shipped_units) AS ytd_shipped_units FROM `replica_adtec_bi`.`prst_tbl_temp_product_master` a
 WHERE  DATE_FORMAT(a.batchid,'%Y-%m-%d') >= MAKEDATE(YEAR(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY)), 1) 
 GROUP BY ASIN)c ON (a.asin = c.asin)
 
 
 LEFT JOIN ( SELECT ASIN , SUM(shipped_units) AS  mtd_shipped_units FROM `replica_adtec_bi`.`prst_tbl_temp_product_master` a
 WHERE  DATE_FORMAT(a.batchid,'%Y-%m-%d') >= DATE_ADD(DATE_SUB(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY)),INTERVAL 1 MONTH),INTERVAL 1 DAY)
 GROUP BY ASIN)d ON (a.asin = d.asin)
 LEFT JOIN ( SELECT ASIN, SUM(shipped_units) AS   wtd_shipped_units FROM `replica_adtec_bi`.`prst_tbl_temp_product_master` a
 WHERE DATE_FORMAT(a.batchid,'%Y-%m-%d') >= DATE_SUB(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY),INTERVAL WEEKDAY(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY)) DAY)
 GROUP BY ASIN)e ON (a.asin = e.asin)
 LEFT JOIN (SELECT ASIN , SUM(shipped_units) AS last_week_shipped_units FROM `replica_adtec_bi`.`prst_tbl_temp_product_master` a
WHERE  DATE_FORMAT(a.batchid,'%Y-%m-%d') < DATE_SUB(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY),INTERVAL WEEKDAY(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY))  DAY)
AND DATE_FORMAT(a.batchid,'%Y-%m-%d') >= DATE_SUB(DATE_SUB(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY),INTERVAL WEEKDAY(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY))  DAY),INTERVAL 7 DAY)
GROUP BY ASIN)f ON (a.asin = f.asin)
 
 
 
 
LEFT JOIN (
SELECT ASIN,  CASE WHEN `min` > 0 THEN ROUND(COALESCE(`max`/`min`,0.00),2)  ELSE 0.00 END AS price_diff_30d FROM 
(SELECT ASIN, MAX(price) AS `max`, MIN(price) AS `min` FROM `replica_adtec_bi`.`prst_tbl_temp_product_master` c
WHERE  DATE_FORMAT(c.batchid,'%Y-%m-%d') < DATE_SUB(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY),INTERVAL 2 DAY)
AND DATE_FORMAT(c.batchid,'%Y-%m-%d') >= DATE_SUB(DATE_SUB(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY),INTERVAL 2 DAY),INTERVAL 1 MONTH) AND price != -1.00
GROUP BY ASIN)a
) g ON (a.asin = g.asin)
LEFT JOIN (
SELECT DISTINCT ASIN ,  ROUND(COALESCE((salesrank-avg_salesrank)/avg_salesrank,0.00),2) AS prsc_diff_salesrank_pre_30d FROM
(SELECT COALESCE(zz.salesrank,0) AS salesrank,pp.asin,ROUND(avg_salesrank,2) AS avg_salesrank
FROM 
(SELECT salesrank,ASIN FROM `replica_adtec_bi`.`prst_tbl_temp_product_master` t
WHERE DATE_FORMAT(t.batchid,'%Y-%m-%d') = DATE_SUB(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY),INTERVAL 2 DAY) AND salesrank != -1
)zz
RIGHT JOIN 
( SELECT AVG(salesrank) AS avg_salesrank, ASIN FROM `replica_adtec_bi`.`prst_tbl_temp_product_master` yy 
WHERE DATE_FORMAT(yy.batchid,'%Y-%m-%d') < DATE_SUB(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY),INTERVAL 2 DAY)
AND DATE_FORMAT(yy.batchid,'%Y-%m-%d') >= DATE_SUB(DATE_SUB(DATE_ADD(CURRENT_DATE, INTERVAL -2 DAY),INTERVAL 2 DAY),INTERVAL 1 MONTH) AND salesrank != -1
GROUP BY ASIN
)pp
ON zz.asin=pp.asin)c
)h ON (a.asin = h.asin)
LEFT JOIN (SELECT ASIN, MAX(average_review) - MIN(average_review) AS review_score_30d FROM `prst_tbl_scraping` a
WHERE capture_date > DATE_ADD(CURRENT_DATE , INTERVAL - 32 DAY)
AND capture_date <= DATE_ADD(CURRENT_DATE , INTERVAL - 2 DAY)  
GROUP BY 
ASIN)i ON (a.asin = i.asin)
LEFT JOIN (SELECT ASIN,  MAX(reviews_count) - MIN(reviews_count) AS review_count_30d FROM `prst_tbl_scraping` a
WHERE  capture_date > DATE_ADD(CURRENT_DATE , INTERVAL - 32 DAY)
AND capture_date <= DATE_ADD(CURRENT_DATE , INTERVAL - 2 DAY)  
GROUP BY 
ASIN)j ON (a.asin = j.asin)
 -- -----------------------------------------------------------------------------
 
 LEFT JOIN ( SELECT ASIN, SUM(accepted_cases) AS  ytd_po_units FROM `prst_tbl_purchase_order` a
 WHERE  DATE_FORMAT(batchid,'%Y-%m-%d') >= MAKEDATE(YEAR(CURRENT_DATE), 1) 
 GROUP BY ASIN)k  ON (a.asin = k.asin)
LEFT JOIN ( SELECT ASIN, SUM(accepted_cases) AS  mtd_po_units FROM `prst_tbl_purchase_order` a
 WHERE DATE_FORMAT(batchid,'%Y-%m-%d') >= DATE_ADD(DATE_SUB(LAST_DAY(CURRENT_DATE),INTERVAL 1 MONTH),INTERVAL 1 DAY)
 GROUP BY ASIN
 )l  ON (a.asin = l.asin)
LEFT JOIN (SELECT ASIN, SUM(accepted_cases) AS qtd_po_units FROM `prst_tbl_purchase_order` a
 WHERE  DATE_FORMAT(batchid,'%Y-%m-%d') > MAKEDATE(YEAR(CURRENT_DATE), 1) + INTERVAL QUARTER(CURRENT_DATE) QUARTER                                        - INTERVAL    1 QUARTER
 GROUP BY ASIN)m ON (a.asin = m.asin)
LEFT JOIN ( SELECT ASIN, SUM(accepted_cases) AS  wtd_po_units FROM `prst_tbl_purchase_order` a
 WHERE   DATE_FORMAT(batchid,'%Y-%m-%d') >= DATE_SUB(CURRENT_DATE,INTERVAL WEEKDAY(CURRENT_DATE) DAY)
 GROUP BY ASIN)n  ON (a.asin = n.asin)
LEFT JOIN(
SELECT ASIN ,SUM(accepted_cases) AS last_week_po_units FROM `prst_tbl_purchase_order` a
WHERE   DATE_FORMAT(batchid,'%Y-%m-%d') < DATE_SUB(CURRENT_DATE,INTERVAL WEEKDAY(CURRENT_DATE)  DAY)
AND DATE_FORMAT(batchid,'%Y-%m-%d') >= DATE_SUB(DATE_SUB(CURRENT_DATE,INTERVAL WEEKDAY(CURRENT_DATE)  DAY),INTERVAL 7 DAY)
GROUP BY ASIN)o ON (a.asin = o.asin)
;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateProductMasterTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateProductMasterTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateProductMasterTempTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateProductMasterTempTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateProductMasterTempTable`(IN `max_date` VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ======================================================================================================================================
DELETE FROM replica_adtec_bi.`prst_tbl_temp_product_master` WHERE DATE_FORMAT(batchid,'%Y-%m-%d') = DATE_FORMAT(`max_date`,'%Y-%m-%d');
INSERT INTO replica_adtec_bi.`prst_tbl_temp_product_master`
SELECT 
NULL,
t.account_id , t.asin, 
REPLACE(COALESCE(c.product_title,'N/A'), 'NA', 'N/A') AS product_title,
REPLACE(COALESCE(c.`fullfillment_channel`,'N/A'), 'NA', 'N/A') AS fullfillment_channel,
COALESCE(SUM(b.cost),0.00) AS cost,
COALESCE(SUM(b.revenue),0.00) AS revenue
,COALESCE(SUM(b.order_conversion),0) AS order_conversion,
COALESCE(SUM(b.order_units),0) AS order_units,
COALESCE(SUM(c.shipped_units),0) AS shipped_units,
COALESCE(MAX(c.price),0.00) AS price,
COALESCE(MAX(c.salesrank),-1) AS salesrank,
COALESCE(SUM(d.sellable_inv_units),0) AS  sellable_inv_units,
COALESCE(SUM(d.unsellable_inv_units),0) AS  unsellable_inv_units,
COALESCE(SUM(e.accepted_cases),0) AS po_units,
COALESCE(MAX(f.`reviews_count`),0) AS reviews_count,
COALESCE(MAX(f.`average_review`),0.00) AS reviews_score,
t.batchid 
FROM
(
SELECT DISTINCT account_id AS account_id, ASIN,batchid FROM `prst_tbl_ams_product` WHERE batchid = `max_date`
UNION
SELECT DISTINCT  fk_account_id AS account_id, ASIN,batchid FROM `prst_vew_inventory_table`  WHERE batchid = `max_date`
UNION
SELECT DISTINCT account_id AS account_id, ASIN,batchid FROM `prst_tbl_purchase_order`  WHERE batchid = `max_date`
UNION
SELECT DISTINCT account_id AS account_id, ASIN,DATE_FORMAT(capture_date,'%Y%m%d') AS batchid FROM `prst_tbl_scraping`
WHERE DATE_FORMAT(capture_date,'%Y%m%d') = `max_date`
UNION
SELECT DISTINCT fk_account_id AS account_id, ASIN,batchid FROM `prst_vew_product_table` WHERE batchid = `max_date`
)t
LEFT JOIN `prst_tbl_ams_product` b ON (t.asin = b.asin AND t.account_id = b.account_id AND t.batchid = b.batchid)
LEFT JOIN `prst_vew_product_table`  c ON (t.asin = c.asin AND t.account_id = c.fk_account_id AND t.batchid = c.batchid)
LEFT JOIN  prst_vew_inventory_table  d ON (t.asin = d.asin AND t.account_id = d.fk_account_id AND t.batchid = d.batchid)
LEFT JOIN `prst_tbl_purchase_order`  e ON (t.asin = e.asin AND t.account_id = e.account_id AND t.batchid = e.batchid)
LEFT JOIN `prst_tbl_scraping`  f ON (t.asin = f.asin AND t.account_id = f.account_id AND DATE_FORMAT(t.batchid, '%Y-%m-%d') = f.capture_date)
GROUP BY t.account_id , t.asin, t.batchid ,
REPLACE(COALESCE(c.product_title,'N/A'), 'NA', 'N/A'),
REPLACE(COALESCE(c.`fullfillment_channel`,'N/A'), 'NA', 'N/A')
;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateProductMasterTempTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateProductMasterTempTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
 COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateDateLevelPOValidationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateDateLevelPOValidationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateDateLevelPOValidationTable`(IN max_date VARCHAR(20))
    SQL SECURITY INVOKER
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
   SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
    -- WARNING
  --  SELECT 
    --  "Warning by DB" ;
   -- SET `_rollback` = 1 ;
   -- ROLLBACK;
 -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
DELETE FROM vald_date_purchaseorders WHERE  batchid = max_date;
INSERT INTO vald_date_purchaseorders
   (  fact_total_cost
    , stage_total_cost
    , diff_total_cost
    , fact_accepted_case_cost
    , stage_accepted_case_cost
    , diff_accepted_case_cost
    , fact_rejected_case_cost
    , stage_rejected_case_cost
    , diff_rejected_case_cost
    , fact_total_po_cost
    , stage_total_po_cost
    , diff_total_po_cost
    , batchid
   )
(SELECT
a.TotalCost AS fact_total_cost
,b.TotalCost AS stage_total_cost
,a.TotalCost-b.TotalCost AS diff_total_cost
,a.AcceptedCases AS fact_accepted_case_cost
,b.AcceptedCases AS stage_accepted_case_cost
,a.AcceptedCases - b.AcceptedCases  AS diff_accepted_case_cost
,a.RejectedCases AS fact_rejected_case_cost
,b.RejectedCases AS stage_rejected_case_cost
,a.RejectedCases - b. RejectedCases AS diff_rejected_case_cost
,a.TotalPOCost AS fact_total_po_cost
,b.TotalPOCost  AS stage_total_po_cost
,a.TotalPOCost - b.TotalPOCost AS diff_total_po_cost
,a.batchid
FROM 
(SELECT
  SUM(`total_cost`) AS TotalCost,
  SUM(`accepted_case`) AS AcceptedCases,
  SUM(`rejected_case`) AS RejectedCases,
  SUM(`total_po_cost`) AS TotalPOCost
 ,batchid
FROM `replica_adtec_bi`.`fact_purchaseorder`
WHERE  batchid = max_date
	GROUP BY 
	batchid
)a
INNER JOIN
(
SELECT
  SUM(`total_cost`) AS TotalCost,
  SUM(`accepted_case`) AS AcceptedCases,
  SUM(`rejected_case`) AS RejectedCases,
  SUM(`total_po_cost`) AS TotalPOCost,
 LEFT(`batchid`,8)   AS batchid
  FROM
  `replica_adtec_bi`.`stage_purchaseorder_master`
  GROUP BY 
  LEFT(`batchid`,8)
)b
ON a.batchid=b.batchid)
;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelPOValidationTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ROLLBACK;
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateDateLevelPOValidationTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  COMMIT;
  END
  IF;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePresentationYTDTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePresentationYTDTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePresentationYTDTable`()
BEGIN
    
    DECLARE `_rollback` BOOL DEFAULT 0 ;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  
  START TRANSACTION ;
  SET autocommit = 0 ;
 
INSERT INTO replica_adtec_bi.`prst_vew_peformance_ytd` 
(
profile_id,
profile_name,
`account_name`,
`account_id`,
`cost`,
`revenue`,
`acos`
)
SELECT
 profile_id,
 profile_name,
`account_name`,
`accouint_id`,
`cost`,
`revenue`,
CASE WHEN revenue > 0 THEN  ROUND(((  `cost` / `Revenue`)*100),2) ELSE 0.00 END AS acos_
 FROM
(
SELECT
 profile_id,
 profile_name,
 `account_name`,
 `accouint_id`,
 COALESCE(SUM( `cost`),0) cost,
 COALESCE(SUM(`revenue`),0) revenue
 
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
DATE_FORMAT(batchid,"%Y-%m-%d") >=   DATE_FORMAT(CURRENT_DATE(), '%Y-01-01') 
AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(CURRENT_DATE(), "%Y%m%d")
GROUP BY  profile_id,profile_name,`account_name`,`accouint_id`
)t;
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulatePresentationYTDTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulatePresentationYTDTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spProfilemapping` */

/*!50003 DROP PROCEDURE IF EXISTS  `spProfilemapping` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spProfilemapping`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
 -- BEGIN
    -- ERROR
 --   SELECT 
 --     "Syntax Error" ;
 --   SET `_rollback` = 1 ;
  --  ROLLBACK ;
 -- END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
INSERT INTO `replica_adtec_bi`.`map_ams_profile`
SELECT DISTINCT NULL,`profile_id`,profile_name AS `fk_profile_name` FROM `replica_adtec_bi`.`stage_ams_profile`
WHERE `profile_id` NOT IN (SELECT DISTINCT `Profile_id` FROM `replica_adtec_bi`.`map_ams_profile`);
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spProfilemapping',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spProfilemapping',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spStageLayerTruncate` */

/*!50003 DROP PROCEDURE IF EXISTS  `spStageLayerTruncate` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spStageLayerTruncate`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
TRUNCATE TABLE replica_adtec_bi.`stage_account_client`;
TRUNCATE TABLE replica_adtec_bi.`stage_ams_profile`;
TRUNCATE TABLE replica_adtec_bi.`stage_sales_master`;
TRUNCATE TABLE replica_adtec_bi.`stage_inventory_master`;
TRUNCATE TABLE replica_adtec_bi.`stage_purchaseorder_master`;
TRUNCATE TABLE replica_adtec_bi.`stage_product_catalog`;
TRUNCATE TABLE replica_adtec_bi.`stage_asin_tags`;
TRUNCATE TABLE replica_adtec_bi.`stage_campaign`;
TRUNCATE TABLE replica_adtec_bi.`stage_adgroup`;
TRUNCATE TABLE replica_adtec_bi.`stage_keyword`;
TRUNCATE TABLE replica_adtec_bi.`stage_product_ads`;
TRUNCATE TABLE replica_adtec_bi.`stage_ams_asin`;
TRUNCATE TABLE replica_adtec_bi.`stage_scraping`;
TRUNCATE TABLE replica_adtec_bi.`stage_purchaseorder_master`;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spStageLayerTruncate',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spStageLayerTruncate',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAsinLevelEfficiency` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAsinLevelEfficiency` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAsinLevelEfficiency`(IN startdate DATE
									  ,IN enddate DATE
									  ,IN pro_id BIGINT
									  ,IN camp_id varchar(2000)
									  ,IN asin_ varchar(50)
									  )
BEGIN
SELECT
  DATE_FORMAT(`date_key`,"%Y-%m-%d") AS date_key,
  CASE
        WHEN SUM(clicks) > 0 
        THEN COALESCE(ROUND(SUM(cost) / SUM(clicks), 2),0.00) 
        ELSE 0.00 
      END AS cpc,
         CASE
        WHEN SUM(cost) > 0 
        THEN COALESCE(ROUND(SUM(revenue) /SUM(cost), 2),0.00) 
        ELSE 0.00 
      END AS roas,
       CASE
        WHEN SUM(order_conversion) > 0 
        THEN COALESCE(ROUND(SUM(cost) /SUM(order_conversion), 2),0.00) 
        ELSE 0.00 
      END AS cpa
    
FROM `replica_adtec_bi`.`prst_tbl_ams_product`
WHERE 
(profile_id = pro_id)
AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All' )
AND (ASIN = asin_)
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d")
group by DATE_FORMAT(`date_key`,"%Y-%m-%d")
ORDER BY date_key
; 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateCampaignEfficiency` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateCampaignEfficiency` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateCampaignEfficiency`(IN startdate DATE
									  ,IN enddate DATE
									  ,IN pro_id BIGINT
									  ,IN campaignid VARCHAR(2000)
									  )
BEGIN
SELECT
 
  Date_Format(`date_key`,"%Y-%m-%d") As date_key,
  CASE
        WHEN SUM(clicks) > 0 
        THEN COALESCE(ROUND(SUM(cost) / SUM(clicks), 2),0.00) 
        ELSE 0.00 
      END AS cpc,
         CASE
        WHEN SUM(cost) > 0 
        THEN COALESCE(ROUND(SUM(revenue) /SUM(cost), 2),0.00) 
        ELSE 0.00 
      END AS roas,
       CASE
        WHEN SUM(order_conversion) > 0 
        THEN COALESCE(ROUND(SUM(cost) /SUM(order_conversion), 2),0.00) 
        ELSE 0.00 
      END AS cpa
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
profile_id = pro_id 
AND (campaignid =  'All' OR FIND_IN_SET(`campaign_id`,`campaignid` ))
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d")
GROUP BY 
  DATE_FORMAT(`date_key`,"%Y-%m-%d")
  ORDER BY date_key
; 
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateCampaignAwareness` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateCampaignAwareness` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateCampaignAwareness`(IN startdate DATE,IN enddate DATE,IN pro_id BIGINT,IN campaignid Varchar(2000))
BEGIN
select
  DATE_FORMAT(`date_key`,"%Y-%m-%d") AS date_key,
  COALESCE(SUM(`impressions`),0) as `impressions`,
  COALESCE(SUM(`clicks`),0) as `clicks`,
   CASE
    WHEN 
    SUM(`impressions`) > 0 
    THEN
    COALESCE(ROUND ((SUM(`clicks`) / SUM(`impressions`)*100),2),0.00)
       ELSE 0.00 
       END  AS CTR
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE 
profile_id = pro_id 
AND (`campaignid`= 'All'  OR FIND_IN_SET(`campaign_id` , `campaignid`))
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d")
Group by
DATE_FORMAT(`date_key`,"%Y-%m-%d")
ORDER BY date_key
;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAMSAwarenessAsinLevel` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAMSAwarenessAsinLevel` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAMSAwarenessAsinLevel`(IN startdate DATE
									                                ,IN enddate DATE
									                                ,IN pro_id BIGINT
									                                ,IN camp_id VARCHAR(2000)
									                                ,IN asin_ VARCHAR(50))
BEGIN
SELECT
	DATE_FORMAT(`date_key`,"%Y-%m-%d") AS date_key,
COALESCE(SUM(`impressions`),0) AS `impressions`,
  COALESCE(SUM(`clicks`),0) AS `clicks`,
   CASE
    WHEN 
    sum(`impressions`) > 0 
    THEN
      COALESCE(ROUND(  sum(`clicks`)/ sum(`impressions`),2),0.00)
       ELSE 0.00 
       END  AS CTR
FROM
	`replica_adtec_bi`.`prst_tbl_ams_product`
WHERE
	(profile_id = pro_id )
        AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All' )
        AND (ASIN = asin_)
	AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
	AND DATE_FORMAT(batchid,"%Y-%m-%d") <= DATE_FORMAT(enddate,"%Y-%m-%d")
	Group by
	DATE_FORMAT(`date_key`,"%Y-%m-%d")
	ORDER BY date_key
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAsinPerformance` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAsinPerformance` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAsinPerformance`(IN startdate DATE
									    ,IN enddate DATE
									    ,IN pro_id BIGINT
									    ,IN camp_id VARCHAR(2000)
									    ,IN asin_ varchar(50))
BEGIN
SELECT
  DATE_FORMAT(`date_key`,"%Y-%m-%d") AS date_key,
  COALESCE(ROUND(SUM(`cost`),2),0.00) AS cost,
  COALESCE(ROUND(SUM(`revenue`),2),0.00) AS revenue	,
  CASE
   WHEN
     SUM(`revenue`) > 0 
     THEN 
       COALESCE(ROUND (SUM(`cost`) / SUM(`revenue`),2),0.00)
    ELSE
     0.00 
     END AS `acos`
 
FROM `replica_adtec_bi`.`prst_tbl_ams_product`
WHERE 
(profile_id = pro_id )
AND  (FIND_IN_SET (`campaign_id`,`camp_id`) OR `camp_id` = 'All')
AND (asin = asin_ )
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(startdate,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(enddate,"%Y-%m-%d")
GROUP BY
 DATE_FORMAT(`date_key`,"%Y-%m-%d")
 ORDER BY date_key
;
  
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateCampaignPerformance` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateCampaignPerformance` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateCampaignPerformance`(IN `start_date` VARCHAR(20)
,IN `end_date` VARCHAR(20)
,IN `pro_id`   BIGINT
,IN `camp_id`  VARCHAR(2000))
BEGIN
SELECT
  DATE_FORMAT(`date_key`,"%Y-%m-%d") AS date_key,
  COALESCE(ROUND(SUM(`cost`),2),0.00) as cost,
  COALESCE(ROUND(SUM(`revenue`),2),0.00) as revenue	,
  CASE
   WHEN
     SUM(`revenue`) > 0 
     THEN 
        COALESCE(ROUND ((SUM(`cost`) / SUM(`revenue`)*100),2),0.00)
    ELSE
     0.00 
     END AS `acos`
FROM `replica_adtec_bi`.`prst_tbl_ams_campaign`
WHERE (`camp_id`= 'All'  OR FIND_IN_SET(`campaign_id` , `camp_id`))
   AND `profile_id`  = `pro_id`
AND DATE_FORMAT(batchid,"%Y-%m-%d") >= DATE_FORMAT(start_date,"%Y-%m-%d")
AND DATE_FORMAT(batchid,"%Y-%m-%d")  <= DATE_FORMAT(end_date,"%Y-%m-%d")
group By
 DATE_FORMAT(`date_key`,"%Y-%m-%d")
 ORDER BY date_key
;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPresentationLayerTruncate` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPresentationLayerTruncate` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPresentationLayerTruncate`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
  
	-- Truncate all Presentation Layer Tables
	TRUNCATE TABLE replica_adtec_bi.prst_tbl_sales_asin_weekly;
	/* DELETE FROM replica_adtec_bi.prst_vew_product_table       WHERE  batchid =  `max_date`;
	DELETE FROM replica_adtec_bi.prst_vew_inventory_table     WHERE  batchid =  `max_date`;
	DELETE FROM replica_adtec_bi.prst_tbl_ams_campaign        WHERE  batchid  = `max_date`;
	DELETE FROM replica_adtec_bi.prst_tbl_ams_adgroup         WHERE  batchid  = `max_date`;
	DELETE FROM replica_adtec_bi.prst_tbl_ams_keyword         WHERE  batchid  = `max_date`;
	DELETE FROM replica_adtec_bi.prst_tbl_ams_product         WHERE  batchid  = `max_date`;
	DELETE FROM replica_adtec_bi.prst_tbl_ams_asins           WHERE  batchid  = `max_date`;
	*/
	
	
	
	
	TRUNCATE TABLE replica_adtec_bi.prst_vew_performance_pre30dayTable;
	TRUNCATE TABLE replica_adtec_bi.prst_tbl_sales_asin_monthly;
	TRUNCATE TABLE replica_adtec_bi.`prst_vew_peformance_ytd`;
        TRUNCATE TABLE replica_adtec_bi.prst_vew_performance_pre30dayTable_grand_total;
        TRUNCATE TABLE replica_adtec_bi.tbl_prst_vew_peformance_ytd_grand_total;	
	
	
	-- Commit if no warning and error else roolback and put them into ETL Logs
  
	IF `_rollback` THEN
		insert into `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		values (
			NULL
			,'spPresentationLayerTruncate'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPresentationLayerTruncate'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageAccountClientTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageAccountClientTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageAccountClientTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
 
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  INSERT INTO replica_adtec_bi.`stage_account_client`
SELECT
    NULL 
  , agency_id
  , Agency_Name
  , client_id
  , client_name
  , client_email
  , client_account_password
  , client_creation
  , client_updation
  , account_id
  , marketplaceid
  , account_type
  , account_type_name
  , fkId
  , accountName
  , account_creation
  , account_updation
  , LoadDate
FROM
	replica_adtec.`tbl_rtl_account_client`
;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageAccountClientTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageAccountClientTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  END
  IF;
  IF `_rollback` THEN
  ROLLBACK;
  ELSE
  COMMIT;
  END
  IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageAMSAdgroupTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageAMSAdgroupTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageAMSAdgroupTable`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
 BEGIN
    -- ERROR
  SELECT 
     "Syntax Error" ;
  SET `_rollback` = 1 ;
  ROLLBACK ;
 END ;
 
   
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
 
 
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.stage_adgroup
(
  `fk_batch_id`,
  `fk_account_id`,
  `fk_profile_id`,
  `profile_name`,
  `campaign_id`,
  `campaign_name`,
  `adgroup_id`,
  `adgroup_name`,
  `campaign_type`,
  `impressions`,
  `clicks`,
  `cost`,
  `conversions`,
  `conversions_same_sku`,
  `unit_ordered`,
  `sales`,
  `sales_same_sku`,
  `report_date`,
  `creation_date`
)
SELECT
     `fkBatchId`
    , `fkAccountId`
    , `fkProfileId`
    , `profile_name`
    , `campaignId`
    , `campaignName`
    , `adGroupId`
    , `adGroupName`
    , `report_type`
    , `impressions`
    , `clicks`
    , `cost`
    , `attributedConversions`
    , `attributedConversionsSameSKU`
    , `attributedUnitsOrdered`
    , `attributedSales`
    , `attributedSalesSameSKU`
    , `reportDate`
    , `creationDate`
FROM
   `replica_adtec`.`tbl_rtl_ams_adgroup`
;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageAMSAdgroupTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageAMSAdgroupTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  END
  IF;
  IF `_rollback` THEN
  ROLLBACK;
  ELSE
  COMMIT;
  END
  IF;
  
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageAMSAsinTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageAMSAsinTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageAMSAsinTable`()
BEGIN
  
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
INSERT INTO `replica_adtec_bi`.`stage_ams_asin`
            (`id`,
             `fkBatchId`,
             `fkAccountId`,
             `fkProfileId`,
             `profile_name`,
             `campaignid`,
             `campaignname`,
             `adGroupid`,
             `adGroupname`,
             `keywordid`,
             `keywordtext`,
             `asin`,
             `other_asin`,
             `sku`,
             `currency`,
             `matchtype`,
              campaign_type,
             `attributedUnitsOrdered`,
             `sales_other_sku`,
             `units_ordered_other_sku`,
             `reportdate`,
             `creationdate`)
SELECT
  `id`,
  `fkBatchId`,
  `fkAccountId`,
  `fkProfileId`,
  `profile_name`,
  `campaignId`,
  `campaignName`,
  `adGroupId`,
  `adGroupName`,
  `keywordId`,
  `keywordText`,
  `asin`,
  `otherAsin`,
  `sku`,
  `currency`,
  `matchType`,
  report_type,
  `attributedUnitsOrdered`,
  `attributedSalesOtherSKU`,
  `attributedUnitsOrderedOtherSKU`,
  `reportDate`,
  `creationDate`
FROM `replica_adtec`.`tbl_rtl_ams_asin` ;
/* end of script   */
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageAMSAsinTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageAMSAsinTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageAMSCampaignTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageAMSCampaignTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageAMSCampaignTable`()
BEGIN
  
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
   END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
    -- SET `_rollback` = 1 ;
    -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
INSERT INTO `replica_adtec_bi`.stage_campaign
SELECT 	Null,
	
	fkBatchId,
	fkAccountId,
	fkProfileId,
	profile_name,
	campaignId,
	campaignName,
	campaignStatus,
	campaignBudget,
	campaign_Budget_Type,
	campaign_type,
	impressions,
	clicks,
	cost,
	attributedConversions,
	attributedConversionsSameSKU,
	attributedUnitsOrdered,
	attributedSales,
	attributedSalesSameSKU,
	reportDate,
	creationDate
	 FROM `replica_adtec`.tbl_rtl_ams_campaign;
/* end of script   */
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageAMSCampaignTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageAMSCampaignTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageAMSProdAdsTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageAMSProdAdsTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageAMSProdAdsTable`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
 BEGIN
    -- ERROR
  SELECT 
     "Syntax Error" ;
  SET `_rollback` = 1 ;
  ROLLBACK ;
 END ;
 
   
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
 
 
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.`stage_product_ads`
(
      `fk_batch_id`                      
    , `fk_account_id`                 
    , `fk_profile_id`                 
    , `profile_name`                  
    , `campaign_id`                   
    , `campaign_name`                 
    , `adgroup_id`                    
    , `adgroup_name`                  
    , `campaign_type`                   
	, `ad_id`                         
	, `asin`                          
	, `sku`                           
    , `impressions`                   
    , `clicks`                        
    , `cost`                          
    , `conversions`                   
    , `conversions_same_sku`          
    , `unit_ordered`                  
    , `sales`                         
    , `sales_same_sku`                
    , `unit_ordered_same_sku`         	
    , `report_date`                   
    , `creation_date` 
)
SELECT
      `fkBatchId`                      
    , `fkAccountId`                   
    , `fkProfileId`                   
    , `profile_name`                  
    , `campaignId`                    
    , `campaignName`                  
    , `adGroupId`                     
    , `adGroupName`                   
    , `report_type`                   
    , `adId`                          
    , `asin`                          
    , `sku`                           
    , `impressions`                   
    , `clicks`                        
    , `cost`                          
    , `attributedConversions`         
    , `attributedConversionsSameSKU`  
    , `attributedUnitsOrdered`        
    , `attributedSales`               
    , `attributedSalesSameSKU`        
    , `attributedUnitsOrderedSameSKU` 
    , `reportDate`                    
    , `creationDate`      
FROM
   `replica_adtec`.`tbl_rtl_ams_product_ads`;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageAMSProdAdsTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageAMSProdAdsTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  END
  IF;
  IF `_rollback` THEN
  ROLLBACK;
  ELSE
  COMMIT;
  END
  IF;
  
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageAMSProfileTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageAMSProfileTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageAMSProfileTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
 
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  INSERT INTO replica_adtec_bi.`stage_ams_profile`
SELECT
    NULL 
  , profile_id
  , profile_name
  , isActive
  
FROM
	replica_adtec.`tbl_rtl_ams_profile`
;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageAMSProfileTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageAMSProfileTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  END
  IF;
  IF `_rollback` THEN
  ROLLBACK;
  ELSE
  COMMIT;
  END
  IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageAsinsTags` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageAsinsTags` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageAsinsTags`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
  INSERT INTO replica_adtec_bi.`stage_asin_tags`
SELECT 	Null,
	
	fkAccountId,
	ASIN,
	fkTagId,
	tag,
	fullFillmentChannel,
	uniqueColumn,
	createdAt,
	updatedAt
	 FROM replica_adtec.`tbl_asin_tags`;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageAsinsTags',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageAsinsTags',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageInventoryMasterTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageInventoryMasterTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageInventoryMasterTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING  
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
INSERT INTO replica_adtec_bi.`stage_inventory_master`
SELECT null,
	
	fk_account_id,
	asins,
	sku,
	`fulfillment_channel`,
	seller_inv_units,
	unseller_inv_units,
	capture_date,
	batchid,
	LoadDate
	 FROM replica_adtec.`tbl_rtl_inventory_master`;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageInventoryMasterTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageInventoryMasterTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageManagerTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageManagerTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageManagerTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
 
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  INSERT INTO replica_adtec_bi.`stage_manager`
SELECT
	NULL ,
	`Manager_id`,
	`Brand_id`,
	`Manager_name`,
	`created_at`,
	`updated_at`,
	`deleted_at`
FROM
	replica_adtec.`tbl_rtl_manager`
;
  IF `_rollback` THEN
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageManagerTable'
      , 'RollBack'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  ELSE
  INSERT INTO `replica_adtec_bi`.`etl_logs`
     ( `log_id`
      , `Stored_Procedure_Name`
      , `Execution_status`
      , `LogDate`
     )
     VALUES
     ( NULL
      , 'spPopulateStageManagerTable'
      , 'Commit'
      , CURRENT_TIMESTAMP()
     )
  ;
  
  END
  IF;
  IF `_rollback` THEN
  ROLLBACK;
  ELSE
  COMMIT;
  END
  IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageProductCatalogTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageProductCatalogTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageProductCatalogTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
  INSERT INTO replica_adtec_bi.`stage_product_catalog`
SELECT 	Null,
	
	fk_account_id,
	last_refresh,
	ASIN,
	sku,
	model,
	fulfillment_channel,
	sc_status,
	vc_status,
	upc,
	release_date,
	color,
	size,
	price,
	product_width,
	product_length,
	product_height,
	product_ship_weight,
	brand,
	manufacturer,
	binding,
	product_group,
	product_type,
	product_title,
	parent_asins,
	category_id,
	category_name,
	subcategory_id,
	subcategory_name,
	salesrank,
	capture_date,
	batchid,
	LoadDate
	 FROM replica_adtec.`tbl_rtl_product_catalog`
;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageProductCatalogTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageProductCatalogTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStagePurchaseOrderMasterTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStagePurchaseOrderMasterTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStagePurchaseOrderMasterTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
INSERT INTO replica_adtec_bi.`stage_purchaseorder_master`
SELECT 
Null,
fk_account_id,
po,
hand_off_type,
ship_location,
model_number,
asins,
sku,
title,
po_status,
delivery_window_start,
delivery_window_end,
backorder,
expected_ship_date,
confirmed_ship_date,
case_size,
submitted_cases,
accepted_cases,
received_cases,
outstanding_cases,
str_case_cost,
str_total_cost,
order_date,
case_cost,
total_cost,
accepted_case,
rejected_case,
total_po_cost,
capture_date,
batchid,
LoadDate
 FROM replica_adtec.`tbl_rtl_purchaseorder_master`;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStagePurchaseOrderMasterTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStagePurchaseOrderMasterTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageSalesMasterTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageSalesMasterTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageSalesMasterTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
INSERT INTO replica_adtec_bi.`stage_sales_master`
SELECT  Null,
	
	fk_account_id,
	ASIN,
	fulfillment_channel,
	sku,
	shipped_cogs,
	shipped_unit,
	shipped_cogs_last_year,
	shipped_units_last_year,
	capture_date,
	batchid,
	LoadDate
	 FROM replica_adtec.`tbl_rtl_sale_master`;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageSalesMasterTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageSalesMasterTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageScrapingTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageScrapingTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageScrapingTable`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
INSERT INTO replica_adtec_bi.`stage_scraping`
SELECT 
Null,
         account_id
       , `asin`
       , total_reviews
       , reviews_count
       , average_review 
    , `capture_date`
    , `LoadDate`
 FROM replica_adtec.`tbl_rtl_scraping`;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageScrapingTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateStageScrapingTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimAdgroup` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimAdgroup` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimAdgroup`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.`dim_adgroup`
SELECT
   NULL
 , bb.camp_type_key
 , cc.profile_key
 , aa.`campaign_id`
 , aa.`campaign_name`
 , aa.`adGroup_Id`
 , aa.`adGroup_Name`
 , CURRENT_DATE() AS load_date
 , aa.campaign_type
FROM
   `replica_adtec_bi`.`stage_adgroup` aa
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_report_type` bb
      ON
         (
            aa.`campaign_type` = bb.camp_type
         )
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_profile` cc
      ON
         (
            aa.`fk_Profile_Id` = cc.profile_id
         )
   LEFT OUTER JOIN
      `replica_adtec_bi`.`dim_adgroup` dd
      ON
         (
            aa.campaign_Id = dd.campaign_id AND aa.`adGroup_Id` = dd.`adgroup_id`  AND aa.campaign_type = dd.campaign_type
         )
WHERE
   dd.campaign_name IS NULL
  
;
 
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimAdgroup'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimAdgroup'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimCampaign` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimCampaign` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimCampaign`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  /*
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  */
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
  
INSERT INTO `replica_adtec_bi`.`dim_campaign`
SELECT
   NULL
 , bb.camp_type_key
 , cc.profile_key
 , aa.`campaign_id`
 , aa.`campaign_name`
 , aa.`campaign_status`
 , aa.`campaign_budget_type`
 , CURRENT_TIMESTAMP() AS load_date
 ,aa.campaign_type
FROM
   `replica_adtec_bi`.`stage_campaign` aa
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_report_type` bb
      ON
         (
            aa.`campaign_type` = bb.camp_type
         )
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_profile` cc
      ON
         (
            aa.`fk_profile_id` = cc.profile_id
         )
   LEFT OUTER JOIN
      `replica_adtec_bi`.`dim_campaign` dd
      ON
         (
            aa.campaign_id = dd.campaign_id AND aa.campaign_type = dd.campaign_type
         )
WHERE
   dd.campaign_name IS NULL
   -- OR (dd.camp_type_key <> bb.camp_type_key )
;
 

   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimCampaign'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimCampaign'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
  
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spMasterETL` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMasterETL` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMasterETL`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	
      
	CALL `replica_adtec_bi`.spStageLayerTruncate();
	CALL `replica_adtec_bi`.spPopulateStageAccountClientTable();
	CALL `replica_adtec_bi`.spPopulateStageAMSProfileTable();
	CALL `replica_adtec_bi`.spPopulateStageSalesMasterTable();
	CALL `replica_adtec_bi`.spPopulateStageInventoryMasterTable();
	CALL `replica_adtec_bi`.spPopulateStageProductCatalogTable();
	CALL `replica_adtec_bi`.spPopulateStageAsinsTags();
	CALL `replica_adtec_bi`.spPopulateStageAMSCampaignTable();
	CALL `replica_adtec_bi`.spPopulateStageAMSAdgroupTable();
	CALL `replica_adtec_bi`.spPopulateStageAMSKeywordTable(`max_date`);
	CALL `replica_adtec_bi`.spPopulateStageAMSProdAdsTable();
	CALL `replica_adtec_bi`.`spPopulateStagePurchaseOrderMasterTable`();
	CALL `replica_adtec_bi`.`spPopulateStageScrapingTable`();
	CALL `replica_adtec_bi`.spPopulateStageAMSAsinTable();
	
	
	--  DWH Layer 1 Populate Dimensions
	CALL `replica_adtec_bi`.spPopulateClientDimTable();
	
        --	
	CALL `replica_adtec_bi`.spExpireExistingAccount();
	CALL `replica_adtec_bi`.spNewRowForChangingAccount();
	CALL `replica_adtec_bi`.spAddNewAccountDimension();
	
	--
	CALL `replica_adtec_bi`.spUpdateDimProductMaster();
	CALL `replica_adtec_bi`.spAddNewRecordDimProductMaster();
	
	--
	CALL `replica_adtec_bi`.spExpireExistingProductCategory();
	CALL `replica_adtec_bi`.spUpNewRowForChangingProductCategory();
	CALL `replica_adtec_bi`.spAddNewRecordDimProductCategoryMaster();
	
	-- Mapping tables
	CALL `replica_adtec_bi`.spProfilemapping();
        CALL `replica_adtec_bi`.spCampaignMapping();	
   --     call `replica_adtec_bi`.`spPopulateMapCampTagingDailyTable`();
	
	-- 
	CALL `replica_adtec_bi`.`spUpdateDimCampiagn`();
	CALL `replica_adtec_bi`.`spAddNewRecordDimCampaign`();
	
	--
	CALL `replica_adtec_bi`.`spAddNewRecordDimAdgroup`();
	
	--
	-- CALL `replica_adtec_bi`.`spUpdateDimKeyword`();
	CALL `replica_adtec_bi`.`spAddNewRecordDimKeyword`();
	
		
	--
	CALL `replica_adtec_bi`.`spAddNewRecordDimProduct`();
	
	--
	CALL `replica_adtec_bi`.`spAddNewRecordDimAsins`();
        --
        
        CALL `replica_adtec_bi`.`spAddNewRecordDimPurchaseOrder`();
        
        --
        
        CALL `replica_adtec_bi`.`spAddNewRecordDimScraping`();	
   	
	
	
	
	--  DWH Layer 1 Populate Fact
	CALL `replica_adtec_bi`.spPopulateFactSaleMaster(`max_date`);
	CALL `replica_adtec_bi`.spPopulateFactInventoryMaster(`max_date`);
	CALL `replica_adtec_bi`.spPopulateCampaignFactTable(`max_date`);
	CALL `replica_adtec_bi`.spPopulateAdgroupFactTable(`max_date`);
	CALL `replica_adtec_bi`.spPopulateKeywordFactTable(`max_date`);
	CALL `replica_adtec_bi`.spPopulateProductFactTable(`max_date`);
	CALL `replica_adtec_bi`.spPopulateAsinsFactTable(`max_date`);
	CALL `replica_adtec_bi`.`spPopulatePurchaseOrderFactTable`(`max_date`);
	CALL `replica_adtec_bi`.`spPopulateFactScraping`(`max_date`);
	
	
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spMasterETL'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spMasterETL'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimProduct` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimProduct` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimProduct`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.`dim_product`
SELECT
   NULL
 , bb.camp_type_key
 , cc.profile_key
 , aa.`campaign_id`
 , aa.`campaign_name`
 , aa.`adGroup_Id`
 , aa.`adGroup_Name`
 , aa.`ad_id`
 , COALESCE(aa.`asin`) ASIN
 , COALESCE(aa.`sku`) sku
 , CURRENT_DATE() AS load_date
 , aa.campaign_type
FROM
   `replica_adtec_bi`.`stage_product_ads` aa
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_report_type` bb
      ON
         (
            aa.`campaign_type` = bb.camp_type
         )
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_profile` cc
      ON
         (
            aa.`fk_Profile_Id` = cc.profile_id
         )
   LEFT OUTER JOIN
      `replica_adtec_bi`.`dim_product` dd
      ON
         (
            aa.campaign_Id = dd.campaign_id AND aa.`adGroup_Id` = dd.`adgroup_id`  AND aa.`ad_id` = dd.`ad_id` and aa.campaign_type = dd.campaign_type
            AND aa.`asin` = dd.`asin` AND aa.`sku` = dd.`sku`
         )
WHERE
   dd.campaign_name IS NULL
  
;
 
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimProduct'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimProduct'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimAsins` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimAsins` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimAsins`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ;
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.`dim_asins`
SELECT
   NULL
 , bb.camp_type_key
 , cc.profile_key
 , aa.`campaignid`
 , aa.`campaignname`
 , aa.`adGroupId`
 , aa.`adGroupName`
 , aa.`keywordId`
 , aa.`keywordText`
 , aa.`asin`
 , aa.`other_asin`
 , aa.`sku`
 , aa.`currency`
 , aa.`matchType`
 , CURRENT_DATE() AS load_date
 , aa.campaign_type 
FROM
   `replica_adtec_bi`.`stage_ams_asin` aa
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_report_type` bb
      ON
         (
            aa.`campaign_type` = bb.camp_type
         )
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_profile` cc
      ON
         (
            aa.`fkProfileId` = cc.profile_id
         )
   LEFT OUTER JOIN
      `replica_adtec_bi`.`dim_asins` dd
      ON
         (
            aa.campaignId = dd.campaign_id AND aa.`adGroupId` = dd.`adgroup_id` AND aa.`keywordId` = dd.`keyword_id`
            AND aa.`asin` = dd.`asin`  AND aa.`other_asin` = dd.`other_asin`  AND aa.`sku` = dd.`sku` AND aa.`currency` = dd.`currency`
            AND aa.`matchType` = dd.`match_type` and aa.campaign_type = dd.campaign_type
         )
WHERE
   dd.campaign_name IS NULL
  
;
 
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimAsins'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimAsins'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAdgroupFactTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAdgroupFactTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAdgroupFactTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
-- DELETE FROM replica_adtec_bi.`fact_ams_adgroup`  WHERE batchid = `max_date`;
INSERT INTO replica_adtec_bi.`fact_ams_adgroup` 
SELECT
  
  
   cc.`Client_Key` ,
   bb.`Account_Key`,
   dd.date_key,
   ee.`adgroup_key`,
   `impressions`,
   `clicks`,
    `cost`,
   unit_ordered AS `attributedunitsordered`,
   sales AS `attributedsales`,
   LEFT(aa.`fk_Batch_Id`, 8) AS batchId ,
   aa.`creation_Date` AS capture_date,
   CURRENT_DATE() AS `LoadDate`
 
FROM `replica_adtec_bi`.`stage_adgroup` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb  ON (aa.`fk_Account_Id` = bb.`Account_ID` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_brand`   cc  ON (bb.`Client_ID` = cc.`Client_key` )
LEFT JOIN replica_adtec_bi.`dim_date`    dd  ON (dd.full_date = aa.`report_Date` )
LEFT JOIN replica_adtec_bi.`map_ams_report_type` ff ON (ff.`camp_type` = aa.`campaign_type`)
LEFT JOIN replica_adtec_bi.`dim_adgroup` ee ON (ee.`campaign_id` = aa.`campaign_Id` AND ee.`camp_type_key` = ff.`camp_type_key` AND ee.`adgroup_id` = aa.`adGroup_Id` )
;
 
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAdgroupFactTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAdgroupFactTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateAsinsFactTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateAsinsFactTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateAsinsFactTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
-- DELETE FROM replica_adtec_bi.`fact_ams_asins`  WHERE batchid = `max_date` ;
INSERT INTO replica_adtec_bi.`fact_ams_asins`
SELECT
  
  
   cc.`Client_Key` ,
   bb.`Account_Key`,
   dd.date_key,
   ee.`asins_key`,
  `attributedunitsordered`,
  `sales_other_sku`,
  `units_ordered_other_sku`,  
   LEFT(aa.`fkBatchId`, 8) AS batchId ,
   aa.`creationDate` AS capture_date,
   CURRENT_DATE() AS `LoadDate`
 
FROM `replica_adtec_bi`.`stage_ams_asin` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb  ON (aa.`fkAccountId` = bb.`Account_ID` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_brand`   cc  ON (bb.`Client_ID` = cc.`Client_key` )
LEFT JOIN replica_adtec_bi.`dim_date`    dd  ON (dd.full_date = aa.`reportDate` )
LEFT JOIN replica_adtec_bi.`map_ams_report_type` ff ON (ff.`camp_type` = aa.`campaign_type`)
LEFT JOIN replica_adtec_bi.`dim_asins` ee ON (ee.`campaign_id` = aa.`campaignId` AND ee.`camp_type_key` = ff.`camp_type_key`
AND ee.`adgroup_id` = aa.`adGroupId` AND ee.`keyword_id` = aa.`keywordId` AND ee.`asin` = aa.`asin` AND ee.`other_asin` = aa.`other_asin`
AND ee.`currency` = aa.`currency` AND ee.`sku` = aa.`sku` AND  ee.`match_type` = aa.`matchType`)
;
 
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAsinsFactTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateAsinsFactTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateCampaignFactTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateCampaignFactTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateCampaignFactTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
-- DELETE FROM replica_adtec_bi.`fact_ams_campaign`  WHERE batchid = `max_date` ;
INSERT INTO replica_adtec_bi.`fact_ams_campaign` 
SELECT
  
  
   cc.`Client_Key` ,
   bb.`Account_Key`,
   dd.date_key,
   ee.`camp_key`,
   `impressions`,
   `clicks`,
  `cost`,
  `campaign_budget`,
  `attributedunitsordered`,
  `attributedsales`,
   LEFT(aa.`fk_batch_id`,8) AS batchId ,
   aa.`creation_date` AS capture_date,
   CURRENT_DATE() AS `LoadDate`
 
FROM `replica_adtec_bi`.`stage_campaign` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb  ON (aa.`fk_account_id` = bb.`Account_ID` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_brand`   cc  ON (bb.`Client_ID` = cc.`Client_key` )
LEFT JOIN replica_adtec_bi.`dim_date`    dd  ON (dd.full_date = aa.`report_date` )
LEFT JOIN replica_adtec_bi.`map_ams_report_type` ff ON (ff.`camp_type` = aa.`campaign_type`)
LEFT JOIN replica_adtec_bi.`dim_campaign` ee ON  (ee.`campaign_id` = aa.`campaign_id` AND ee.`camp_type_key` = ff.`camp_type_key`)
;
 
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateCampaignFactTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateCampaignFactTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateFactInventoryMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateFactInventoryMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateFactInventoryMaster`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	-- DECLARE EXIT HANDLER FOR SQLEXCEPTION
	-- BEGIN
		-- ERROR
		-- SELECT "Syntax Error" ;
		-- SET `_rollback` = 1 ;
		-- ROLLBACK ;
	-- END;
	
	DECLARE EXIT HANDLER FOR SQLWARNING
	BEGIN
		-- WARNING
		SELECT "Warning by DB";
		SET `_rollback` = 1 ;
		ROLLBACK;
	END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	
-- DELETE FROM replica_adtec_bi.fact_inventory_master WHERE batchid = `max_date`;
INSERT INTO replica_adtec_bi.fact_inventory_master
SELECT
 
   cc.`Client_Key` ,
   bb.`Account_Key`,
   dd.date_key,
   ee.`pm_key`,
   ff.`pm_cat_id`,
   
  aa.`seller_inv_units`,
  aa.`unseller_inv_units`,
  
  COALESCE(gg.`price`,-1) AS price,
  COALESCE(gg.`salesrank`,-1) AS salesrank,
  
  left(aa.batchid,8) as batchid,
  aa.`capture_date`,
  CURRENT_date() AS `LoadDate`
FROM `replica_adtec_bi`.`stage_inventory_master` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb  ON (aa.`fk_account_id` = bb.`Account_ID` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_brand`  cc  ON (bb.`Client_ID` = cc.`Client_key` )
LEFT JOIN replica_adtec_bi.`dim_date`    dd  ON (dd.date_key = LEFT(aa.batchid , 8) )
LEFT JOIN replica_adtec_bi.`dim_product_master`    ee  ON (ee.`fk_account_id` = aa.`fk_account_id` AND ee.`ASIN` = aa.`ASINs` AND ee.`sku` = aa.`sku`  AND aa.fulfillment_channel = ee.fulfillment_channel)
LEFT JOIN replica_adtec_bi.`dim_product_category_master`    ff  ON (ff.`fk_account_id` = aa.`fk_account_id` AND ff.`ASIN` = aa.`ASINs`  AND ff.`flag` = 1 )
LEFT JOIN 
(SELECT fk_account_id,ASIN, sku, MAX(price) AS price ,MAX(salesrank) AS salesrank FROM replica_adtec_bi.`stage_product_catalog`
GROUP BY fk_account_id,ASIN, sku)gg ON (gg.`fk_account_id` = aa.`fk_account_id` AND gg.`ASIN` = aa.`ASINs`  AND gg.`sku` = aa.`sku`)
;
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateFactInventoryMaster'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateFactInventoryMaster'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateFactSaleMaster` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateFactSaleMaster` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateFactSaleMaster`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	DECLARE EXIT HANDLER FOR SQLWARNING
	BEGIN
		-- WARNING
		SELECT "Warning by DB";
		SET `_rollback` = 1 ;
		ROLLBACK;
	END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	
-- DELETE FROM replica_adtec_bi.fact_sales_master WHERE batchid = `max_date`;
INSERT INTO fact_sales_master
SELECT
 
   cc.`Client_Key` ,
   bb.`Account_Key`,
   dd.date_key,
   ee.`pm_key`,
   ff.`pm_cat_id`,
   
  aa.`shipped_cogs`,
  aa.`shipped_unit`,
  aa.`shipped_cogs_last_year`,
  aa.`shipped_units_last_year`,
  
  COALESCE(gg.`price`,-1) AS price,
  COALESCE(gg.`salesrank`,-1) AS salesrank,
  
  left(aa.batchid,8) as batchid,
  aa.`capture_date`,
  CURRENT_DATE() AS `LoadDate`
FROM `replica_adtec_bi`.`stage_sales_master` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb  ON (aa.`fk_account_id` = bb.`Account_ID` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_brand`  cc  ON (bb.`Client_ID` = cc.`Client_key` )
LEFT JOIN replica_adtec_bi.`dim_date`    dd  ON (dd.date_key = LEFT(aa.batchid , 8) )
LEFT JOIN replica_adtec_bi.`dim_product_master`    ee  ON (ee.`fk_account_id` = aa.`fk_account_id` AND ee.`ASIN` = aa.`ASIN` AND ee.`sku` = aa.`sku` AND ee.`fulfillment_channel` = aa.`fulfillment_channel`)
LEFT JOIN replica_adtec_bi.`dim_product_category_master`    ff  ON (ff.`fk_account_id` = aa.`fk_account_id` AND ff.`ASIN` = aa.`ASIN`  AND ff.`flag` = 1 )
LEFT JOIN 
(SELECT fk_account_id,ASIN, sku,`fulfillment_channel`, MAX(price) AS price ,MAX(salesrank) AS salesrank FROM replica_adtec_bi.`stage_product_catalog`
GROUP BY fk_account_id,ASIN, sku,`fulfillment_channel`)gg ON (gg.`fk_account_id` = aa.`fk_account_id` AND gg.`ASIN` = aa.`ASIN`  AND gg.`sku` = aa.`sku` AND gg.`fulfillment_channel` = aa.`fulfillment_channel`)
;
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateFactSaleMaster'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateFactSaleMaster'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateFactScraping` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateFactScraping` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateFactScraping`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	DECLARE EXIT HANDLER FOR SQLWARNING
	BEGIN
		-- WARNING
		SELECT "Warning by DB";
		SET `_rollback` = 1 ;
		ROLLBACK;
	END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	
-- DELETE FROM replica_adtec_bi.fact_scraping WHERE DATE_FORMAT(capture_date,'%Y%m%d') = date_format(`max_date`,'%Y%m%d');
INSERT INTO fact_scraping
SELECT
 null,
   cc.`Client_Key` ,
   bb.`Account_Key`,
   dd.date_key,
   ee.`scrap_key` as scrap_key,
   aa.`total_reviews`,
   aa.`reviews_count`,
   aa.`average_review`,
   aa.`capture_date`,
   CURRENT_DATE() AS `LoadDate`
  
  
FROM `replica_adtec_bi`.`stage_scraping` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb  ON (aa.`account_id` = bb.`Account_ID` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_brand`  cc  ON (bb.`Client_ID` = cc.`Client_key` )
LEFT JOIN replica_adtec_bi.`dim_date`    dd  ON (dd.date_key = DATE_FORMAT(aa.capture_date,'%Y%m%d') )
LEFT JOIN replica_adtec_bi.`dim_scraping`    ee  ON (ee.`account_id` = aa.`account_id` AND ee.`asin` = aa.`asin` )
;
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateFactScraping'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spPopulateFactScraping'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateProductFactTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateProductFactTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateProductFactTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
-- DELETE FROM replica_adtec_bi.`fact_ams_product`  WHERE batchid = `max_date`;
INSERT INTO replica_adtec_bi.`fact_ams_product` 
SELECT
  
  
   cc.`Client_Key` ,
   bb.`Account_Key`,
   dd.date_key,
   ee.`product_key`,
   `impressions`,
   `clicks`,
    `cost`,
     COALESCE(conversions,0) AS `attributedunitsconversions`,
   unit_ordered AS `attributedunitsordered`,
  sales AS `attributedsales`,
   LEFT(aa.`fk_Batch_Id`, 8) AS batchId ,
   aa.`creation_Date` AS capture_date,
   CURRENT_DATE() AS `LoadDate`
 
FROM `replica_adtec_bi`.`stage_product_ads` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb  ON (aa.`fk_Account_Id` = bb.`Account_ID` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_brand`   cc  ON (bb.`Client_ID` = cc.`Client_key` )
LEFT JOIN replica_adtec_bi.`dim_date`    dd  ON (dd.full_date = aa.`report_Date` )
LEFT JOIN replica_adtec_bi.`map_ams_report_type` ff ON (ff.`camp_type` = aa.`campaign_type`)
LEFT JOIN replica_adtec_bi.`dim_product` ee ON (ee.`campaign_id` = aa.`campaign_Id` AND ee.`camp_type_key` = ff.`camp_type_key` AND ee.`adgroup_id` = aa.`adGroup_Id` 
                                      AND ee.`ad_id` = aa.ad_id AND ee.`asin` = aa.asin AND ee.`asin` = aa.asin  )
;
 
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateProductFactTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateProductFactTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulatePurchaseOrderFactTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulatePurchaseOrderFactTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulatePurchaseOrderFactTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
-- DELETE FROM `replica_adtec_bi`.`fact_purchaseorder` WHERE LEFT(batchid,8) = `max_date`;
INSERT INTO `replica_adtec_bi`.`fact_purchaseorder`
SELECT 	
         cc.`Client_Key` ,
         bb.`Account_Key`,
         dd.date_key,
         ee.po_key,
	`case_size`, 
	`submitted_cases`, 
	`accepted_cases`, 
	`received_cases`, 
	`outstanding_cases`, 
	`str_case_cost`, 
	`str_total_cost`, 
	`case_cost`, 
	`total_cost`, 
	`accepted_case`, 
	`rejected_case`, 
	`total_po_cost`, 
         LEFT(aa.batchid,8) AS batchid,
         aa.`capture_date`,
         CURRENT_DATE() AS `LoadDate`
	 
	FROM 
	`replica_adtec_bi`.`stage_purchaseorder_master`  aa
	LEFT JOIN replica_adtec_bi.`dim_account` bb           ON (aa.`fk_account_id` = bb.`Account_ID` AND bb.`flag` = 1)
        LEFT JOIN replica_adtec_bi.`dim_brand`   cc           ON (bb.`Client_ID` = cc.`Client_key` )
        LEFT JOIN replica_adtec_bi.`dim_date`    dd           ON (dd.date_key = LEFT(aa.batchid , 8) )
        LEFT JOIN replica_adtec_bi.`dim_purchaseorder` ee     ON (ee.asins   = aa.asins AND ee.po = aa.po  AND ee.sku = aa.sku AND ee.`model_number` = aa.`model_number`)
;
 
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulatePurchaseOrderFactTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulatePurchaseOrderFactTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spUpdateDimKeyword` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUpdateDimKeyword` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUpdateDimKeyword`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 /* DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ; */
  START TRANSACTION ;
  SET autocommit = 0 ;
  -- ===============================================================================================
UPDATE 
   `adtec_bi`.`dim_keyword` AS l 
  INNER JOIN `map_ams_report_type` AS m 
    ON (
      l.`camp_type_key` = m.`camp_type_key`
    ) 
  INNER JOIN `adtec_bi`.`stage_keyword`  AS r 
    ON (
      
     l.`campaign_id` = r.`campaignId`
 AND l.`adgroup_id` = r.`adGroupId`
 AND l.`keyword_id` = r.`keywordId`
    ) 
    
    SET l.`match_type` = r.`matchType`,
        l.`Load_Date` = CURRENT_DATE
        
WHERE l.`match_type` != r.`matchType`
;
  -- ===============================================================================================
  IF `_rollback` 
  THEN 
  INSERT INTO `adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spUpdateDimKeyword',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
  ELSE 
  INSERT INTO `adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spUpdateDimKeyword',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
  END IF ;
  IF `_rollback` 
  THEN ROLLBACK ;
  ELSE COMMIT ;
  END IF ;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spMasterDataValidation` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMasterDataValidation` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMasterDataValidation`(IN `max_date` VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	
	
	CALL `replica_adtec_bi`.`spDataValidationLayerTruncate`(`max_date`);
	
	CALL `replica_adtec_bi`.`spPopulateDateLevelSalesValidationTable`(`max_date`);
	CALL `replica_adtec_bi`.`spPopulateAccountLevelSalesValidationTable`(`max_date`);
	
	CALL `replica_adtec_bi`.`spPopulateDateLevelInventoryValidationTable`(`max_date`);
	CALL `replica_adtec_bi`.`spPopulateAccountLevelInventoryValidationTable`(`max_date`);
	
	CALL `replica_adtec_bi`.`spPopulateDateLevelCampaignValidationTable`(`max_date`);
	call `replica_adtec_bi`.`spPopulateAccountLevelCampaignValidationTable`(`max_date`);
	
	CALL `replica_adtec_bi`.`spPopulateDateLevelAdgroupValidationTable`(`max_date`);
	CALL `replica_adtec_bi`.`spPopulateAccountLevelAdgroupValidationTable`(`max_date`);
	
	CALL `replica_adtec_bi`.`spPopulateDateLevelKeywordValidationTable`(`max_date`);
	 CALL `replica_adtec_bi`.`spPopulateAccountLevelKeywordValidationTable`(`max_date`);
	
	CALL `replica_adtec_bi`.`spPopulateDateLevelProductValidationTable`(`max_date`);
	CALL `replica_adtec_bi`.`spPopulateAccountLevelProductValidationTable`(`max_date`);
	
	CALL `replica_adtec_bi`.`spPopulateDateLevelASINValidationTable`(`max_date`);
	CALL `replica_adtec_bi`.`spPopulateAccountLevelASINValidationTable`(`max_date`);
	
	CALL `replica_adtec_bi`.`spPopulateDateLevelPOValidationTable` (`max_date`);
	CALL `replica_adtec_bi`.`spPopulateAccountLevelPurchaseOrderValidationTable` (`max_date`);
	
                         CALL `replica_adtec_bi`.`spPopulateDateLevelScrapingValidation`  (`max_date`);
	CALL `replica_adtec_bi`.`spPopulateAccountLevelScrapingValidationTable` (`max_date`);
	
	
	
	-- Commit if no warning and error else roolback and put them into ETL Logs
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spMasterDataValidation'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spMasterDataValidation'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
     END */$$
DELIMITER ;

/* Procedure structure for procedure `spUpdateDimCampiagn` */

/*!50003 DROP PROCEDURE IF EXISTS  `spUpdateDimCampiagn` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spUpdateDimCampiagn`()
BEGIN
  DECLARE max_date DATE DEFAULT NULL ;

  
  -- ===============================================================================================
UPDATE 
  `replica_adtec_bi`.`dim_campaign` AS l 
  INNER JOIN `map_ams_report_type` AS m 
    ON (
      l.`camp_type_key` = m.`camp_type_key`
    ) 
  INNER JOIN `replica_adtec_bi`.`stage_campaign` AS r 
    ON (
      l.campaign_id = r.campaign_id 
      AND l.campaign_name = r.campaign_name 
      AND r.`campaign_type` = m.`camp_type`
    ) SET l.`campaign_status` = r.`campaign_status`,
  l.`campaign_budget_type` = r.`campaign_budget_type`,
  l.`Load_Date` = CURDATE()
WHERE (
    l.`campaign_status` != r.`campaign_status` 
    OR l.`campaign_budget_type` != r.`campaign_budget_type`
  ) ;
  -- ===============================================================================================
  
  END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateKeywordFactTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateKeywordFactTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateKeywordFactTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
-- DELETE FROM adtec_bi.`fact_ams_keyword`  WHERE batchid = `max_date` ;
INSERT INTO replica_adtec_bi.`fact_ams_keyword` 
SELECT
  
  
   cc.`Client_Key` ,
   bb.`Account_Key`,
   dd.date_key,
   ee.`keyword_key`,
   `impressions`,
   `clicks`,
  `cost`,
  `attributedunitsordered`,
  `attributedsales`,
   LEFT(aa.`fkBatchId`, 8) AS batchId ,
   aa.`creationDate` AS capture_date,
   CURRENT_DATE() AS `LoadDate`
 
FROM `replica_adtec_bi`.`stage_keyword` aa
LEFT JOIN replica_adtec_bi.`dim_account` bb  ON (aa.`fkAccountId` = bb.`Account_ID` AND bb.`flag` = 1)
LEFT JOIN replica_adtec_bi.`dim_brand`   cc  ON (bb.`Client_ID` = cc.`Client_key` )
LEFT JOIN replica_adtec_bi.`dim_date`    dd  ON (dd.full_date = aa.`reportDate` )
LEFT JOIN replica_adtec_bi.`map_ams_report_type` ff ON (ff.`camp_type` = aa.`campaign_type`)
LEFT JOIN replica_adtec_bi.`dim_keyword` ee ON (ee.`campaign_id` = aa.`campaignId` AND ee.`camp_type_key` = ff.`camp_type_key`
AND ee.`adgroup_id` = aa.`adGroupId` AND ee.`keyword_id` = aa.`keywordId` AND ee.`match_type` = aa.`matchType`
AND aa.matchtype = ee.match_type
)
;
 
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateKeywordFactTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateKeywordFactTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateKeywordPresentationTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateKeywordPresentationTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateKeywordPresentationTable`(IN max_date VARCHAR(20))
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
 -- DECLARE EXIT HANDLER FOR SQLWARNING 
 -- BEGIN
    -- WARNING
   -- SELECT 
     -- "Warning by DB" ;
  --  SET `_rollback` = 1 ;
   -- ROLLBACK;
  -- END ;
  START TRANSACTION ;
  SET autocommit = 0 ;
  
INSERT INTO `prst_tbl_ams_keyword`
SELECT
  ee.`Client_ID`,
  ee.`Client_Name`,
  dd.`Account_ID`,
  dd.`Account_Name`,
  pp.profile_id,
  pp.profile_Name,
  
  `date_key`,
   bb.campaign_id,
   bb.`campaign_name`,
   cc.`camp_type`,
     
   bb.adgroup_id,
   bb.adgroup_name,
   bb.keyword_id,
   bb.keyword_name,
   bb.match_type,
   
 
  
  `impressions`,
  `clicks`,
  `cost`,
  `revenue`,
  `order_conversion`,
 
CASE WHEN revenue > 0 THEN  ROUND((Cost/Revenue),2) ELSE 0 END AS acos_,
CASE WHEN clicks > 0 THEN   ROUND((Cost/ clicks),2) ELSE 0 END AS CPC,
CASE WHEN `impressions` > 0 THEN  ROUND((Clicks/`impressions`),2) ELSE 0 END  AS CTR,
CASE WHEN `order_conversion` > 0 THEN ROUND((Cost/`order_conversion`),2) ELSE 0 END 	AS CPA,
CASE WHEN Cost > 0 THEN   ROUND((Revenue/Cost),2) ELSE 0 END  AS ROAS ,
aa.batchid,
aa.capture_date,
CURRENT_DATE AS loaddate  
FROM `replica_adtec_bi`.`fact_ams_keyword`  aa
LEFT JOIN `replica_adtec_bi`.`dim_keyword`         bb  ON (aa.`keyword_key` = bb.`keyword_key`)
LEFT JOIN `replica_adtec_bi`.`map_ams_profile`      pp  ON (pp.`profile_key` = bb.profile_key)
LEFT JOIN `replica_adtec_bi`.`map_ams_report_type`  cc  ON (bb.`camp_type_key` = cc.`camp_type_key`)
LEFT JOIN `replica_adtec_bi`.`dim_account`          dd  ON (dd.`Account_Key` = aa.`account_key` AND dd.flag = 1)
LEFT JOIN `replica_adtec_bi`.`dim_brand`            ee  ON (ee.`Client_Key` = aa.`client_key`)
WHERE aa.batchid = max_date;
  
 
 -- -------------------------------------------------------------------------
 
   IF `_rollback` 
  THEN 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateKeywordPresentationTable',
      'RollBack',
      CURRENT_TIMESTAMP()
    ) ;
    ROLLBACK ;
  ELSE 
  INSERT INTO `replica_adtec_bi`.`etl_logs` (
    `log_id`,
    `Stored_Procedure_Name`,
    `Execution_status`,
    `LogDate`
  ) 
  VALUES
    (
      NULL,
      'spPopulateKeywordPresentationTable',
      'Commit',
      CURRENT_TIMESTAMP()
    ) ;
    COMMIT ;
  END IF ;
  
    END */$$
DELIMITER ;

/* Procedure structure for procedure `spAddNewRecordDimKeyword` */

/*!50003 DROP PROCEDURE IF EXISTS  `spAddNewRecordDimKeyword` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spAddNewRecordDimKeyword`()
BEGIN
  DECLARE `_rollback` BOOL DEFAULT 0 ;
  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
  BEGIN
    -- ERROR
    SELECT 
      "Syntax Error" ;
    SET `_rollback` = 1 ;
    ROLLBACK ;
  END ;
  
  /* DECLARE EXIT HANDLER FOR SQLWARNING 
  BEGIN
    -- WARNING
    SELECT 
      "Warning by DB" ;
    SET `_rollback` = 1 ;
    ROLLBACK;
  END ; */
  
  
  START TRANSACTION ;
  
  
  SET autocommit = 0 ;
  
INSERT INTO `replica_adtec_bi`.`dim_keyword`
SELECT
   NULL
 , bb.camp_type_key
 , cc.profile_key
 , aa.`campaignid`
 , aa.`campaignname`
 , aa.`adGroupId`
 , aa.`adGroupName`
 , aa.`keywordId`
 , aa.`keywordText`
 , aa.`matchType`
 , CURRENT_DATE() AS load_date
 , aa.`campaign_type`
  
FROM
   `replica_adtec_bi`.`stage_keyword` aa
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_report_type` bb
      ON
         (
            aa.`campaign_type` = bb.camp_type
         )
   LEFT JOIN
      `replica_adtec_bi`.`map_ams_profile` cc
      ON
         (
            aa.`fkProfileId` = cc.profile_id
         )
   LEFT OUTER JOIN
      `replica_adtec_bi`.`dim_keyword` dd
      ON
         (
            aa.campaignId = dd.campaign_id AND aa.`adGroupId` = dd.`adgroup_id` AND aa.`keywordId` = dd.`keyword_id`
             AND aa.campaign_type = dd.campaign_type and aa.matchType = dd.match_Type
         )
WHERE
   dd.campaign_name IS NULL
  
;
 
   IF `_rollback` THEN
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimKeyword'
       , 'RollBack'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   ROLLBACK;
   ELSE
   INSERT INTO `replica_adtec_bi`.`etl_logs`
      ( `log_id`
       , `Stored_Procedure_Name`
       , `Execution_status`
       , `LogDate`
      )
      VALUES
      ( NULL
       , 'spAddNewRecordDimKeyword'
       , 'Commit'
       , CURRENT_TIMESTAMP()
      )
   ;
   
   COMMIT;
   END
   IF;
   
   END */$$
DELIMITER ;

/* Procedure structure for procedure `spMasterPresentationLayer` */

/*!50003 DROP PROCEDURE IF EXISTS  `spMasterPresentationLayer` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spMasterPresentationLayer`(IN max_date VARCHAR(20))
BEGIN
	DECLARE `_rollback` BOOL DEFAULT 0;
    
	-- Exception Handling for Syntax Error   
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		-- ERROR
		SELECT "Syntax Error" ;
		SET `_rollback` = 1 ;
		ROLLBACK ;
	END;
	
	-- DECLARE EXIT HANDLER FOR SQLWARNING
	-- BEGIN
		-- WARNING
	--	SELECT "Warning by DB";
	--	SET `_rollback` = 1 ;
	--	ROLLBACK;
	-- END;
	
	-- DB Transactions start here
	START TRANSACTION;
  
	-- use to control AutoCommit off
	SET autocommit = 0;
	
	
	CALL `replica_adtec_bi`.spPopulateAllAsinDetailsTable();
	CALL `replica_adtec_bi`.spPopulateOverrideAllDetailsTable();
	CALL `replica_adtec_bi`.spPopulateOverrideAllTables();
	CALL `replica_adtec_bi`.spPresentationLayerTruncate(max_date);
	CALL `replica_adtec_bi`.spPopulateAsinLevelMonthlyTable();
	CALL `replica_adtec_bi`.spPopulateAsinLevelWeeklyTable();
	CALL `replica_adtec_bi`.spPopulateAsinLevelDailyTable(max_date);
	
	CALL `replica_adtec_bi`.`spPopulateInventoryPresentationTable` (max_date);
	CALL `replica_adtec_bi`.`spPopulateCampaignPresentationTable`  (max_date);
	CALL `replica_adtec_bi`.`spPopulateAdgroupPresentationTable`   (max_date);
	CALL `replica_adtec_bi`.`spPopulateKeywordPresentationTable` (max_date);
	CALL `replica_adtec_bi`.`spPopulateProductPresentationTable`   (max_date);
	CALL `replica_adtec_bi`.`spPopulateAsinsPresentationTable`     (max_date);
	CALL `replica_adtec_bi`.`spPopulatePurchaseOrderPresentationTable` (max_date);
	CALL `replica_adtec_bi`.`spPopulateScrapingPresentationTable` (max_date);
	
	
	
	CALL `replica_adtec_bi`.`spPopulatePresentationPre30DayTable`();
	CALL `replica_adtec_bi`.`spPopulatePresentationPre30DayTableGrandTotal`();
	CALL `replica_adtec_bi`.`spPopulatePresentationYTDTable`();
	CALL `replica_adtec_bi`.`spPopulatePresentationYTDGrandTotalTable`();
	CALL `replica_adtec_bi`.`spPopulateProductMasterTempTable` (max_date);
	CALL `replica_adtec_bi`.`spPopulateProductMasterTable`();
	
	
	
	
	-- Commit if no warning and error else roolback and put them into ETL Logs
  
	IF `_rollback` THEN
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spMasterPresentationLayer'
			,'RollBack'
			,CURRENT_TIMESTAMP()	
);
		ROLLBACK;
	ELSE
	
		INSERT INTO `replica_adtec_bi`.`etl_logs` (
			`log_id`
			,`Stored_Procedure_Name`
			,`Execution_status`
			,`LogDate`
) 
		VALUES (
			NULL
			,'spMasterPresentationLayer'
			,'Commit'
			,CURRENT_TIMESTAMP()
) ;
		COMMIT;
	END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `spPopulateStageAMSKeywordTable` */

/*!50003 DROP PROCEDURE IF EXISTS  `spPopulateStageAMSKeywordTable` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spPopulateStageAMSKeywordTable`(in max_date varchar(20))
BEGIN
  


  
  
INSERT INTO replica_adtec_bi.`stage_keyword`
SELECT
 NULL,
  `fkBatchId`,
  `fkAccountId`,
  `fkProfileId`,
  `profile_name`,
  `campaignId`,
  `campaignName`,
  `adGroupId`,
  `adGroupName`,
  `keywordId`,
  `keywordText`,
  `matchType`,
  `report_type`,
  `impressions`,
  `clicks`,
  `cost`,
  `attributedConversions`,
  `attributedConversionsSameSKU`,
  `attributedUnitsOrdered`,
  `attributedSales`,
  `attributedSalesSameSKU`,
  `reportDate`,
  `creationDate`
FROM `replica_adtec`.`tbl_rtl_ams_keyword_new`
WHERE reportDate = max_date ;

    END */$$
DELIMITER ;

/* Procedure structure for procedure `spETL` */

/*!50003 DROP PROCEDURE IF EXISTS  `spETL` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spETL`()
BEGIN
    DECLARE max_date VARCHAR(20) DEFAULT '' ;
    DECLARE Exdays INT DEFAULT 10;
    
       
      simple_loop: LOOP
      
        SET max_date := DATE_FORMAT( CURDATE() - INTERVAL Exdays DAY,'%Y%m%d')  ; 
         SET Exdays=Exdays - 1;
         
        
        CALL `replica_adtec`.`spMasterRTL`(max_date);
        CALL `spMasterETL`(max_date);
        CALL `spMasterPresentationLayer`(max_date);
        CALL `spMasterDataValidation`(max_date);
         
         
         IF Exdays = 2 THEN
            LEAVE simple_loop;
         END IF;
       
        END LOOP simple_loop;
	
 
  
  
   
  


    END */$$
DELIMITER ;

/* Procedure structure for procedure `spETL_Adhoc` */

/*!50003 DROP PROCEDURE IF EXISTS  `spETL_Adhoc` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `spETL_Adhoc`()
BEGIN
 
       
        
        CALL `replica_adtec`.`spMasterRTL`(20220118);
        CALL `spMasterETL`(20220118);
        CALL `spMasterPresentationLayer`(20220118);
        CALL `spMasterDataValidation`(20220118);
        
        
                CALL `replica_adtec`.`spMasterRTL`(20220122);
        CALL `spMasterETL`(20220122);
        CALL `spMasterPresentationLayer`(20220122);
        CALL `spMasterDataValidation`(20220122);
        
        
                CALL `replica_adtec`.`spMasterRTL`(20220126);
        CALL `spMasterETL`(20220126);
        CALL `spMasterPresentationLayer`(20220126);
        CALL `spMasterDataValidation`(20220126);
        
        
                  CALL `replica_adtec`.`spMasterRTL`(20220204);
        CALL `spMasterETL`(20220204);
        CALL `spMasterPresentationLayer`(20220204);
        CALL `spMasterDataValidation`(20220204);
        
   
        
        
                        
       
         
    


    END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
